using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace MasterPages
{
	/// <summary>
	/// Interaction logic for Window1.xaml
	/// </summary>

	public partial class Window1 : System.Windows.Window
	{
		public Window1()
		{
			InitializeComponent();
		}

		private void GoToPageExecuteHandler(object sender, ExecutedRoutedEventArgs e)
		{
			frmContent.NavigationService.Navigate(new Uri((string)e.Parameter, UriKind.Relative));
		}

		private void GoToPageCanExecuteHandler(object sender, CanExecuteRoutedEventArgs e)
		{
			e.CanExecute = true;
		}
	}
}