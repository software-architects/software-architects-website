﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using BugBusters.Data;

namespace BugBusters.Test
{
    [TestClass]
    public class DataAccessLayerTests
    {
        public DataAccessLayerTests()
        {
        }

        #region TestContext property
        private TestContext testContextInstance;
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }
        #endregion

        #region Test initialization and cleanup code
        private BugBustersDataContext db;
        /// <summary>
        /// Initialize test database using SQL initialization script and open data context
        /// </summary>
        [TestInitialize()]
        public void TimeTrackingConstraintsTestInitialize()
        {
            string connString = ConfigurationManager.ConnectionStrings["TestDatabase"].ConnectionString;
            db = new BugBustersDataContext(ConfigurationManager.ConnectionStrings["TestDatabase"].ConnectionString);
            db.Connection.Open();
            var cmd = new SqlCommand(ConfigurationManager.AppSettings["TestDatabaseInitializationScript"], (SqlConnection)db.Connection);
            cmd.ExecuteNonQuery();
            db.Connection.Close();
        }

        /// <summary>
        /// Close data context after test is done
        /// </summary>
        [TestCleanup()]
        public void TimeTrackingConstraintsTestCleanup()
        {
            db.Dispose();
            db = null;
        }
        #endregion

        private int AddTimeTrackingRow(DateTime startTime, TimeSpan duration)
        {
            var numberOfRecords = db.TimeTrackings.Count();

            var tt = new TimeTracking();
            tt.Project = db.Projects.First();
            tt.TaskType = db.TaskTypes.First();
            tt.User = db.Users.First();
            tt.StartTime = startTime;
            tt.EndTime = startTime + duration;
            tt.Comment = "This is a test case generated during unit testing!";
            db.SubmitChanges();

            Assert.AreEqual(numberOfRecords + 1, db.TimeTrackings.Count());

            return tt.TrackingId;
        }

        [TestMethod]
        public void AddSingleRow()
        {
            var startTime = new DateTime(2007, 1, 1, 8, 0, 0);
            var duration = new TimeSpan(1, 0, 0);

            AddTimeTrackingRow(startTime, duration);
        }

        [TestMethod]
        public void UpdateSingleRow()
        {
            AddTimeTrackingRow(new DateTime(2007, 1, 1, 8, 0, 0), new TimeSpan(1, 0, 0));
            int trackingId = AddTimeTrackingRow(new DateTime(2007, 1, 1, 9, 0, 0), new TimeSpan(1, 0, 0));

            var tt = db.TimeTrackings.Single(t => t.TrackingId == trackingId);
            tt.StartTime = tt.StartTime.AddMinutes(30);
            db.SubmitChanges();

            Assert.AreEqual(2, db.TimeTrackings.Count());
        }

        [TestMethod]
        public void Delete_DeleteSingleRow()
        {
            // add a time tracking entry
            int trackingId = AddTimeTrackingRow(new DateTime(2007, 1, 1, 9, 0, 0), new TimeSpan(1, 0, 0));
            // delete the entry
            db.TimeTrackings.DeleteOnSubmit(db.TimeTrackings.Single(t => t.TrackingId == trackingId));
            db.SubmitChanges();

            Assert.AreEqual(0, db.TimeTrackings.Count());
        }
    }
}
