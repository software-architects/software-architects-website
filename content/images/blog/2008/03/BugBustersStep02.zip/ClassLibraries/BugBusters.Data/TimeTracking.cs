﻿using System;
using System.Linq;
using System.Data.Linq;

namespace BugBusters.Data
{
    public partial class TimeTracking
    {
        partial void OnValidate(System.Data.Linq.ChangeAction action)
        {
            if (action == ChangeAction.Insert || action == ChangeAction.Update)
            {
                if (StartTime >= EndTime)
                    throw new ApplicationException("StartTime must be lower than EndTime!");
            }

            if (User.TimeTrackings.Count(tt => ((tt.StartTime >= StartTime && tt.StartTime < EndTime)
                || (tt.EndTime > StartTime && tt.EndTime <= EndTime))
                && tt != this) > 0)
            {
                throw new ApplicationException("Times must not overlap!");
            }
        }
    }
}
