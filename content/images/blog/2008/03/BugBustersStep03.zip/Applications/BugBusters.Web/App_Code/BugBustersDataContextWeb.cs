﻿using BugBusters.Data;

public class BugBustersDataContextWeb : BugBustersDataContext
{
    public BugBustersDataContextWeb()
        : base(System.Configuration.ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString)
    {
    }
}
