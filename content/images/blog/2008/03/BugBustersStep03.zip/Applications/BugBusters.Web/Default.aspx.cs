﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.Linq;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
		lstUsers.DataBound += new EventHandler(LstUsers_DataBound);

		if (Request.Form["__EVENTTARGET"] == "DataBind")
		{
			Result.DataBind();
		}
    }

	private void LstUsers_DataBound(object sender, EventArgs e)
	{
		((DropDownList)sender).Items.Insert(0, new ListItem("All", "0"));
	}
}
