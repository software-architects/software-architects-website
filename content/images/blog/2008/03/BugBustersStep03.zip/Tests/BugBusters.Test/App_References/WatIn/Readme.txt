ATTENTION!
You have to copy the WatiN DLLs in this directory!