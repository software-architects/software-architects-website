﻿using System;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Data.SqlClient;
using System.Configuration;
using WatiN.Core;
using BugBusters.Data;
using System.Globalization;
using WatiN.Core.DialogHandlers;
using WatiN.Core.UnitTests;
using Microsoft.VisualStudio.TestTools.UnitTesting.Web;

namespace BugBusters.Test
{
    [TestClass]
    public class UserInterfaceTests
    {
        private interface IAssertable
        {
            void AssertControls();
        }

        private abstract class Screen : IDisposable
        {
            public IE ie { get; private set; }

            public Screen(string url, bool attach)
            {
                ie = attach ? IE.AttachToIE(Find.ByUrl(url)) : new IE(url);
                Assert.IsFalse(ie.Html.Contains("Runtime Error"));
                if (this is IAssertable)
                    ((IAssertable)this).AssertControls();
            }

            public Screen(string url)
                : this(url, false)
            {
            }

            public void Dispose()
            {
                ie.Close();
                ie.Dispose();
                GC.SuppressFinalize(this);
            }
        }

        private class OverviewScreen : Screen, IAssertable
        {
            private const string Url = "http://localhost/BugBusters/Default.aspx";
            private const string Control_WindowsLoginFilter = "lstUsers";
            private const string Control_ResultGrid = "Result";
            private const string Control_AddNewLink = "lnkAddItem";
            private const string Control_HelpLink = "lnkHelp";
            public const string FilterItem_All = "All";
            public const int NumberOfResultColumns = 8;
            public const int ColumnIndex_StartTime = 3;
            public const int ColumnIndex_EndTime = 4;
            public const int ColumnIndex_Duration = 5;

            public OverviewScreen()
                : base(Url)
            {
            }

            public void AssertControls()
            {
                var loginFilter = ie.SelectList(Control_WindowsLoginFilter);
                Assert.IsTrue(loginFilter.Exists);
                var resultTable = ie.Table(Control_ResultGrid);
                Assert.IsTrue(resultTable.Exists);
            }

            public SelectList LoginFilter
            {
                get
                {
                    var loginFilter = ie.SelectList(Control_WindowsLoginFilter);
                    Assert.IsTrue(loginFilter.Exists);
                    return loginFilter;
                }
            }
            public void SetLoginFilter(string user)
            {
                // select the current user
                LoginFilter.Select(user);
                // page has been reloaded -> call AssertControls again to verify consistency
                AssertControls();
            }

            public Table ResultGrid
            {
                get
                {
                    var resultTable = ie.Table(Control_ResultGrid);
                    Assert.IsTrue(resultTable.Exists);
                    return resultTable;
                }
            }

            public Link HelpLink
            {
                get
                {
                    var link = ie.Link(Control_HelpLink);
                    Assert.IsTrue(link.Exists);
                    return link;
                }
            }

            public Link AddNewLink
            {
                get
                {
                    var link = ie.Link(Control_AddNewLink);
                    Assert.IsTrue(link.Exists);
                    return link;
                }
            }
        }

        public UserInterfaceTests()
        {
        }

        #region TestContext Property
        private TestContext testContextInstance;
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }
        #endregion

        #region Test and class initialization and cleanup code
        private BugBustersDataContext db;
        /// <summary>
        /// Initialize test database using SQL initialization script and open data context
        /// </summary>
        [TestInitialize()]
        public void TimeTrackingUITestInitialize()
        {
            string connString = ConfigurationManager.ConnectionStrings["TestDatabase"].ConnectionString;
            db = new BugBustersDataContext(ConfigurationManager.ConnectionStrings["TestDatabase"].ConnectionString);
            db.Connection.Open();
            var cmd = new SqlCommand(ConfigurationManager.AppSettings["TestDatabaseInitializationScript"], (SqlConnection)db.Connection);
            cmd.ExecuteNonQuery();
            cmd = new SqlCommand(ConfigurationManager.AppSettings["UITestDatabaseInitializationScript"], (SqlConnection)db.Connection);
            cmd.ExecuteNonQuery();
        }
        /// <summary>
        /// Close data context after test is done
        /// </summary>
        [TestCleanup()]
        public void TimeTrackingConstraintsTestCleanup()
        {
            db.Dispose();
            db = null;
        }
        #endregion

        [TestMethod]
        public void Overview_Launch()
        {
            using (var screen = new OverviewScreen())
            {
                // Check that login filter contains the correct number of items (number of rows in db plus "All");
                Assert.AreEqual(db.Users.Count() + 1, screen.LoginFilter.AllContents.Count);
                // Check that item "All" is present
                Assert.IsTrue(screen.LoginFilter.AllContents.Contains(OverviewScreen.FilterItem_All));

                // Table has to have at least one row (header)
                Assert.IsTrue(screen.ResultGrid.TableRows.Length >= 1);
                // Table has to have 8 columns
                Assert.AreEqual(OverviewScreen.NumberOfResultColumns,
                    screen.ResultGrid.TableRows[0].Elements.Cast<Element>().Count(elem => elem.TagName == "TH"));
            }
        }

        [TestMethod]
        public void Overview_Filter()
        {
            using (var screen = new OverviewScreen())
            {
                // iterate over all users in the database plus "All"
                foreach (var user in (new string[] { OverviewScreen.FilterItem_All }).Union(from u in db.Users select u.WindowsLogin))
                {
                    // select the current user
                    screen.SetLoginFilter(user);

                    // check that the number of rows in the table corresponds to the number of entries in the database.
                    // would not work with paging and a large number of rows!! Just to keep it simple here...
                    if (user != OverviewScreen.FilterItem_All)
                        Assert.AreEqual(db.Users.Single(uu => uu.WindowsLogin == user).TimeTrackings.Count + 1, screen.ResultGrid.TableRows.Length);
                    else
                        Assert.AreEqual(db.TimeTrackings.Count() + 1, screen.ResultGrid.TableRows.Length);
                }
            }
        }
    }
}
