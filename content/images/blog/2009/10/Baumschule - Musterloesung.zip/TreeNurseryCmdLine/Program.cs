﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TreeNursery.Xaml;
using System.Linq.Expressions;

namespace TreeNursery
{
	class Program
	{
		static void Main(string[] args)
		{
			ParseXaml.GetMyGarden();
		}
	}
}
