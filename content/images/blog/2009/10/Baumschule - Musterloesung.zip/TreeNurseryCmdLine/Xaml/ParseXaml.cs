﻿using System.Collections.Generic;
using System.Windows.Markup;
using System.IO;

namespace TreeNursery.Xaml
{
	public abstract class Fruit
	{
		public override string ToString()
		{
			return "Fruit";
		}
	}

	public sealed class Apple : Fruit
	{
		public override string ToString()
		{
			return "Apple";
		}
	}

	public sealed class Apricot : Fruit
	{
		public override string ToString()
		{
			return "Apricot";
		}
	}

	public sealed class Tree
	{
		public Fruit Fruit { get; set; }
		public int NumberOfFruits { get; set; }
	}

	public sealed class Garden
	{
		public Garden()
		{
			this.Trees = new List<Tree>();
		}

		public List<Tree> Trees { get; set; }
	}

	public static class ParseXaml
	{
		public static void GetMyGarden()
		{
			var myGarden = XamlReader.Parse(File.ReadAllText("Xaml\\Data.xaml"));
		}
	}
}
