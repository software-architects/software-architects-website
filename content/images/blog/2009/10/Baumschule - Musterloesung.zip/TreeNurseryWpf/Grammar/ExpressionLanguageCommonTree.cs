﻿using System.Linq;
using Antlr.Runtime;
using Antlr.Runtime.Tree;
using System.Collections.Generic;

namespace TreeNurseryWpf.Grammar
{
	public class ExpressionLanguageCommonTree : CommonTree
	{
		public ExpressionLanguageCommonTree(IToken token)
            : base(token)
        {
        }

		public IEnumerable<ExpressionLanguageCommonTree> ExpressionLanguageChildren
		{
			get
			{
				return this.Children.Cast<ExpressionLanguageCommonTree>().ToList();
			}
		}

		public string TypeName
		{
			get
			{
				return ExpressionLanguageParser.tokenNames[this.Type];
			}
		}
	}
}
