// $ANTLR 3.1.3 Mar 17, 2009 19:23:44 Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g 2009-09-20 14:12:54

// The variable 'variable' is assigned but its value is never used.
#pragma warning disable 168, 219
// Unreachable code detected.
#pragma warning disable 162


using System;
using Antlr.Runtime;
using IList 		= System.Collections.IList;
using ArrayList 	= System.Collections.ArrayList;
using Stack 		= Antlr.Runtime.Collections.StackList;


namespace  TreeNurseryWpf.Grammar 
{
public partial class ExpressionLanguageLexer : Lexer {
    public const int LESSTHAN = 10;
    public const int LITERALBOOLEAN = 17;
    public const int T__27 = 27;
    public const int INTEGERLITERAL = 22;
    public const int T__26 = 26;
    public const int T__25 = 25;
    public const int NUMERICLITERAL = 21;
    public const int LTEQ = 12;
    public const int BOOLEANLITERAL = 20;
    public const int WHITESPACE = 24;
    public const int DIFFERENT = 9;
    public const int GTEQ = 13;
    public const int AND = 6;
    public const int EOF = -1;
    public const int LITERALSTRING = 14;
    public const int LITERALNUMERIC = 15;
    public const int NEWLINE = 23;
    public const int IDENTIFIER = 18;
    public const int STRINGLITERAL = 19;
    public const int EQUAL = 8;
    public const int OR = 7;
    public const int IIF = 16;
    public const int MEMBERACCESS = 5;
    public const int DOT = 4;
    public const int GREATERTHAN = 11;

    // delegates
    // delegators

    public ExpressionLanguageLexer() 
    {
		InitializeCyclicDFAs();
    }
    public ExpressionLanguageLexer(ICharStream input)
		: this(input, null) {
    }
    public ExpressionLanguageLexer(ICharStream input, RecognizerSharedState state)
		: base(input, state) {
		InitializeCyclicDFAs(); 

    }
    
    override public string GrammarFileName
    {
    	get { return "Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g";} 
    }

    // $ANTLR start "DOT"
    public void mDOT() // throws RecognitionException [2]
    {
    		try
    		{
            int _type = DOT;
    	int _channel = DEFAULT_TOKEN_CHANNEL;
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:9:5: ( '.' )
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:9:7: '.'
            {
            	Match('.'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally 
    	{
        }
    }
    // $ANTLR end "DOT"

    // $ANTLR start "MEMBERACCESS"
    public void mMEMBERACCESS() // throws RecognitionException [2]
    {
    		try
    		{
            int _type = MEMBERACCESS;
    	int _channel = DEFAULT_TOKEN_CHANNEL;
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:10:14: ( 'MemberAccess' )
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:10:16: 'MemberAccess'
            {
            	Match("MemberAccess"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally 
    	{
        }
    }
    // $ANTLR end "MEMBERACCESS"

    // $ANTLR start "AND"
    public void mAND() // throws RecognitionException [2]
    {
    		try
    		{
            int _type = AND;
    	int _channel = DEFAULT_TOKEN_CHANNEL;
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:11:5: ( 'And' )
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:11:7: 'And'
            {
            	Match("And"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally 
    	{
        }
    }
    // $ANTLR end "AND"

    // $ANTLR start "OR"
    public void mOR() // throws RecognitionException [2]
    {
    		try
    		{
            int _type = OR;
    	int _channel = DEFAULT_TOKEN_CHANNEL;
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:12:4: ( 'Or' )
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:12:6: 'Or'
            {
            	Match("Or"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally 
    	{
        }
    }
    // $ANTLR end "OR"

    // $ANTLR start "EQUAL"
    public void mEQUAL() // throws RecognitionException [2]
    {
    		try
    		{
            int _type = EQUAL;
    	int _channel = DEFAULT_TOKEN_CHANNEL;
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:13:7: ( '=' )
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:13:9: '='
            {
            	Match('='); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally 
    	{
        }
    }
    // $ANTLR end "EQUAL"

    // $ANTLR start "DIFFERENT"
    public void mDIFFERENT() // throws RecognitionException [2]
    {
    		try
    		{
            int _type = DIFFERENT;
    	int _channel = DEFAULT_TOKEN_CHANNEL;
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:14:11: ( '<>' )
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:14:13: '<>'
            {
            	Match("<>"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally 
    	{
        }
    }
    // $ANTLR end "DIFFERENT"

    // $ANTLR start "LESSTHAN"
    public void mLESSTHAN() // throws RecognitionException [2]
    {
    		try
    		{
            int _type = LESSTHAN;
    	int _channel = DEFAULT_TOKEN_CHANNEL;
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:15:10: ( '<' )
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:15:12: '<'
            {
            	Match('<'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally 
    	{
        }
    }
    // $ANTLR end "LESSTHAN"

    // $ANTLR start "GREATERTHAN"
    public void mGREATERTHAN() // throws RecognitionException [2]
    {
    		try
    		{
            int _type = GREATERTHAN;
    	int _channel = DEFAULT_TOKEN_CHANNEL;
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:16:13: ( '>' )
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:16:15: '>'
            {
            	Match('>'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally 
    	{
        }
    }
    // $ANTLR end "GREATERTHAN"

    // $ANTLR start "LTEQ"
    public void mLTEQ() // throws RecognitionException [2]
    {
    		try
    		{
            int _type = LTEQ;
    	int _channel = DEFAULT_TOKEN_CHANNEL;
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:17:6: ( '<=' )
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:17:8: '<='
            {
            	Match("<="); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally 
    	{
        }
    }
    // $ANTLR end "LTEQ"

    // $ANTLR start "GTEQ"
    public void mGTEQ() // throws RecognitionException [2]
    {
    		try
    		{
            int _type = GTEQ;
    	int _channel = DEFAULT_TOKEN_CHANNEL;
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:18:6: ( '>=' )
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:18:8: '>='
            {
            	Match(">="); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally 
    	{
        }
    }
    // $ANTLR end "GTEQ"

    // $ANTLR start "LITERALSTRING"
    public void mLITERALSTRING() // throws RecognitionException [2]
    {
    		try
    		{
            int _type = LITERALSTRING;
    	int _channel = DEFAULT_TOKEN_CHANNEL;
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:19:15: ( 'StringLiteral' )
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:19:17: 'StringLiteral'
            {
            	Match("StringLiteral"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally 
    	{
        }
    }
    // $ANTLR end "LITERALSTRING"

    // $ANTLR start "LITERALNUMERIC"
    public void mLITERALNUMERIC() // throws RecognitionException [2]
    {
    		try
    		{
            int _type = LITERALNUMERIC;
    	int _channel = DEFAULT_TOKEN_CHANNEL;
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:20:16: ( 'NumericLiteral' )
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:20:18: 'NumericLiteral'
            {
            	Match("NumericLiteral"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally 
    	{
        }
    }
    // $ANTLR end "LITERALNUMERIC"

    // $ANTLR start "IIF"
    public void mIIF() // throws RecognitionException [2]
    {
    		try
    		{
            int _type = IIF;
    	int _channel = DEFAULT_TOKEN_CHANNEL;
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:21:5: ( 'Iif' )
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:21:7: 'Iif'
            {
            	Match("Iif"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally 
    	{
        }
    }
    // $ANTLR end "IIF"

    // $ANTLR start "LITERALBOOLEAN"
    public void mLITERALBOOLEAN() // throws RecognitionException [2]
    {
    		try
    		{
            int _type = LITERALBOOLEAN;
    	int _channel = DEFAULT_TOKEN_CHANNEL;
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:22:16: ( 'BooleanLiteral' )
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:22:18: 'BooleanLiteral'
            {
            	Match("BooleanLiteral"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally 
    	{
        }
    }
    // $ANTLR end "LITERALBOOLEAN"

    // $ANTLR start "T__25"
    public void mT__25() // throws RecognitionException [2]
    {
    		try
    		{
            int _type = T__25;
    	int _channel = DEFAULT_TOKEN_CHANNEL;
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:23:7: ( '(' )
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:23:9: '('
            {
            	Match('('); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally 
    	{
        }
    }
    // $ANTLR end "T__25"

    // $ANTLR start "T__26"
    public void mT__26() // throws RecognitionException [2]
    {
    		try
    		{
            int _type = T__26;
    	int _channel = DEFAULT_TOKEN_CHANNEL;
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:24:7: ( ')' )
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:24:9: ')'
            {
            	Match(')'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally 
    	{
        }
    }
    // $ANTLR end "T__26"

    // $ANTLR start "T__27"
    public void mT__27() // throws RecognitionException [2]
    {
    		try
    		{
            int _type = T__27;
    	int _channel = DEFAULT_TOKEN_CHANNEL;
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:25:7: ( ',' )
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:25:9: ','
            {
            	Match(','); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally 
    	{
        }
    }
    // $ANTLR end "T__27"

    // $ANTLR start "BOOLEANLITERAL"
    public void mBOOLEANLITERAL() // throws RecognitionException [2]
    {
    		try
    		{
            int _type = BOOLEANLITERAL;
    	int _channel = DEFAULT_TOKEN_CHANNEL;
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:70:3: ( 'True' | 'False' )
            int alt1 = 2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0 == 'T') )
            {
                alt1 = 1;
            }
            else if ( (LA1_0 == 'F') )
            {
                alt1 = 2;
            }
            else 
            {
                NoViableAltException nvae_d1s0 =
                    new NoViableAltException("", 1, 0, input);

                throw nvae_d1s0;
            }
            switch (alt1) 
            {
                case 1 :
                    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:70:5: 'True'
                    {
                    	Match("True"); 


                    }
                    break;
                case 2 :
                    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:70:12: 'False'
                    {
                    	Match("False"); 


                    }
                    break;

            }
            state.type = _type;
            state.channel = _channel;
        }
        finally 
    	{
        }
    }
    // $ANTLR end "BOOLEANLITERAL"

    // $ANTLR start "STRINGLITERAL"
    public void mSTRINGLITERAL() // throws RecognitionException [2]
    {
    		try
    		{
            int _type = STRINGLITERAL;
    	int _channel = DEFAULT_TOKEN_CHANNEL;
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:73:9: ( '\\'' (~ '\\'' )* '\\'' )
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:73:11: '\\'' (~ '\\'' )* '\\''
            {
            	Match('\''); 
            	// Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:73:15: (~ '\\'' )*
            	do 
            	{
            	    int alt2 = 2;
            	    int LA2_0 = input.LA(1);

            	    if ( ((LA2_0 >= '\u0000' && LA2_0 <= '&') || (LA2_0 >= '(' && LA2_0 <= '\uFFFF')) )
            	    {
            	        alt2 = 1;
            	    }


            	    switch (alt2) 
            		{
            			case 1 :
            			    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:73:16: ~ '\\''
            			    {
            			    	if ( (input.LA(1) >= '\u0000' && input.LA(1) <= '&') || (input.LA(1) >= '(' && input.LA(1) <= '\uFFFF') ) 
            			    	{
            			    	    input.Consume();

            			    	}
            			    	else 
            			    	{
            			    	    MismatchedSetException mse = new MismatchedSetException(null,input);
            			    	    Recover(mse);
            			    	    throw mse;}


            			    }
            			    break;

            			default:
            			    goto loop2;
            	    }
            	} while (true);

            	loop2:
            		;	// Stops C# compiler whining that label 'loop2' has no statements

            	Match('\''); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally 
    	{
        }
    }
    // $ANTLR end "STRINGLITERAL"

    // $ANTLR start "NUMERICLITERAL"
    public void mNUMERICLITERAL() // throws RecognitionException [2]
    {
    		try
    		{
            int _type = NUMERICLITERAL;
    	int _channel = DEFAULT_TOKEN_CHANNEL;
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:76:9: ( ( INTEGERLITERAL )* ( DOT ( INTEGERLITERAL ) )? )
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:76:11: ( INTEGERLITERAL )* ( DOT ( INTEGERLITERAL ) )?
            {
            	// Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:76:11: ( INTEGERLITERAL )*
            	do 
            	{
            	    int alt3 = 2;
            	    int LA3_0 = input.LA(1);

            	    if ( ((LA3_0 >= '0' && LA3_0 <= '9')) )
            	    {
            	        alt3 = 1;
            	    }


            	    switch (alt3) 
            		{
            			case 1 :
            			    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:76:12: INTEGERLITERAL
            			    {
            			    	mINTEGERLITERAL(); 

            			    }
            			    break;

            			default:
            			    goto loop3;
            	    }
            	} while (true);

            	loop3:
            		;	// Stops C# compiler whining that label 'loop3' has no statements

            	// Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:76:29: ( DOT ( INTEGERLITERAL ) )?
            	int alt4 = 2;
            	int LA4_0 = input.LA(1);

            	if ( (LA4_0 == '.') )
            	{
            	    alt4 = 1;
            	}
            	switch (alt4) 
            	{
            	    case 1 :
            	        // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:76:31: DOT ( INTEGERLITERAL )
            	        {
            	        	mDOT(); 
            	        	// Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:76:35: ( INTEGERLITERAL )
            	        	// Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:76:37: INTEGERLITERAL
            	        	{
            	        		mINTEGERLITERAL(); 

            	        	}


            	        }
            	        break;

            	}


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally 
    	{
        }
    }
    // $ANTLR end "NUMERICLITERAL"

    // $ANTLR start "INTEGERLITERAL"
    public void mINTEGERLITERAL() // throws RecognitionException [2]
    {
    		try
    		{
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:80:9: ( ( '0' .. '9' ) )
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:80:11: ( '0' .. '9' )
            {
            	// Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:80:11: ( '0' .. '9' )
            	// Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:80:12: '0' .. '9'
            	{
            		MatchRange('0','9'); 

            	}


            }

        }
        finally 
    	{
        }
    }
    // $ANTLR end "INTEGERLITERAL"

    // $ANTLR start "IDENTIFIER"
    public void mIDENTIFIER() // throws RecognitionException [2]
    {
    		try
    		{
            int _type = IDENTIFIER;
    	int _channel = DEFAULT_TOKEN_CHANNEL;
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:83:9: ( ( 'a' .. 'z' | 'A' .. 'Z' | '_' ) ( 'a' .. 'z' | 'A' .. 'Z' | '_' | ( INTEGERLITERAL ) )* )
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:83:11: ( 'a' .. 'z' | 'A' .. 'Z' | '_' ) ( 'a' .. 'z' | 'A' .. 'Z' | '_' | ( INTEGERLITERAL ) )*
            {
            	if ( (input.LA(1) >= 'A' && input.LA(1) <= 'Z') || input.LA(1) == '_' || (input.LA(1) >= 'a' && input.LA(1) <= 'z') ) 
            	{
            	    input.Consume();

            	}
            	else 
            	{
            	    MismatchedSetException mse = new MismatchedSetException(null,input);
            	    Recover(mse);
            	    throw mse;}

            	// Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:83:41: ( 'a' .. 'z' | 'A' .. 'Z' | '_' | ( INTEGERLITERAL ) )*
            	do 
            	{
            	    int alt5 = 5;
            	    switch ( input.LA(1) ) 
            	    {
            	    case 'a':
            	    case 'b':
            	    case 'c':
            	    case 'd':
            	    case 'e':
            	    case 'f':
            	    case 'g':
            	    case 'h':
            	    case 'i':
            	    case 'j':
            	    case 'k':
            	    case 'l':
            	    case 'm':
            	    case 'n':
            	    case 'o':
            	    case 'p':
            	    case 'q':
            	    case 'r':
            	    case 's':
            	    case 't':
            	    case 'u':
            	    case 'v':
            	    case 'w':
            	    case 'x':
            	    case 'y':
            	    case 'z':
            	    	{
            	        alt5 = 1;
            	        }
            	        break;
            	    case 'A':
            	    case 'B':
            	    case 'C':
            	    case 'D':
            	    case 'E':
            	    case 'F':
            	    case 'G':
            	    case 'H':
            	    case 'I':
            	    case 'J':
            	    case 'K':
            	    case 'L':
            	    case 'M':
            	    case 'N':
            	    case 'O':
            	    case 'P':
            	    case 'Q':
            	    case 'R':
            	    case 'S':
            	    case 'T':
            	    case 'U':
            	    case 'V':
            	    case 'W':
            	    case 'X':
            	    case 'Y':
            	    case 'Z':
            	    	{
            	        alt5 = 2;
            	        }
            	        break;
            	    case '_':
            	    	{
            	        alt5 = 3;
            	        }
            	        break;
            	    case '0':
            	    case '1':
            	    case '2':
            	    case '3':
            	    case '4':
            	    case '5':
            	    case '6':
            	    case '7':
            	    case '8':
            	    case '9':
            	    	{
            	        alt5 = 4;
            	        }
            	        break;

            	    }

            	    switch (alt5) 
            		{
            			case 1 :
            			    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:83:43: 'a' .. 'z'
            			    {
            			    	MatchRange('a','z'); 

            			    }
            			    break;
            			case 2 :
            			    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:83:54: 'A' .. 'Z'
            			    {
            			    	MatchRange('A','Z'); 

            			    }
            			    break;
            			case 3 :
            			    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:83:65: '_'
            			    {
            			    	Match('_'); 

            			    }
            			    break;
            			case 4 :
            			    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:83:71: ( INTEGERLITERAL )
            			    {
            			    	// Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:83:71: ( INTEGERLITERAL )
            			    	// Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:83:72: INTEGERLITERAL
            			    	{
            			    		mINTEGERLITERAL(); 

            			    	}


            			    }
            			    break;

            			default:
            			    goto loop5;
            	    }
            	} while (true);

            	loop5:
            		;	// Stops C# compiler whining that label 'loop5' has no statements


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally 
    	{
        }
    }
    // $ANTLR end "IDENTIFIER"

    // $ANTLR start "NEWLINE"
    public void mNEWLINE() // throws RecognitionException [2]
    {
    		try
    		{
            int _type = NEWLINE;
    	int _channel = DEFAULT_TOKEN_CHANNEL;
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:86:3: ( ( ( '\\r' )? '\\n' )+ )
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:86:5: ( ( '\\r' )? '\\n' )+
            {
            	// Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:86:5: ( ( '\\r' )? '\\n' )+
            	int cnt7 = 0;
            	do 
            	{
            	    int alt7 = 2;
            	    int LA7_0 = input.LA(1);

            	    if ( (LA7_0 == '\n' || LA7_0 == '\r') )
            	    {
            	        alt7 = 1;
            	    }


            	    switch (alt7) 
            		{
            			case 1 :
            			    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:86:6: ( '\\r' )? '\\n'
            			    {
            			    	// Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:86:6: ( '\\r' )?
            			    	int alt6 = 2;
            			    	int LA6_0 = input.LA(1);

            			    	if ( (LA6_0 == '\r') )
            			    	{
            			    	    alt6 = 1;
            			    	}
            			    	switch (alt6) 
            			    	{
            			    	    case 1 :
            			    	        // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:86:6: '\\r'
            			    	        {
            			    	        	Match('\r'); 

            			    	        }
            			    	        break;

            			    	}

            			    	Match('\n'); 

            			    }
            			    break;

            			default:
            			    if ( cnt7 >= 1 ) goto loop7;
            		            EarlyExitException eee7 =
            		                new EarlyExitException(7, input);
            		            throw eee7;
            	    }
            	    cnt7++;
            	} while (true);

            	loop7:
            		;	// Stops C# compiler whining that label 'loop7' has no statements

            	 _channel = HIDDEN; 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally 
    	{
        }
    }
    // $ANTLR end "NEWLINE"

    // $ANTLR start "WHITESPACE"
    public void mWHITESPACE() // throws RecognitionException [2]
    {
    		try
    		{
            int _type = WHITESPACE;
    	int _channel = DEFAULT_TOKEN_CHANNEL;
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:89:9: ( ( '\\t' | ' ' )+ )
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:89:11: ( '\\t' | ' ' )+
            {
            	// Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:89:11: ( '\\t' | ' ' )+
            	int cnt8 = 0;
            	do 
            	{
            	    int alt8 = 2;
            	    int LA8_0 = input.LA(1);

            	    if ( (LA8_0 == '\t' || LA8_0 == ' ') )
            	    {
            	        alt8 = 1;
            	    }


            	    switch (alt8) 
            		{
            			case 1 :
            			    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:
            			    {
            			    	if ( input.LA(1) == '\t' || input.LA(1) == ' ' ) 
            			    	{
            			    	    input.Consume();

            			    	}
            			    	else 
            			    	{
            			    	    MismatchedSetException mse = new MismatchedSetException(null,input);
            			    	    Recover(mse);
            			    	    throw mse;}


            			    }
            			    break;

            			default:
            			    if ( cnt8 >= 1 ) goto loop8;
            		            EarlyExitException eee8 =
            		                new EarlyExitException(8, input);
            		            throw eee8;
            	    }
            	    cnt8++;
            	} while (true);

            	loop8:
            		;	// Stops C# compiler whining that label 'loop8' has no statements

            	 _channel = HIDDEN; 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally 
    	{
        }
    }
    // $ANTLR end "WHITESPACE"

    override public void mTokens() // throws RecognitionException 
    {
        // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:1:8: ( DOT | MEMBERACCESS | AND | OR | EQUAL | DIFFERENT | LESSTHAN | GREATERTHAN | LTEQ | GTEQ | LITERALSTRING | LITERALNUMERIC | IIF | LITERALBOOLEAN | T__25 | T__26 | T__27 | BOOLEANLITERAL | STRINGLITERAL | NUMERICLITERAL | IDENTIFIER | NEWLINE | WHITESPACE )
        int alt9 = 23;
        alt9 = dfa9.Predict(input);
        switch (alt9) 
        {
            case 1 :
                // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:1:10: DOT
                {
                	mDOT(); 

                }
                break;
            case 2 :
                // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:1:14: MEMBERACCESS
                {
                	mMEMBERACCESS(); 

                }
                break;
            case 3 :
                // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:1:27: AND
                {
                	mAND(); 

                }
                break;
            case 4 :
                // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:1:31: OR
                {
                	mOR(); 

                }
                break;
            case 5 :
                // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:1:34: EQUAL
                {
                	mEQUAL(); 

                }
                break;
            case 6 :
                // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:1:40: DIFFERENT
                {
                	mDIFFERENT(); 

                }
                break;
            case 7 :
                // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:1:50: LESSTHAN
                {
                	mLESSTHAN(); 

                }
                break;
            case 8 :
                // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:1:59: GREATERTHAN
                {
                	mGREATERTHAN(); 

                }
                break;
            case 9 :
                // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:1:71: LTEQ
                {
                	mLTEQ(); 

                }
                break;
            case 10 :
                // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:1:76: GTEQ
                {
                	mGTEQ(); 

                }
                break;
            case 11 :
                // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:1:81: LITERALSTRING
                {
                	mLITERALSTRING(); 

                }
                break;
            case 12 :
                // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:1:95: LITERALNUMERIC
                {
                	mLITERALNUMERIC(); 

                }
                break;
            case 13 :
                // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:1:110: IIF
                {
                	mIIF(); 

                }
                break;
            case 14 :
                // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:1:114: LITERALBOOLEAN
                {
                	mLITERALBOOLEAN(); 

                }
                break;
            case 15 :
                // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:1:129: T__25
                {
                	mT__25(); 

                }
                break;
            case 16 :
                // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:1:135: T__26
                {
                	mT__26(); 

                }
                break;
            case 17 :
                // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:1:141: T__27
                {
                	mT__27(); 

                }
                break;
            case 18 :
                // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:1:147: BOOLEANLITERAL
                {
                	mBOOLEANLITERAL(); 

                }
                break;
            case 19 :
                // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:1:162: STRINGLITERAL
                {
                	mSTRINGLITERAL(); 

                }
                break;
            case 20 :
                // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:1:176: NUMERICLITERAL
                {
                	mNUMERICLITERAL(); 

                }
                break;
            case 21 :
                // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:1:191: IDENTIFIER
                {
                	mIDENTIFIER(); 

                }
                break;
            case 22 :
                // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:1:202: NEWLINE
                {
                	mNEWLINE(); 

                }
                break;
            case 23 :
                // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:1:210: WHITESPACE
                {
                	mWHITESPACE(); 

                }
                break;

        }

    }


    protected DFA9 dfa9;
	private void InitializeCyclicDFAs()
	{
	    this.dfa9 = new DFA9(this);
	}

    const string DFA9_eotS =
        "\x01\x12\x01\x16\x03\x13\x01\uffff\x01\x1c\x01\x1e\x04\x13\x03"+
        "\uffff\x02\x13\x06\uffff\x02\x13\x01\x27\x05\uffff\x07\x13\x01\x2f"+
        "\x01\uffff\x02\x13\x01\x32\x04\x13\x01\uffff\x02\x13\x01\uffff\x01"+
        "\x13\x01\x3a\x05\x13\x01\uffff\x01\x3a\x18\x13\x01\x58\x03\x13\x01"+
        "\uffff\x01\x5c\x02\x13\x01\uffff\x01\x5f\x01\x60\x02\uffff";
    const string DFA9_eofS =
        "\x61\uffff";
    const string DFA9_minS =
        "\x01\x09\x01\x30\x01\x65\x01\x6e\x01\x72\x01\uffff\x02\x3d\x01"+
        "\x74\x01\x75\x01\x69\x01\x6f\x03\uffff\x01\x72\x01\x61\x06\uffff"+
        "\x01\x6d\x01\x64\x01\x30\x05\uffff\x01\x72\x01\x6d\x01\x66\x01\x6f"+
        "\x01\x75\x01\x6c\x01\x62\x01\x30\x01\uffff\x01\x69\x01\x65\x01\x30"+
        "\x01\x6c\x01\x65\x01\x73\x01\x65\x01\uffff\x01\x6e\x01\x72\x01\uffff"+
        "\x01\x65\x01\x30\x01\x65\x01\x72\x01\x67\x01\x69\x01\x61\x01\uffff"+
        "\x01\x30\x01\x41\x01\x4c\x01\x63\x01\x6e\x01\x63\x01\x69\x02\x4c"+
        "\x01\x63\x01\x74\x02\x69\x02\x65\x02\x74\x01\x73\x01\x72\x02\x65"+
        "\x01\x73\x01\x61\x02\x72\x01\x30\x01\x6c\x02\x61\x01\uffff\x01\x30"+
        "\x02\x6c\x01\uffff\x02\x30\x02\uffff";
    const string DFA9_maxS =
        "\x01\x7a\x01\x39\x01\x65\x01\x6e\x01\x72\x01\uffff\x01\x3e\x01"+
        "\x3d\x01\x74\x01\x75\x01\x69\x01\x6f\x03\uffff\x01\x72\x01\x61\x06"+
        "\uffff\x01\x6d\x01\x64\x01\x7a\x05\uffff\x01\x72\x01\x6d\x01\x66"+
        "\x01\x6f\x01\x75\x01\x6c\x01\x62\x01\x7a\x01\uffff\x01\x69\x01\x65"+
        "\x01\x7a\x01\x6c\x01\x65\x01\x73\x01\x65\x01\uffff\x01\x6e\x01\x72"+
        "\x01\uffff\x01\x65\x01\x7a\x01\x65\x01\x72\x01\x67\x01\x69\x01\x61"+
        "\x01\uffff\x01\x7a\x01\x41\x01\x4c\x01\x63\x01\x6e\x01\x63\x01\x69"+
        "\x02\x4c\x01\x63\x01\x74\x02\x69\x02\x65\x02\x74\x01\x73\x01\x72"+
        "\x02\x65\x01\x73\x01\x61\x02\x72\x01\x7a\x01\x6c\x02\x61\x01\uffff"+
        "\x01\x7a\x02\x6c\x01\uffff\x02\x7a\x02\uffff";
    const string DFA9_acceptS =
        "\x05\uffff\x01\x05\x06\uffff\x01\x0f\x01\x10\x01\x11\x02\uffff"+
        "\x01\x13\x01\x14\x01\x15\x01\x16\x01\x17\x01\x01\x03\uffff\x01\x06"+
        "\x01\x09\x01\x07\x01\x0a\x01\x08\x08\uffff\x01\x04\x07\uffff\x01"+
        "\x03\x02\uffff\x01\x0d\x07\uffff\x01\x12\x1d\uffff\x01\x02\x03\uffff"+
        "\x01\x0b\x02\uffff\x01\x0c\x01\x0e";
    const string DFA9_specialS =
        "\x61\uffff}>";
    static readonly string[] DFA9_transitionS = {
            "\x01\x15\x01\x14\x02\uffff\x01\x14\x12\uffff\x01\x15\x06\uffff"+
            "\x01\x11\x01\x0c\x01\x0d\x02\uffff\x01\x0e\x01\uffff\x01\x01"+
            "\x0d\uffff\x01\x06\x01\x05\x01\x07\x02\uffff\x01\x03\x01\x0b"+
            "\x03\x13\x01\x10\x02\x13\x01\x0a\x03\x13\x01\x02\x01\x09\x01"+
            "\x04\x03\x13\x01\x08\x01\x0f\x06\x13\x04\uffff\x01\x13\x01\uffff"+
            "\x1a\x13",
            "\x0a\x12",
            "\x01\x17",
            "\x01\x18",
            "\x01\x19",
            "",
            "\x01\x1b\x01\x1a",
            "\x01\x1d",
            "\x01\x1f",
            "\x01\x20",
            "\x01\x21",
            "\x01\x22",
            "",
            "",
            "",
            "\x01\x23",
            "\x01\x24",
            "",
            "",
            "",
            "",
            "",
            "",
            "\x01\x25",
            "\x01\x26",
            "\x0a\x13\x07\uffff\x1a\x13\x04\uffff\x01\x13\x01\uffff\x1a"+
            "\x13",
            "",
            "",
            "",
            "",
            "",
            "\x01\x28",
            "\x01\x29",
            "\x01\x2a",
            "\x01\x2b",
            "\x01\x2c",
            "\x01\x2d",
            "\x01\x2e",
            "\x0a\x13\x07\uffff\x1a\x13\x04\uffff\x01\x13\x01\uffff\x1a"+
            "\x13",
            "",
            "\x01\x30",
            "\x01\x31",
            "\x0a\x13\x07\uffff\x1a\x13\x04\uffff\x01\x13\x01\uffff\x1a"+
            "\x13",
            "\x01\x33",
            "\x01\x34",
            "\x01\x35",
            "\x01\x36",
            "",
            "\x01\x37",
            "\x01\x38",
            "",
            "\x01\x39",
            "\x0a\x13\x07\uffff\x1a\x13\x04\uffff\x01\x13\x01\uffff\x1a"+
            "\x13",
            "\x01\x3b",
            "\x01\x3c",
            "\x01\x3d",
            "\x01\x3e",
            "\x01\x3f",
            "",
            "\x0a\x13\x07\uffff\x1a\x13\x04\uffff\x01\x13\x01\uffff\x1a"+
            "\x13",
            "\x01\x40",
            "\x01\x41",
            "\x01\x42",
            "\x01\x43",
            "\x01\x44",
            "\x01\x45",
            "\x01\x46",
            "\x01\x47",
            "\x01\x48",
            "\x01\x49",
            "\x01\x4a",
            "\x01\x4b",
            "\x01\x4c",
            "\x01\x4d",
            "\x01\x4e",
            "\x01\x4f",
            "\x01\x50",
            "\x01\x51",
            "\x01\x52",
            "\x01\x53",
            "\x01\x54",
            "\x01\x55",
            "\x01\x56",
            "\x01\x57",
            "\x0a\x13\x07\uffff\x1a\x13\x04\uffff\x01\x13\x01\uffff\x1a"+
            "\x13",
            "\x01\x59",
            "\x01\x5a",
            "\x01\x5b",
            "",
            "\x0a\x13\x07\uffff\x1a\x13\x04\uffff\x01\x13\x01\uffff\x1a"+
            "\x13",
            "\x01\x5d",
            "\x01\x5e",
            "",
            "\x0a\x13\x07\uffff\x1a\x13\x04\uffff\x01\x13\x01\uffff\x1a"+
            "\x13",
            "\x0a\x13\x07\uffff\x1a\x13\x04\uffff\x01\x13\x01\uffff\x1a"+
            "\x13",
            "",
            ""
    };

    static readonly short[] DFA9_eot = DFA.UnpackEncodedString(DFA9_eotS);
    static readonly short[] DFA9_eof = DFA.UnpackEncodedString(DFA9_eofS);
    static readonly char[] DFA9_min = DFA.UnpackEncodedStringToUnsignedChars(DFA9_minS);
    static readonly char[] DFA9_max = DFA.UnpackEncodedStringToUnsignedChars(DFA9_maxS);
    static readonly short[] DFA9_accept = DFA.UnpackEncodedString(DFA9_acceptS);
    static readonly short[] DFA9_special = DFA.UnpackEncodedString(DFA9_specialS);
    static readonly short[][] DFA9_transition = DFA.UnpackEncodedStringArray(DFA9_transitionS);

    protected class DFA9 : DFA
    {
        public DFA9(BaseRecognizer recognizer)
        {
            this.recognizer = recognizer;
            this.decisionNumber = 9;
            this.eot = DFA9_eot;
            this.eof = DFA9_eof;
            this.min = DFA9_min;
            this.max = DFA9_max;
            this.accept = DFA9_accept;
            this.special = DFA9_special;
            this.transition = DFA9_transition;

        }

        override public string Description
        {
            get { return "1:1: Tokens : ( DOT | MEMBERACCESS | AND | OR | EQUAL | DIFFERENT | LESSTHAN | GREATERTHAN | LTEQ | GTEQ | LITERALSTRING | LITERALNUMERIC | IIF | LITERALBOOLEAN | T__25 | T__26 | T__27 | BOOLEANLITERAL | STRINGLITERAL | NUMERICLITERAL | IDENTIFIER | NEWLINE | WHITESPACE );"; }
        }

    }

 
    
}
}