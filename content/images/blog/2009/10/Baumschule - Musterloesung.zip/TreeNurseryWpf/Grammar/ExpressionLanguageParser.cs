// $ANTLR 3.1.3 Mar 17, 2009 19:23:44 Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g 2009-09-20 14:12:54

// The variable 'variable' is assigned but its value is never used.
#pragma warning disable 168, 219
// Unreachable code detected.
#pragma warning disable 162


using System;
using Antlr.Runtime;
using IList 		= System.Collections.IList;
using ArrayList 	= System.Collections.ArrayList;
using Stack 		= Antlr.Runtime.Collections.StackList;

using IDictionary	= System.Collections.IDictionary;
using Hashtable 	= System.Collections.Hashtable;

using Antlr.Runtime.Tree;

namespace  TreeNurseryWpf.Grammar 
{
public partial class ExpressionLanguageParser : Parser
{
    public static readonly string[] tokenNames = new string[] 
	{
        "<invalid>", 
		"<EOR>", 
		"<DOWN>", 
		"<UP>", 
		"DOT", 
		"MEMBERACCESS", 
		"AND", 
		"OR", 
		"EQUAL", 
		"DIFFERENT", 
		"LESSTHAN", 
		"GREATERTHAN", 
		"LTEQ", 
		"GTEQ", 
		"LITERALSTRING", 
		"LITERALNUMERIC", 
		"IIF", 
		"LITERALBOOLEAN", 
		"IDENTIFIER", 
		"STRINGLITERAL", 
		"BOOLEANLITERAL", 
		"NUMERICLITERAL", 
		"INTEGERLITERAL", 
		"NEWLINE", 
		"WHITESPACE", 
		"'('", 
		"')'", 
		"','"
    };

    public const int LESSTHAN = 10;
    public const int LITERALBOOLEAN = 17;
    public const int INTEGERLITERAL = 22;
    public const int T__27 = 27;
    public const int T__26 = 26;
    public const int T__25 = 25;
    public const int NUMERICLITERAL = 21;
    public const int LTEQ = 12;
    public const int BOOLEANLITERAL = 20;
    public const int WHITESPACE = 24;
    public const int DIFFERENT = 9;
    public const int GTEQ = 13;
    public const int AND = 6;
    public const int EOF = -1;
    public const int LITERALSTRING = 14;
    public const int LITERALNUMERIC = 15;
    public const int NEWLINE = 23;
    public const int STRINGLITERAL = 19;
    public const int IDENTIFIER = 18;
    public const int EQUAL = 8;
    public const int OR = 7;
    public const int IIF = 16;
    public const int MEMBERACCESS = 5;
    public const int DOT = 4;
    public const int GREATERTHAN = 11;

    // delegates
    // delegators



        public ExpressionLanguageParser(ITokenStream input)
    		: this(input, new RecognizerSharedState()) {
        }

        public ExpressionLanguageParser(ITokenStream input, RecognizerSharedState state)
    		: base(input, state) {
            InitializeCyclicDFAs();
            this.state.ruleMemo = new Hashtable[27+1];
             
             
        }
        
    protected ITreeAdaptor adaptor = new CommonTreeAdaptor();

    public ITreeAdaptor TreeAdaptor
    {
        get { return this.adaptor; }
        set {
    	this.adaptor = value;
    	}
    }

    override public string[] TokenNames {
		get { return ExpressionLanguageParser.tokenNames; }
    }

    override public string GrammarFileName {
		get { return "Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g"; }
    }


    public class conditionalOrExpression_return : ParserRuleReturnScope
    {
        private object tree;
        override public object Tree
        {
        	get { return tree; }
        	set { tree = (object) value; }
        }
    };

    // $ANTLR start "conditionalOrExpression"
    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:30:1: conditionalOrExpression : conditionalAndExpression ( OR conditionalAndExpression )* ;
    public ExpressionLanguageParser.conditionalOrExpression_return conditionalOrExpression() // throws RecognitionException [1]
    {   
        ExpressionLanguageParser.conditionalOrExpression_return retval = new ExpressionLanguageParser.conditionalOrExpression_return();
        retval.Start = input.LT(1);
        int conditionalOrExpression_StartIndex = input.Index();
        object root_0 = null;

        IToken OR2 = null;
        ExpressionLanguageParser.conditionalAndExpression_return conditionalAndExpression1 = default(ExpressionLanguageParser.conditionalAndExpression_return);

        ExpressionLanguageParser.conditionalAndExpression_return conditionalAndExpression3 = default(ExpressionLanguageParser.conditionalAndExpression_return);


        object OR2_tree=null;

        try 
    	{
    	    if ( (state.backtracking > 0) && AlreadyParsedRule(input, 1) ) 
    	    {
    	    	return retval; 
    	    }
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:31:5: ( conditionalAndExpression ( OR conditionalAndExpression )* )
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:31:10: conditionalAndExpression ( OR conditionalAndExpression )*
            {
            	root_0 = (object)adaptor.GetNilNode();

            	PushFollow(FOLLOW_conditionalAndExpression_in_conditionalOrExpression202);
            	conditionalAndExpression1 = conditionalAndExpression();
            	state.followingStackPointer--;
            	if (state.failed) return retval;
            	if ( state.backtracking == 0 ) adaptor.AddChild(root_0, conditionalAndExpression1.Tree);
            	// Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:31:35: ( OR conditionalAndExpression )*
            	do 
            	{
            	    int alt1 = 2;
            	    int LA1_0 = input.LA(1);

            	    if ( (LA1_0 == OR) )
            	    {
            	        alt1 = 1;
            	    }


            	    switch (alt1) 
            		{
            			case 1 :
            			    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:31:37: OR conditionalAndExpression
            			    {
            			    	OR2=(IToken)Match(input,OR,FOLLOW_OR_in_conditionalOrExpression206); if (state.failed) return retval;
            			    	if ( state.backtracking == 0 )
            			    	{OR2_tree = (object)adaptor.Create(OR2);
            			    		root_0 = (object)adaptor.BecomeRoot(OR2_tree, root_0);
            			    	}
            			    	PushFollow(FOLLOW_conditionalAndExpression_in_conditionalOrExpression209);
            			    	conditionalAndExpression3 = conditionalAndExpression();
            			    	state.followingStackPointer--;
            			    	if (state.failed) return retval;
            			    	if ( state.backtracking == 0 ) adaptor.AddChild(root_0, conditionalAndExpression3.Tree);

            			    }
            			    break;

            			default:
            			    goto loop1;
            	    }
            	} while (true);

            	loop1:
            		;	// Stops C# compiler whining that label 'loop1' has no statements


            }

            retval.Stop = input.LT(-1);

            if ( (state.backtracking==0) )
            {	retval.Tree = (object)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, (IToken) retval.Start, (IToken) retval.Stop);}
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
    	// Conversion of the second argument necessary, but harmless
    	retval.Tree = (object)adaptor.ErrorNode(input, (IToken) retval.Start, input.LT(-1), re);

        }
        finally 
    	{
            if ( state.backtracking > 0 ) 
            {
            	Memoize(input, 1, conditionalOrExpression_StartIndex); 
            }
        }
        return retval;
    }
    // $ANTLR end "conditionalOrExpression"

    public class conditionalAndExpression_return : ParserRuleReturnScope
    {
        private object tree;
        override public object Tree
        {
        	get { return tree; }
        	set { tree = (object) value; }
        }
    };

    // $ANTLR start "conditionalAndExpression"
    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:33:1: conditionalAndExpression : equalityExpression ( AND equalityExpression )* ;
    public ExpressionLanguageParser.conditionalAndExpression_return conditionalAndExpression() // throws RecognitionException [1]
    {   
        ExpressionLanguageParser.conditionalAndExpression_return retval = new ExpressionLanguageParser.conditionalAndExpression_return();
        retval.Start = input.LT(1);
        int conditionalAndExpression_StartIndex = input.Index();
        object root_0 = null;

        IToken AND5 = null;
        ExpressionLanguageParser.equalityExpression_return equalityExpression4 = default(ExpressionLanguageParser.equalityExpression_return);

        ExpressionLanguageParser.equalityExpression_return equalityExpression6 = default(ExpressionLanguageParser.equalityExpression_return);


        object AND5_tree=null;

        try 
    	{
    	    if ( (state.backtracking > 0) && AlreadyParsedRule(input, 2) ) 
    	    {
    	    	return retval; 
    	    }
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:34:5: ( equalityExpression ( AND equalityExpression )* )
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:34:10: equalityExpression ( AND equalityExpression )*
            {
            	root_0 = (object)adaptor.GetNilNode();

            	PushFollow(FOLLOW_equalityExpression_in_conditionalAndExpression227);
            	equalityExpression4 = equalityExpression();
            	state.followingStackPointer--;
            	if (state.failed) return retval;
            	if ( state.backtracking == 0 ) adaptor.AddChild(root_0, equalityExpression4.Tree);
            	// Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:34:29: ( AND equalityExpression )*
            	do 
            	{
            	    int alt2 = 2;
            	    int LA2_0 = input.LA(1);

            	    if ( (LA2_0 == AND) )
            	    {
            	        alt2 = 1;
            	    }


            	    switch (alt2) 
            		{
            			case 1 :
            			    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:34:31: AND equalityExpression
            			    {
            			    	AND5=(IToken)Match(input,AND,FOLLOW_AND_in_conditionalAndExpression231); if (state.failed) return retval;
            			    	if ( state.backtracking == 0 )
            			    	{AND5_tree = (object)adaptor.Create(AND5);
            			    		root_0 = (object)adaptor.BecomeRoot(AND5_tree, root_0);
            			    	}
            			    	PushFollow(FOLLOW_equalityExpression_in_conditionalAndExpression234);
            			    	equalityExpression6 = equalityExpression();
            			    	state.followingStackPointer--;
            			    	if (state.failed) return retval;
            			    	if ( state.backtracking == 0 ) adaptor.AddChild(root_0, equalityExpression6.Tree);

            			    }
            			    break;

            			default:
            			    goto loop2;
            	    }
            	} while (true);

            	loop2:
            		;	// Stops C# compiler whining that label 'loop2' has no statements


            }

            retval.Stop = input.LT(-1);

            if ( (state.backtracking==0) )
            {	retval.Tree = (object)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, (IToken) retval.Start, (IToken) retval.Stop);}
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
    	// Conversion of the second argument necessary, but harmless
    	retval.Tree = (object)adaptor.ErrorNode(input, (IToken) retval.Start, input.LT(-1), re);

        }
        finally 
    	{
            if ( state.backtracking > 0 ) 
            {
            	Memoize(input, 2, conditionalAndExpression_StartIndex); 
            }
        }
        return retval;
    }
    // $ANTLR end "conditionalAndExpression"

    public class equalityExpression_return : ParserRuleReturnScope
    {
        private object tree;
        override public object Tree
        {
        	get { return tree; }
        	set { tree = (object) value; }
        }
    };

    // $ANTLR start "equalityExpression"
    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:36:1: equalityExpression : relationalExpression ( ( EQUAL | DIFFERENT ) relationalExpression )* ;
    public ExpressionLanguageParser.equalityExpression_return equalityExpression() // throws RecognitionException [1]
    {   
        ExpressionLanguageParser.equalityExpression_return retval = new ExpressionLanguageParser.equalityExpression_return();
        retval.Start = input.LT(1);
        int equalityExpression_StartIndex = input.Index();
        object root_0 = null;

        IToken EQUAL8 = null;
        IToken DIFFERENT9 = null;
        ExpressionLanguageParser.relationalExpression_return relationalExpression7 = default(ExpressionLanguageParser.relationalExpression_return);

        ExpressionLanguageParser.relationalExpression_return relationalExpression10 = default(ExpressionLanguageParser.relationalExpression_return);


        object EQUAL8_tree=null;
        object DIFFERENT9_tree=null;

        try 
    	{
    	    if ( (state.backtracking > 0) && AlreadyParsedRule(input, 3) ) 
    	    {
    	    	return retval; 
    	    }
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:37:5: ( relationalExpression ( ( EQUAL | DIFFERENT ) relationalExpression )* )
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:37:10: relationalExpression ( ( EQUAL | DIFFERENT ) relationalExpression )*
            {
            	root_0 = (object)adaptor.GetNilNode();

            	PushFollow(FOLLOW_relationalExpression_in_equalityExpression252);
            	relationalExpression7 = relationalExpression();
            	state.followingStackPointer--;
            	if (state.failed) return retval;
            	if ( state.backtracking == 0 ) adaptor.AddChild(root_0, relationalExpression7.Tree);
            	// Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:37:31: ( ( EQUAL | DIFFERENT ) relationalExpression )*
            	do 
            	{
            	    int alt4 = 2;
            	    int LA4_0 = input.LA(1);

            	    if ( ((LA4_0 >= EQUAL && LA4_0 <= DIFFERENT)) )
            	    {
            	        alt4 = 1;
            	    }


            	    switch (alt4) 
            		{
            			case 1 :
            			    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:37:33: ( EQUAL | DIFFERENT ) relationalExpression
            			    {
            			    	// Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:37:33: ( EQUAL | DIFFERENT )
            			    	int alt3 = 2;
            			    	int LA3_0 = input.LA(1);

            			    	if ( (LA3_0 == EQUAL) )
            			    	{
            			    	    alt3 = 1;
            			    	}
            			    	else if ( (LA3_0 == DIFFERENT) )
            			    	{
            			    	    alt3 = 2;
            			    	}
            			    	else 
            			    	{
            			    	    if ( state.backtracking > 0 ) {state.failed = true; return retval;}
            			    	    NoViableAltException nvae_d3s0 =
            			    	        new NoViableAltException("", 3, 0, input);

            			    	    throw nvae_d3s0;
            			    	}
            			    	switch (alt3) 
            			    	{
            			    	    case 1 :
            			    	        // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:37:34: EQUAL
            			    	        {
            			    	        	EQUAL8=(IToken)Match(input,EQUAL,FOLLOW_EQUAL_in_equalityExpression257); if (state.failed) return retval;
            			    	        	if ( state.backtracking == 0 )
            			    	        	{EQUAL8_tree = (object)adaptor.Create(EQUAL8);
            			    	        		root_0 = (object)adaptor.BecomeRoot(EQUAL8_tree, root_0);
            			    	        	}

            			    	        }
            			    	        break;
            			    	    case 2 :
            			    	        // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:37:43: DIFFERENT
            			    	        {
            			    	        	DIFFERENT9=(IToken)Match(input,DIFFERENT,FOLLOW_DIFFERENT_in_equalityExpression262); if (state.failed) return retval;
            			    	        	if ( state.backtracking == 0 )
            			    	        	{DIFFERENT9_tree = (object)adaptor.Create(DIFFERENT9);
            			    	        		root_0 = (object)adaptor.BecomeRoot(DIFFERENT9_tree, root_0);
            			    	        	}

            			    	        }
            			    	        break;

            			    	}

            			    	PushFollow(FOLLOW_relationalExpression_in_equalityExpression266);
            			    	relationalExpression10 = relationalExpression();
            			    	state.followingStackPointer--;
            			    	if (state.failed) return retval;
            			    	if ( state.backtracking == 0 ) adaptor.AddChild(root_0, relationalExpression10.Tree);

            			    }
            			    break;

            			default:
            			    goto loop4;
            	    }
            	} while (true);

            	loop4:
            		;	// Stops C# compiler whining that label 'loop4' has no statements


            }

            retval.Stop = input.LT(-1);

            if ( (state.backtracking==0) )
            {	retval.Tree = (object)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, (IToken) retval.Start, (IToken) retval.Stop);}
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
    	// Conversion of the second argument necessary, but harmless
    	retval.Tree = (object)adaptor.ErrorNode(input, (IToken) retval.Start, input.LT(-1), re);

        }
        finally 
    	{
            if ( state.backtracking > 0 ) 
            {
            	Memoize(input, 3, equalityExpression_StartIndex); 
            }
        }
        return retval;
    }
    // $ANTLR end "equalityExpression"

    public class relationalExpression_return : ParserRuleReturnScope
    {
        private object tree;
        override public object Tree
        {
        	get { return tree; }
        	set { tree = (object) value; }
        }
    };

    // $ANTLR start "relationalExpression"
    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:39:1: relationalExpression : atom ( ( LESSTHAN | LTEQ | GREATERTHAN | GTEQ ) atom )* ;
    public ExpressionLanguageParser.relationalExpression_return relationalExpression() // throws RecognitionException [1]
    {   
        ExpressionLanguageParser.relationalExpression_return retval = new ExpressionLanguageParser.relationalExpression_return();
        retval.Start = input.LT(1);
        int relationalExpression_StartIndex = input.Index();
        object root_0 = null;

        IToken LESSTHAN12 = null;
        IToken LTEQ13 = null;
        IToken GREATERTHAN14 = null;
        IToken GTEQ15 = null;
        ExpressionLanguageParser.atom_return atom11 = default(ExpressionLanguageParser.atom_return);

        ExpressionLanguageParser.atom_return atom16 = default(ExpressionLanguageParser.atom_return);


        object LESSTHAN12_tree=null;
        object LTEQ13_tree=null;
        object GREATERTHAN14_tree=null;
        object GTEQ15_tree=null;

        try 
    	{
    	    if ( (state.backtracking > 0) && AlreadyParsedRule(input, 4) ) 
    	    {
    	    	return retval; 
    	    }
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:40:5: ( atom ( ( LESSTHAN | LTEQ | GREATERTHAN | GTEQ ) atom )* )
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:40:10: atom ( ( LESSTHAN | LTEQ | GREATERTHAN | GTEQ ) atom )*
            {
            	root_0 = (object)adaptor.GetNilNode();

            	PushFollow(FOLLOW_atom_in_relationalExpression283);
            	atom11 = atom();
            	state.followingStackPointer--;
            	if (state.failed) return retval;
            	if ( state.backtracking == 0 ) adaptor.AddChild(root_0, atom11.Tree);
            	// Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:40:15: ( ( LESSTHAN | LTEQ | GREATERTHAN | GTEQ ) atom )*
            	do 
            	{
            	    int alt6 = 2;
            	    int LA6_0 = input.LA(1);

            	    if ( ((LA6_0 >= LESSTHAN && LA6_0 <= GTEQ)) )
            	    {
            	        alt6 = 1;
            	    }


            	    switch (alt6) 
            		{
            			case 1 :
            			    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:40:17: ( LESSTHAN | LTEQ | GREATERTHAN | GTEQ ) atom
            			    {
            			    	// Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:40:17: ( LESSTHAN | LTEQ | GREATERTHAN | GTEQ )
            			    	int alt5 = 4;
            			    	switch ( input.LA(1) ) 
            			    	{
            			    	case LESSTHAN:
            			    		{
            			    	    alt5 = 1;
            			    	    }
            			    	    break;
            			    	case LTEQ:
            			    		{
            			    	    alt5 = 2;
            			    	    }
            			    	    break;
            			    	case GREATERTHAN:
            			    		{
            			    	    alt5 = 3;
            			    	    }
            			    	    break;
            			    	case GTEQ:
            			    		{
            			    	    alt5 = 4;
            			    	    }
            			    	    break;
            			    		default:
            			    		    if ( state.backtracking > 0 ) {state.failed = true; return retval;}
            			    		    NoViableAltException nvae_d5s0 =
            			    		        new NoViableAltException("", 5, 0, input);

            			    		    throw nvae_d5s0;
            			    	}

            			    	switch (alt5) 
            			    	{
            			    	    case 1 :
            			    	        // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:40:18: LESSTHAN
            			    	        {
            			    	        	LESSTHAN12=(IToken)Match(input,LESSTHAN,FOLLOW_LESSTHAN_in_relationalExpression288); if (state.failed) return retval;
            			    	        	if ( state.backtracking == 0 )
            			    	        	{LESSTHAN12_tree = (object)adaptor.Create(LESSTHAN12);
            			    	        		root_0 = (object)adaptor.BecomeRoot(LESSTHAN12_tree, root_0);
            			    	        	}

            			    	        }
            			    	        break;
            			    	    case 2 :
            			    	        // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:40:30: LTEQ
            			    	        {
            			    	        	LTEQ13=(IToken)Match(input,LTEQ,FOLLOW_LTEQ_in_relationalExpression293); if (state.failed) return retval;
            			    	        	if ( state.backtracking == 0 )
            			    	        	{LTEQ13_tree = (object)adaptor.Create(LTEQ13);
            			    	        		root_0 = (object)adaptor.BecomeRoot(LTEQ13_tree, root_0);
            			    	        	}

            			    	        }
            			    	        break;
            			    	    case 3 :
            			    	        // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:40:38: GREATERTHAN
            			    	        {
            			    	        	GREATERTHAN14=(IToken)Match(input,GREATERTHAN,FOLLOW_GREATERTHAN_in_relationalExpression298); if (state.failed) return retval;
            			    	        	if ( state.backtracking == 0 )
            			    	        	{GREATERTHAN14_tree = (object)adaptor.Create(GREATERTHAN14);
            			    	        		root_0 = (object)adaptor.BecomeRoot(GREATERTHAN14_tree, root_0);
            			    	        	}

            			    	        }
            			    	        break;
            			    	    case 4 :
            			    	        // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:40:53: GTEQ
            			    	        {
            			    	        	GTEQ15=(IToken)Match(input,GTEQ,FOLLOW_GTEQ_in_relationalExpression303); if (state.failed) return retval;
            			    	        	if ( state.backtracking == 0 )
            			    	        	{GTEQ15_tree = (object)adaptor.Create(GTEQ15);
            			    	        		root_0 = (object)adaptor.BecomeRoot(GTEQ15_tree, root_0);
            			    	        	}

            			    	        }
            			    	        break;

            			    	}

            			    	PushFollow(FOLLOW_atom_in_relationalExpression307);
            			    	atom16 = atom();
            			    	state.followingStackPointer--;
            			    	if (state.failed) return retval;
            			    	if ( state.backtracking == 0 ) adaptor.AddChild(root_0, atom16.Tree);

            			    }
            			    break;

            			default:
            			    goto loop6;
            	    }
            	} while (true);

            	loop6:
            		;	// Stops C# compiler whining that label 'loop6' has no statements


            }

            retval.Stop = input.LT(-1);

            if ( (state.backtracking==0) )
            {	retval.Tree = (object)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, (IToken) retval.Start, (IToken) retval.Stop);}
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
    	// Conversion of the second argument necessary, but harmless
    	retval.Tree = (object)adaptor.ErrorNode(input, (IToken) retval.Start, input.LT(-1), re);

        }
        finally 
    	{
            if ( state.backtracking > 0 ) 
            {
            	Memoize(input, 4, relationalExpression_StartIndex); 
            }
        }
        return retval;
    }
    // $ANTLR end "relationalExpression"

    public class atom_return : ParserRuleReturnScope
    {
        private object tree;
        override public object Tree
        {
        	get { return tree; }
        	set { tree = (object) value; }
        }
    };

    // $ANTLR start "atom"
    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:42:1: atom : ( '(' conditionalOrExpression ')' | functionCall | memberAccess | literal );
    public ExpressionLanguageParser.atom_return atom() // throws RecognitionException [1]
    {   
        ExpressionLanguageParser.atom_return retval = new ExpressionLanguageParser.atom_return();
        retval.Start = input.LT(1);
        int atom_StartIndex = input.Index();
        object root_0 = null;

        IToken char_literal17 = null;
        IToken char_literal19 = null;
        ExpressionLanguageParser.conditionalOrExpression_return conditionalOrExpression18 = default(ExpressionLanguageParser.conditionalOrExpression_return);

        ExpressionLanguageParser.functionCall_return functionCall20 = default(ExpressionLanguageParser.functionCall_return);

        ExpressionLanguageParser.memberAccess_return memberAccess21 = default(ExpressionLanguageParser.memberAccess_return);

        ExpressionLanguageParser.literal_return literal22 = default(ExpressionLanguageParser.literal_return);


        object char_literal17_tree=null;
        object char_literal19_tree=null;

        try 
    	{
    	    if ( (state.backtracking > 0) && AlreadyParsedRule(input, 5) ) 
    	    {
    	    	return retval; 
    	    }
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:43:3: ( '(' conditionalOrExpression ')' | functionCall | memberAccess | literal )
            int alt7 = 4;
            switch ( input.LA(1) ) 
            {
            case 25:
            	{
                alt7 = 1;
                }
                break;
            case IIF:
            	{
                alt7 = 2;
                }
                break;
            case IDENTIFIER:
            	{
                alt7 = 3;
                }
                break;
            case STRINGLITERAL:
            case BOOLEANLITERAL:
            case NUMERICLITERAL:
            	{
                alt7 = 4;
                }
                break;
            	default:
            	    if ( state.backtracking > 0 ) {state.failed = true; return retval;}
            	    NoViableAltException nvae_d7s0 =
            	        new NoViableAltException("", 7, 0, input);

            	    throw nvae_d7s0;
            }

            switch (alt7) 
            {
                case 1 :
                    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:43:5: '(' conditionalOrExpression ')'
                    {
                    	root_0 = (object)adaptor.GetNilNode();

                    	char_literal17=(IToken)Match(input,25,FOLLOW_25_in_atom319); if (state.failed) return retval;
                    	PushFollow(FOLLOW_conditionalOrExpression_in_atom322);
                    	conditionalOrExpression18 = conditionalOrExpression();
                    	state.followingStackPointer--;
                    	if (state.failed) return retval;
                    	if ( state.backtracking == 0 ) adaptor.AddChild(root_0, conditionalOrExpression18.Tree);
                    	char_literal19=(IToken)Match(input,26,FOLLOW_26_in_atom324); if (state.failed) return retval;

                    }
                    break;
                case 2 :
                    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:44:5: functionCall
                    {
                    	root_0 = (object)adaptor.GetNilNode();

                    	PushFollow(FOLLOW_functionCall_in_atom331);
                    	functionCall20 = functionCall();
                    	state.followingStackPointer--;
                    	if (state.failed) return retval;
                    	if ( state.backtracking == 0 ) adaptor.AddChild(root_0, functionCall20.Tree);

                    }
                    break;
                case 3 :
                    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:45:5: memberAccess
                    {
                    	root_0 = (object)adaptor.GetNilNode();

                    	PushFollow(FOLLOW_memberAccess_in_atom337);
                    	memberAccess21 = memberAccess();
                    	state.followingStackPointer--;
                    	if (state.failed) return retval;
                    	if ( state.backtracking == 0 ) adaptor.AddChild(root_0, memberAccess21.Tree);

                    }
                    break;
                case 4 :
                    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:46:5: literal
                    {
                    	root_0 = (object)adaptor.GetNilNode();

                    	PushFollow(FOLLOW_literal_in_atom343);
                    	literal22 = literal();
                    	state.followingStackPointer--;
                    	if (state.failed) return retval;
                    	if ( state.backtracking == 0 ) adaptor.AddChild(root_0, literal22.Tree);

                    }
                    break;

            }
            retval.Stop = input.LT(-1);

            if ( (state.backtracking==0) )
            {	retval.Tree = (object)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, (IToken) retval.Start, (IToken) retval.Stop);}
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
    	// Conversion of the second argument necessary, but harmless
    	retval.Tree = (object)adaptor.ErrorNode(input, (IToken) retval.Start, input.LT(-1), re);

        }
        finally 
    	{
            if ( state.backtracking > 0 ) 
            {
            	Memoize(input, 5, atom_StartIndex); 
            }
        }
        return retval;
    }
    // $ANTLR end "atom"

    public class expression_return : ParserRuleReturnScope
    {
        private object tree;
        override public object Tree
        {
        	get { return tree; }
        	set { tree = (object) value; }
        }
    };

    // $ANTLR start "expression"
    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:48:1: expression : ( conditionalOrExpression | functionCall | parenthesizedExpression | memberAccess | literal );
    public ExpressionLanguageParser.expression_return expression() // throws RecognitionException [1]
    {   
        ExpressionLanguageParser.expression_return retval = new ExpressionLanguageParser.expression_return();
        retval.Start = input.LT(1);
        int expression_StartIndex = input.Index();
        object root_0 = null;

        ExpressionLanguageParser.conditionalOrExpression_return conditionalOrExpression23 = default(ExpressionLanguageParser.conditionalOrExpression_return);

        ExpressionLanguageParser.functionCall_return functionCall24 = default(ExpressionLanguageParser.functionCall_return);

        ExpressionLanguageParser.parenthesizedExpression_return parenthesizedExpression25 = default(ExpressionLanguageParser.parenthesizedExpression_return);

        ExpressionLanguageParser.memberAccess_return memberAccess26 = default(ExpressionLanguageParser.memberAccess_return);

        ExpressionLanguageParser.literal_return literal27 = default(ExpressionLanguageParser.literal_return);



        try 
    	{
    	    if ( (state.backtracking > 0) && AlreadyParsedRule(input, 6) ) 
    	    {
    	    	return retval; 
    	    }
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:49:9: ( conditionalOrExpression | functionCall | parenthesizedExpression | memberAccess | literal )
            int alt8 = 5;
            alt8 = dfa8.Predict(input);
            switch (alt8) 
            {
                case 1 :
                    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:49:11: conditionalOrExpression
                    {
                    	root_0 = (object)adaptor.GetNilNode();

                    	PushFollow(FOLLOW_conditionalOrExpression_in_expression360);
                    	conditionalOrExpression23 = conditionalOrExpression();
                    	state.followingStackPointer--;
                    	if (state.failed) return retval;
                    	if ( state.backtracking == 0 ) adaptor.AddChild(root_0, conditionalOrExpression23.Tree);

                    }
                    break;
                case 2 :
                    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:50:11: functionCall
                    {
                    	root_0 = (object)adaptor.GetNilNode();

                    	PushFollow(FOLLOW_functionCall_in_expression373);
                    	functionCall24 = functionCall();
                    	state.followingStackPointer--;
                    	if (state.failed) return retval;
                    	if ( state.backtracking == 0 ) adaptor.AddChild(root_0, functionCall24.Tree);

                    }
                    break;
                case 3 :
                    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:51:11: parenthesizedExpression
                    {
                    	root_0 = (object)adaptor.GetNilNode();

                    	PushFollow(FOLLOW_parenthesizedExpression_in_expression386);
                    	parenthesizedExpression25 = parenthesizedExpression();
                    	state.followingStackPointer--;
                    	if (state.failed) return retval;
                    	if ( state.backtracking == 0 ) adaptor.AddChild(root_0, parenthesizedExpression25.Tree);

                    }
                    break;
                case 4 :
                    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:52:11: memberAccess
                    {
                    	root_0 = (object)adaptor.GetNilNode();

                    	PushFollow(FOLLOW_memberAccess_in_expression399);
                    	memberAccess26 = memberAccess();
                    	state.followingStackPointer--;
                    	if (state.failed) return retval;
                    	if ( state.backtracking == 0 ) adaptor.AddChild(root_0, memberAccess26.Tree);

                    }
                    break;
                case 5 :
                    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:53:11: literal
                    {
                    	root_0 = (object)adaptor.GetNilNode();

                    	PushFollow(FOLLOW_literal_in_expression412);
                    	literal27 = literal();
                    	state.followingStackPointer--;
                    	if (state.failed) return retval;
                    	if ( state.backtracking == 0 ) adaptor.AddChild(root_0, literal27.Tree);

                    }
                    break;

            }
            retval.Stop = input.LT(-1);

            if ( (state.backtracking==0) )
            {	retval.Tree = (object)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, (IToken) retval.Start, (IToken) retval.Stop);}
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
    	// Conversion of the second argument necessary, but harmless
    	retval.Tree = (object)adaptor.ErrorNode(input, (IToken) retval.Start, input.LT(-1), re);

        }
        finally 
    	{
            if ( state.backtracking > 0 ) 
            {
            	Memoize(input, 6, expression_StartIndex); 
            }
        }
        return retval;
    }
    // $ANTLR end "expression"

    public class parenthesizedExpression_return : ParserRuleReturnScope
    {
        private object tree;
        override public object Tree
        {
        	get { return tree; }
        	set { tree = (object) value; }
        }
    };

    // $ANTLR start "parenthesizedExpression"
    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:55:1: parenthesizedExpression : '(' expression ')' ;
    public ExpressionLanguageParser.parenthesizedExpression_return parenthesizedExpression() // throws RecognitionException [1]
    {   
        ExpressionLanguageParser.parenthesizedExpression_return retval = new ExpressionLanguageParser.parenthesizedExpression_return();
        retval.Start = input.LT(1);
        int parenthesizedExpression_StartIndex = input.Index();
        object root_0 = null;

        IToken char_literal28 = null;
        IToken char_literal30 = null;
        ExpressionLanguageParser.expression_return expression29 = default(ExpressionLanguageParser.expression_return);


        object char_literal28_tree=null;
        object char_literal30_tree=null;

        try 
    	{
    	    if ( (state.backtracking > 0) && AlreadyParsedRule(input, 7) ) 
    	    {
    	    	return retval; 
    	    }
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:56:3: ( '(' expression ')' )
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:56:4: '(' expression ')'
            {
            	root_0 = (object)adaptor.GetNilNode();

            	char_literal28=(IToken)Match(input,25,FOLLOW_25_in_parenthesizedExpression429); if (state.failed) return retval;
            	PushFollow(FOLLOW_expression_in_parenthesizedExpression432);
            	expression29 = expression();
            	state.followingStackPointer--;
            	if (state.failed) return retval;
            	if ( state.backtracking == 0 ) adaptor.AddChild(root_0, expression29.Tree);
            	char_literal30=(IToken)Match(input,26,FOLLOW_26_in_parenthesizedExpression434); if (state.failed) return retval;

            }

            retval.Stop = input.LT(-1);

            if ( (state.backtracking==0) )
            {	retval.Tree = (object)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, (IToken) retval.Start, (IToken) retval.Stop);}
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
    	// Conversion of the second argument necessary, but harmless
    	retval.Tree = (object)adaptor.ErrorNode(input, (IToken) retval.Start, input.LT(-1), re);

        }
        finally 
    	{
            if ( state.backtracking > 0 ) 
            {
            	Memoize(input, 7, parenthesizedExpression_StartIndex); 
            }
        }
        return retval;
    }
    // $ANTLR end "parenthesizedExpression"

    public class memberAccess_return : ParserRuleReturnScope
    {
        private object tree;
        override public object Tree
        {
        	get { return tree; }
        	set { tree = (object) value; }
        }
    };

    // $ANTLR start "memberAccess"
    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:58:1: memberAccess : id= IDENTIFIER -> ^( MEMBERACCESS[$id.text] ) ;
    public ExpressionLanguageParser.memberAccess_return memberAccess() // throws RecognitionException [1]
    {   
        ExpressionLanguageParser.memberAccess_return retval = new ExpressionLanguageParser.memberAccess_return();
        retval.Start = input.LT(1);
        int memberAccess_StartIndex = input.Index();
        object root_0 = null;

        IToken id = null;

        object id_tree=null;
        RewriteRuleTokenStream stream_IDENTIFIER = new RewriteRuleTokenStream(adaptor,"token IDENTIFIER");

        try 
    	{
    	    if ( (state.backtracking > 0) && AlreadyParsedRule(input, 8) ) 
    	    {
    	    	return retval; 
    	    }
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:59:9: (id= IDENTIFIER -> ^( MEMBERACCESS[$id.text] ) )
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:59:11: id= IDENTIFIER
            {
            	id=(IToken)Match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_memberAccess453); if (state.failed) return retval; 
            	if ( (state.backtracking==0) ) stream_IDENTIFIER.Add(id);



            	// AST REWRITE
            	// elements:          
            	// token labels:      
            	// rule labels:       retval
            	// token list labels: 
            	// rule list labels:  
            	// wildcard labels: 
            	if ( (state.backtracking==0) ) {
            	retval.Tree = root_0;
            	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "rule retval", retval!=null ? retval.Tree : null);

            	root_0 = (object)adaptor.GetNilNode();
            	// 59:45: -> ^( MEMBERACCESS[$id.text] )
            	{
            	    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:59:48: ^( MEMBERACCESS[$id.text] )
            	    {
            	    object root_1 = (object)adaptor.GetNilNode();
            	    root_1 = (object)adaptor.BecomeRoot((object)adaptor.Create(MEMBERACCESS, ((id != null) ? id.Text : null)), root_1);

            	    adaptor.AddChild(root_0, root_1);
            	    }

            	}

            	retval.Tree = root_0;retval.Tree = root_0;}
            }

            retval.Stop = input.LT(-1);

            if ( (state.backtracking==0) )
            {	retval.Tree = (object)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, (IToken) retval.Start, (IToken) retval.Stop);}
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
    	// Conversion of the second argument necessary, but harmless
    	retval.Tree = (object)adaptor.ErrorNode(input, (IToken) retval.Start, input.LT(-1), re);

        }
        finally 
    	{
            if ( state.backtracking > 0 ) 
            {
            	Memoize(input, 8, memberAccess_StartIndex); 
            }
        }
        return retval;
    }
    // $ANTLR end "memberAccess"

    public class functionCall_return : ParserRuleReturnScope
    {
        private object tree;
        override public object Tree
        {
        	get { return tree; }
        	set { tree = (object) value; }
        }
    };

    // $ANTLR start "functionCall"
    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:61:1: functionCall : 'Iif' '(' expression ',' expression ',' expression ')' -> ^( IIF ( expression )* ) ;
    public ExpressionLanguageParser.functionCall_return functionCall() // throws RecognitionException [1]
    {   
        ExpressionLanguageParser.functionCall_return retval = new ExpressionLanguageParser.functionCall_return();
        retval.Start = input.LT(1);
        int functionCall_StartIndex = input.Index();
        object root_0 = null;

        IToken string_literal31 = null;
        IToken char_literal32 = null;
        IToken char_literal34 = null;
        IToken char_literal36 = null;
        IToken char_literal38 = null;
        ExpressionLanguageParser.expression_return expression33 = default(ExpressionLanguageParser.expression_return);

        ExpressionLanguageParser.expression_return expression35 = default(ExpressionLanguageParser.expression_return);

        ExpressionLanguageParser.expression_return expression37 = default(ExpressionLanguageParser.expression_return);


        object string_literal31_tree=null;
        object char_literal32_tree=null;
        object char_literal34_tree=null;
        object char_literal36_tree=null;
        object char_literal38_tree=null;
        RewriteRuleTokenStream stream_IIF = new RewriteRuleTokenStream(adaptor,"token IIF");
        RewriteRuleTokenStream stream_25 = new RewriteRuleTokenStream(adaptor,"token 25");
        RewriteRuleTokenStream stream_26 = new RewriteRuleTokenStream(adaptor,"token 26");
        RewriteRuleTokenStream stream_27 = new RewriteRuleTokenStream(adaptor,"token 27");
        RewriteRuleSubtreeStream stream_expression = new RewriteRuleSubtreeStream(adaptor,"rule expression");
        try 
    	{
    	    if ( (state.backtracking > 0) && AlreadyParsedRule(input, 9) ) 
    	    {
    	    	return retval; 
    	    }
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:62:3: ( 'Iif' '(' expression ',' expression ',' expression ')' -> ^( IIF ( expression )* ) )
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:62:5: 'Iif' '(' expression ',' expression ',' expression ')'
            {
            	string_literal31=(IToken)Match(input,IIF,FOLLOW_IIF_in_functionCall501); if (state.failed) return retval; 
            	if ( (state.backtracking==0) ) stream_IIF.Add(string_literal31);

            	char_literal32=(IToken)Match(input,25,FOLLOW_25_in_functionCall503); if (state.failed) return retval; 
            	if ( (state.backtracking==0) ) stream_25.Add(char_literal32);

            	PushFollow(FOLLOW_expression_in_functionCall505);
            	expression33 = expression();
            	state.followingStackPointer--;
            	if (state.failed) return retval;
            	if ( (state.backtracking==0) ) stream_expression.Add(expression33.Tree);
            	char_literal34=(IToken)Match(input,27,FOLLOW_27_in_functionCall507); if (state.failed) return retval; 
            	if ( (state.backtracking==0) ) stream_27.Add(char_literal34);

            	PushFollow(FOLLOW_expression_in_functionCall509);
            	expression35 = expression();
            	state.followingStackPointer--;
            	if (state.failed) return retval;
            	if ( (state.backtracking==0) ) stream_expression.Add(expression35.Tree);
            	char_literal36=(IToken)Match(input,27,FOLLOW_27_in_functionCall511); if (state.failed) return retval; 
            	if ( (state.backtracking==0) ) stream_27.Add(char_literal36);

            	PushFollow(FOLLOW_expression_in_functionCall513);
            	expression37 = expression();
            	state.followingStackPointer--;
            	if (state.failed) return retval;
            	if ( (state.backtracking==0) ) stream_expression.Add(expression37.Tree);
            	char_literal38=(IToken)Match(input,26,FOLLOW_26_in_functionCall515); if (state.failed) return retval; 
            	if ( (state.backtracking==0) ) stream_26.Add(char_literal38);



            	// AST REWRITE
            	// elements:          expression
            	// token labels:      
            	// rule labels:       retval
            	// token list labels: 
            	// rule list labels:  
            	// wildcard labels: 
            	if ( (state.backtracking==0) ) {
            	retval.Tree = root_0;
            	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "rule retval", retval!=null ? retval.Tree : null);

            	root_0 = (object)adaptor.GetNilNode();
            	// 62:67: -> ^( IIF ( expression )* )
            	{
            	    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:62:70: ^( IIF ( expression )* )
            	    {
            	    object root_1 = (object)adaptor.GetNilNode();
            	    root_1 = (object)adaptor.BecomeRoot((object)adaptor.Create(IIF, "IIF"), root_1);

            	    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:62:77: ( expression )*
            	    while ( stream_expression.HasNext() )
            	    {
            	        adaptor.AddChild(root_1, stream_expression.NextTree());

            	    }
            	    stream_expression.Reset();

            	    adaptor.AddChild(root_0, root_1);
            	    }

            	}

            	retval.Tree = root_0;retval.Tree = root_0;}
            }

            retval.Stop = input.LT(-1);

            if ( (state.backtracking==0) )
            {	retval.Tree = (object)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, (IToken) retval.Start, (IToken) retval.Stop);}
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
    	// Conversion of the second argument necessary, but harmless
    	retval.Tree = (object)adaptor.ErrorNode(input, (IToken) retval.Start, input.LT(-1), re);

        }
        finally 
    	{
            if ( state.backtracking > 0 ) 
            {
            	Memoize(input, 9, functionCall_StartIndex); 
            }
        }
        return retval;
    }
    // $ANTLR end "functionCall"

    public class literal_return : ParserRuleReturnScope
    {
        private object tree;
        override public object Tree
        {
        	get { return tree; }
        	set { tree = (object) value; }
        }
    };

    // $ANTLR start "literal"
    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:64:1: literal : (sl= STRINGLITERAL -> ^( LITERALSTRING[$sl] ) | bl= BOOLEANLITERAL -> ^( LITERALBOOLEAN[$bl] ) | il= NUMERICLITERAL -> ^( LITERALNUMERIC[$il] ) );
    public ExpressionLanguageParser.literal_return literal() // throws RecognitionException [1]
    {   
        ExpressionLanguageParser.literal_return retval = new ExpressionLanguageParser.literal_return();
        retval.Start = input.LT(1);
        int literal_StartIndex = input.Index();
        object root_0 = null;

        IToken sl = null;
        IToken bl = null;
        IToken il = null;

        object sl_tree=null;
        object bl_tree=null;
        object il_tree=null;
        RewriteRuleTokenStream stream_BOOLEANLITERAL = new RewriteRuleTokenStream(adaptor,"token BOOLEANLITERAL");
        RewriteRuleTokenStream stream_STRINGLITERAL = new RewriteRuleTokenStream(adaptor,"token STRINGLITERAL");
        RewriteRuleTokenStream stream_NUMERICLITERAL = new RewriteRuleTokenStream(adaptor,"token NUMERICLITERAL");

        try 
    	{
    	    if ( (state.backtracking > 0) && AlreadyParsedRule(input, 10) ) 
    	    {
    	    	return retval; 
    	    }
            // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:65:9: (sl= STRINGLITERAL -> ^( LITERALSTRING[$sl] ) | bl= BOOLEANLITERAL -> ^( LITERALBOOLEAN[$bl] ) | il= NUMERICLITERAL -> ^( LITERALNUMERIC[$il] ) )
            int alt9 = 3;
            switch ( input.LA(1) ) 
            {
            case STRINGLITERAL:
            	{
                alt9 = 1;
                }
                break;
            case BOOLEANLITERAL:
            	{
                alt9 = 2;
                }
                break;
            case NUMERICLITERAL:
            	{
                alt9 = 3;
                }
                break;
            	default:
            	    if ( state.backtracking > 0 ) {state.failed = true; return retval;}
            	    NoViableAltException nvae_d9s0 =
            	        new NoViableAltException("", 9, 0, input);

            	    throw nvae_d9s0;
            }

            switch (alt9) 
            {
                case 1 :
                    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:65:11: sl= STRINGLITERAL
                    {
                    	sl=(IToken)Match(input,STRINGLITERAL,FOLLOW_STRINGLITERAL_in_literal551); if (state.failed) return retval; 
                    	if ( (state.backtracking==0) ) stream_STRINGLITERAL.Add(sl);



                    	// AST REWRITE
                    	// elements:          
                    	// token labels:      
                    	// rule labels:       retval
                    	// token list labels: 
                    	// rule list labels:  
                    	// wildcard labels: 
                    	if ( (state.backtracking==0) ) {
                    	retval.Tree = root_0;
                    	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "rule retval", retval!=null ? retval.Tree : null);

                    	root_0 = (object)adaptor.GetNilNode();
                    	// 65:45: -> ^( LITERALSTRING[$sl] )
                    	{
                    	    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:65:48: ^( LITERALSTRING[$sl] )
                    	    {
                    	    object root_1 = (object)adaptor.GetNilNode();
                    	    root_1 = (object)adaptor.BecomeRoot((object)adaptor.Create(LITERALSTRING, sl), root_1);

                    	    adaptor.AddChild(root_0, root_1);
                    	    }

                    	}

                    	retval.Tree = root_0;retval.Tree = root_0;}
                    }
                    break;
                case 2 :
                    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:66:11: bl= BOOLEANLITERAL
                    {
                    	bl=(IToken)Match(input,BOOLEANLITERAL,FOLLOW_BOOLEANLITERAL_in_literal592); if (state.failed) return retval; 
                    	if ( (state.backtracking==0) ) stream_BOOLEANLITERAL.Add(bl);



                    	// AST REWRITE
                    	// elements:          
                    	// token labels:      
                    	// rule labels:       retval
                    	// token list labels: 
                    	// rule list labels:  
                    	// wildcard labels: 
                    	if ( (state.backtracking==0) ) {
                    	retval.Tree = root_0;
                    	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "rule retval", retval!=null ? retval.Tree : null);

                    	root_0 = (object)adaptor.GetNilNode();
                    	// 66:46: -> ^( LITERALBOOLEAN[$bl] )
                    	{
                    	    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:66:49: ^( LITERALBOOLEAN[$bl] )
                    	    {
                    	    object root_1 = (object)adaptor.GetNilNode();
                    	    root_1 = (object)adaptor.BecomeRoot((object)adaptor.Create(LITERALBOOLEAN, bl), root_1);

                    	    adaptor.AddChild(root_0, root_1);
                    	    }

                    	}

                    	retval.Tree = root_0;retval.Tree = root_0;}
                    }
                    break;
                case 3 :
                    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:67:11: il= NUMERICLITERAL
                    {
                    	il=(IToken)Match(input,NUMERICLITERAL,FOLLOW_NUMERICLITERAL_in_literal633); if (state.failed) return retval; 
                    	if ( (state.backtracking==0) ) stream_NUMERICLITERAL.Add(il);



                    	// AST REWRITE
                    	// elements:          
                    	// token labels:      
                    	// rule labels:       retval
                    	// token list labels: 
                    	// rule list labels:  
                    	// wildcard labels: 
                    	if ( (state.backtracking==0) ) {
                    	retval.Tree = root_0;
                    	RewriteRuleSubtreeStream stream_retval = new RewriteRuleSubtreeStream(adaptor, "rule retval", retval!=null ? retval.Tree : null);

                    	root_0 = (object)adaptor.GetNilNode();
                    	// 67:86: -> ^( LITERALNUMERIC[$il] )
                    	{
                    	    // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:67:89: ^( LITERALNUMERIC[$il] )
                    	    {
                    	    object root_1 = (object)adaptor.GetNilNode();
                    	    root_1 = (object)adaptor.BecomeRoot((object)adaptor.Create(LITERALNUMERIC, il), root_1);

                    	    adaptor.AddChild(root_0, root_1);
                    	    }

                    	}

                    	retval.Tree = root_0;retval.Tree = root_0;}
                    }
                    break;

            }
            retval.Stop = input.LT(-1);

            if ( (state.backtracking==0) )
            {	retval.Tree = (object)adaptor.RulePostProcessing(root_0);
            	adaptor.SetTokenBoundaries(retval.Tree, (IToken) retval.Start, (IToken) retval.Stop);}
        }
        catch (RecognitionException re) 
    	{
            ReportError(re);
            Recover(input,re);
    	// Conversion of the second argument necessary, but harmless
    	retval.Tree = (object)adaptor.ErrorNode(input, (IToken) retval.Start, input.LT(-1), re);

        }
        finally 
    	{
            if ( state.backtracking > 0 ) 
            {
            	Memoize(input, 10, literal_StartIndex); 
            }
        }
        return retval;
    }
    // $ANTLR end "literal"

    // $ANTLR start "synpred12_ExpressionLanguage"
    public void synpred12_ExpressionLanguage_fragment() {
        // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:49:11: ( conditionalOrExpression )
        // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:49:11: conditionalOrExpression
        {
        	PushFollow(FOLLOW_conditionalOrExpression_in_synpred12_ExpressionLanguage360);
        	conditionalOrExpression();
        	state.followingStackPointer--;
        	if (state.failed) return ;

        }
    }
    // $ANTLR end "synpred12_ExpressionLanguage"

    // $ANTLR start "synpred13_ExpressionLanguage"
    public void synpred13_ExpressionLanguage_fragment() {
        // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:50:11: ( functionCall )
        // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:50:11: functionCall
        {
        	PushFollow(FOLLOW_functionCall_in_synpred13_ExpressionLanguage373);
        	functionCall();
        	state.followingStackPointer--;
        	if (state.failed) return ;

        }
    }
    // $ANTLR end "synpred13_ExpressionLanguage"

    // $ANTLR start "synpred14_ExpressionLanguage"
    public void synpred14_ExpressionLanguage_fragment() {
        // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:51:11: ( parenthesizedExpression )
        // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:51:11: parenthesizedExpression
        {
        	PushFollow(FOLLOW_parenthesizedExpression_in_synpred14_ExpressionLanguage386);
        	parenthesizedExpression();
        	state.followingStackPointer--;
        	if (state.failed) return ;

        }
    }
    // $ANTLR end "synpred14_ExpressionLanguage"

    // $ANTLR start "synpred15_ExpressionLanguage"
    public void synpred15_ExpressionLanguage_fragment() {
        // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:52:11: ( memberAccess )
        // Q:\\SoftwareArchitects.SessionsAndTrainings\\Basta2009\\02-Baumschule\\TreeNurseryWpf\\Grammar\\ExpressionLanguage.g:52:11: memberAccess
        {
        	PushFollow(FOLLOW_memberAccess_in_synpred15_ExpressionLanguage399);
        	memberAccess();
        	state.followingStackPointer--;
        	if (state.failed) return ;

        }
    }
    // $ANTLR end "synpred15_ExpressionLanguage"

    // Delegated rules

   	public bool synpred15_ExpressionLanguage() 
   	{
   	    state.backtracking++;
   	    int start = input.Mark();
   	    try 
   	    {
   	        synpred15_ExpressionLanguage_fragment(); // can never throw exception
   	    }
   	    catch (RecognitionException re) 
   	    {
   	        Console.Error.WriteLine("impossible: "+re);
   	    }
   	    bool success = !state.failed;
   	    input.Rewind(start);
   	    state.backtracking--;
   	    state.failed = false;
   	    return success;
   	}
   	public bool synpred14_ExpressionLanguage() 
   	{
   	    state.backtracking++;
   	    int start = input.Mark();
   	    try 
   	    {
   	        synpred14_ExpressionLanguage_fragment(); // can never throw exception
   	    }
   	    catch (RecognitionException re) 
   	    {
   	        Console.Error.WriteLine("impossible: "+re);
   	    }
   	    bool success = !state.failed;
   	    input.Rewind(start);
   	    state.backtracking--;
   	    state.failed = false;
   	    return success;
   	}
   	public bool synpred13_ExpressionLanguage() 
   	{
   	    state.backtracking++;
   	    int start = input.Mark();
   	    try 
   	    {
   	        synpred13_ExpressionLanguage_fragment(); // can never throw exception
   	    }
   	    catch (RecognitionException re) 
   	    {
   	        Console.Error.WriteLine("impossible: "+re);
   	    }
   	    bool success = !state.failed;
   	    input.Rewind(start);
   	    state.backtracking--;
   	    state.failed = false;
   	    return success;
   	}
   	public bool synpred12_ExpressionLanguage() 
   	{
   	    state.backtracking++;
   	    int start = input.Mark();
   	    try 
   	    {
   	        synpred12_ExpressionLanguage_fragment(); // can never throw exception
   	    }
   	    catch (RecognitionException re) 
   	    {
   	        Console.Error.WriteLine("impossible: "+re);
   	    }
   	    bool success = !state.failed;
   	    input.Rewind(start);
   	    state.backtracking--;
   	    state.failed = false;
   	    return success;
   	}


   	protected DFA8 dfa8;
	private void InitializeCyclicDFAs()
	{
    	this.dfa8 = new DFA8(this);
	    this.dfa8.specialStateTransitionHandler = new DFA.SpecialStateTransitionHandler(DFA8_SpecialStateTransition);
	}

    const string DFA8_eotS =
        "\x0c\uffff";
    const string DFA8_eofS =
        "\x0c\uffff";
    const string DFA8_minS =
        "\x01\x10\x06\x00\x05\uffff";
    const string DFA8_maxS =
        "\x01\x19\x06\x00\x05\uffff";
    const string DFA8_acceptS =
        "\x07\uffff\x01\x01\x01\x03\x01\x02\x01\x04\x01\x05";
    const string DFA8_specialS =
        "\x01\uffff\x01\x00\x01\x01\x01\x02\x01\x03\x01\x04\x01\x05\x05"+
        "\uffff}>";
    static readonly string[] DFA8_transitionS = {
            "\x01\x02\x01\uffff\x01\x03\x01\x04\x01\x05\x01\x06\x03\uffff"+
            "\x01\x01",
            "\x01\uffff",
            "\x01\uffff",
            "\x01\uffff",
            "\x01\uffff",
            "\x01\uffff",
            "\x01\uffff",
            "",
            "",
            "",
            "",
            ""
    };

    static readonly short[] DFA8_eot = DFA.UnpackEncodedString(DFA8_eotS);
    static readonly short[] DFA8_eof = DFA.UnpackEncodedString(DFA8_eofS);
    static readonly char[] DFA8_min = DFA.UnpackEncodedStringToUnsignedChars(DFA8_minS);
    static readonly char[] DFA8_max = DFA.UnpackEncodedStringToUnsignedChars(DFA8_maxS);
    static readonly short[] DFA8_accept = DFA.UnpackEncodedString(DFA8_acceptS);
    static readonly short[] DFA8_special = DFA.UnpackEncodedString(DFA8_specialS);
    static readonly short[][] DFA8_transition = DFA.UnpackEncodedStringArray(DFA8_transitionS);

    protected class DFA8 : DFA
    {
        public DFA8(BaseRecognizer recognizer)
        {
            this.recognizer = recognizer;
            this.decisionNumber = 8;
            this.eot = DFA8_eot;
            this.eof = DFA8_eof;
            this.min = DFA8_min;
            this.max = DFA8_max;
            this.accept = DFA8_accept;
            this.special = DFA8_special;
            this.transition = DFA8_transition;

        }

        override public string Description
        {
            get { return "48:1: expression : ( conditionalOrExpression | functionCall | parenthesizedExpression | memberAccess | literal );"; }
        }

    }


    protected internal int DFA8_SpecialStateTransition(DFA dfa, int s, IIntStream _input) //throws NoViableAltException
    {
            ITokenStream input = (ITokenStream)_input;
    	int _s = s;
        switch ( s )
        {
               	case 0 : 
                   	int LA8_1 = input.LA(1);

                   	 
                   	int index8_1 = input.Index();
                   	input.Rewind();
                   	s = -1;
                   	if ( (synpred12_ExpressionLanguage()) ) { s = 7; }

                   	else if ( (synpred14_ExpressionLanguage()) ) { s = 8; }

                   	 
                   	input.Seek(index8_1);
                   	if ( s >= 0 ) return s;
                   	break;
               	case 1 : 
                   	int LA8_2 = input.LA(1);

                   	 
                   	int index8_2 = input.Index();
                   	input.Rewind();
                   	s = -1;
                   	if ( (synpred12_ExpressionLanguage()) ) { s = 7; }

                   	else if ( (synpred13_ExpressionLanguage()) ) { s = 9; }

                   	 
                   	input.Seek(index8_2);
                   	if ( s >= 0 ) return s;
                   	break;
               	case 2 : 
                   	int LA8_3 = input.LA(1);

                   	 
                   	int index8_3 = input.Index();
                   	input.Rewind();
                   	s = -1;
                   	if ( (synpred12_ExpressionLanguage()) ) { s = 7; }

                   	else if ( (synpred15_ExpressionLanguage()) ) { s = 10; }

                   	 
                   	input.Seek(index8_3);
                   	if ( s >= 0 ) return s;
                   	break;
               	case 3 : 
                   	int LA8_4 = input.LA(1);

                   	 
                   	int index8_4 = input.Index();
                   	input.Rewind();
                   	s = -1;
                   	if ( (synpred12_ExpressionLanguage()) ) { s = 7; }

                   	else if ( (true) ) { s = 11; }

                   	 
                   	input.Seek(index8_4);
                   	if ( s >= 0 ) return s;
                   	break;
               	case 4 : 
                   	int LA8_5 = input.LA(1);

                   	 
                   	int index8_5 = input.Index();
                   	input.Rewind();
                   	s = -1;
                   	if ( (synpred12_ExpressionLanguage()) ) { s = 7; }

                   	else if ( (true) ) { s = 11; }

                   	 
                   	input.Seek(index8_5);
                   	if ( s >= 0 ) return s;
                   	break;
               	case 5 : 
                   	int LA8_6 = input.LA(1);

                   	 
                   	int index8_6 = input.Index();
                   	input.Rewind();
                   	s = -1;
                   	if ( (synpred12_ExpressionLanguage()) ) { s = 7; }

                   	else if ( (true) ) { s = 11; }

                   	 
                   	input.Seek(index8_6);
                   	if ( s >= 0 ) return s;
                   	break;
        }
        if (state.backtracking > 0) {state.failed = true; return -1;}
        NoViableAltException nvae8 =
            new NoViableAltException(dfa.Description, 8, _s, input);
        dfa.Error(nvae8);
        throw nvae8;
    }
 

    public static readonly BitSet FOLLOW_conditionalAndExpression_in_conditionalOrExpression202 = new BitSet(new ulong[]{0x0000000000000082UL});
    public static readonly BitSet FOLLOW_OR_in_conditionalOrExpression206 = new BitSet(new ulong[]{0x00000000023D0000UL});
    public static readonly BitSet FOLLOW_conditionalAndExpression_in_conditionalOrExpression209 = new BitSet(new ulong[]{0x0000000000000082UL});
    public static readonly BitSet FOLLOW_equalityExpression_in_conditionalAndExpression227 = new BitSet(new ulong[]{0x0000000000000042UL});
    public static readonly BitSet FOLLOW_AND_in_conditionalAndExpression231 = new BitSet(new ulong[]{0x00000000023D0000UL});
    public static readonly BitSet FOLLOW_equalityExpression_in_conditionalAndExpression234 = new BitSet(new ulong[]{0x0000000000000042UL});
    public static readonly BitSet FOLLOW_relationalExpression_in_equalityExpression252 = new BitSet(new ulong[]{0x0000000000000302UL});
    public static readonly BitSet FOLLOW_EQUAL_in_equalityExpression257 = new BitSet(new ulong[]{0x00000000023D0000UL});
    public static readonly BitSet FOLLOW_DIFFERENT_in_equalityExpression262 = new BitSet(new ulong[]{0x00000000023D0000UL});
    public static readonly BitSet FOLLOW_relationalExpression_in_equalityExpression266 = new BitSet(new ulong[]{0x0000000000000302UL});
    public static readonly BitSet FOLLOW_atom_in_relationalExpression283 = new BitSet(new ulong[]{0x0000000000003C02UL});
    public static readonly BitSet FOLLOW_LESSTHAN_in_relationalExpression288 = new BitSet(new ulong[]{0x00000000023D0000UL});
    public static readonly BitSet FOLLOW_LTEQ_in_relationalExpression293 = new BitSet(new ulong[]{0x00000000023D0000UL});
    public static readonly BitSet FOLLOW_GREATERTHAN_in_relationalExpression298 = new BitSet(new ulong[]{0x00000000023D0000UL});
    public static readonly BitSet FOLLOW_GTEQ_in_relationalExpression303 = new BitSet(new ulong[]{0x00000000023D0000UL});
    public static readonly BitSet FOLLOW_atom_in_relationalExpression307 = new BitSet(new ulong[]{0x0000000000003C02UL});
    public static readonly BitSet FOLLOW_25_in_atom319 = new BitSet(new ulong[]{0x00000000023D0000UL});
    public static readonly BitSet FOLLOW_conditionalOrExpression_in_atom322 = new BitSet(new ulong[]{0x0000000004000000UL});
    public static readonly BitSet FOLLOW_26_in_atom324 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_functionCall_in_atom331 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_memberAccess_in_atom337 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_literal_in_atom343 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_conditionalOrExpression_in_expression360 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_functionCall_in_expression373 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_parenthesizedExpression_in_expression386 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_memberAccess_in_expression399 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_literal_in_expression412 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_25_in_parenthesizedExpression429 = new BitSet(new ulong[]{0x00000000023D0000UL});
    public static readonly BitSet FOLLOW_expression_in_parenthesizedExpression432 = new BitSet(new ulong[]{0x0000000004000000UL});
    public static readonly BitSet FOLLOW_26_in_parenthesizedExpression434 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_IDENTIFIER_in_memberAccess453 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_IIF_in_functionCall501 = new BitSet(new ulong[]{0x0000000002000000UL});
    public static readonly BitSet FOLLOW_25_in_functionCall503 = new BitSet(new ulong[]{0x00000000023D0000UL});
    public static readonly BitSet FOLLOW_expression_in_functionCall505 = new BitSet(new ulong[]{0x0000000008000000UL});
    public static readonly BitSet FOLLOW_27_in_functionCall507 = new BitSet(new ulong[]{0x00000000023D0000UL});
    public static readonly BitSet FOLLOW_expression_in_functionCall509 = new BitSet(new ulong[]{0x0000000008000000UL});
    public static readonly BitSet FOLLOW_27_in_functionCall511 = new BitSet(new ulong[]{0x00000000023D0000UL});
    public static readonly BitSet FOLLOW_expression_in_functionCall513 = new BitSet(new ulong[]{0x0000000004000000UL});
    public static readonly BitSet FOLLOW_26_in_functionCall515 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_STRINGLITERAL_in_literal551 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_BOOLEANLITERAL_in_literal592 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_NUMERICLITERAL_in_literal633 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_conditionalOrExpression_in_synpred12_ExpressionLanguage360 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_functionCall_in_synpred13_ExpressionLanguage373 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_parenthesizedExpression_in_synpred14_ExpressionLanguage386 = new BitSet(new ulong[]{0x0000000000000002UL});
    public static readonly BitSet FOLLOW_memberAccess_in_synpred15_ExpressionLanguage399 = new BitSet(new ulong[]{0x0000000000000002UL});

}
}