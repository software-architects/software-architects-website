﻿namespace TreeNurseryWpf.Grammar
{
	using Antlr.Runtime;
	using Antlr.Runtime.Tree;

	internal class ExpressionLanguageTreeAdaptor : CommonTreeAdaptor
	{
		public ExpressionLanguageTreeAdaptor()
			: base()
		{
		}

		public override object Create(IToken payload)
		{
			if (payload != null)
			{
				switch (payload.Type)
				{
					default:
						break;
				}
			}

			return new ExpressionLanguageCommonTree(payload);
		}
	}
}
