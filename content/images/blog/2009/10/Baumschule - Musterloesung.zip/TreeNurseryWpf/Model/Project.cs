﻿namespace TreeNurseryWpf.Model
{
	public class Project
	{
		public static Project[] DemoData = new[] {
			new Project() { ProjectName = "Projekt 1", Budget = 100, TotalCost = 110 },
			new Project(){ ProjectName = "Projekt 2", Budget = 100, TotalCost = 90 },
			new Project(){ ProjectName = "Projekt 3", Budget = 200, TotalCost = 100 },
			new Project(){ ProjectName = "Projekt 4", Budget = 300, TotalCost = 300 }
		};

		public string ProjectName { get; set; }
		public decimal Budget { get; set; }
		public decimal TotalCost { get; set; }
	}
}
