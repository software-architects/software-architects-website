﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Data;
using Antlr.Runtime;
using TreeNurseryWpf.Grammar;
using System.Linq.Expressions;

namespace TreeNurseryWpf.ViewModel
{
	public sealed class FormulaConverter : IValueConverter
	{
		

		public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
		{
			var formula = parameter as string;
			if (formula != null)
			{
				return FormulaConverter.CompileAndAddFormula(formula)(value);
			}
			else
			{
				return null;
			}
		}

		public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
		{
			throw new NotImplementedException();
		}

		private static Func<object, object> CompileAndAddFormula(string formula)
		{
			var stream = new ANTLRStringStream(formula);
			var lexer = new ExpressionLanguageLexer(stream);
			var tokens = new CommonTokenStream(lexer);
			var parser = new ExpressionLanguageParser(tokens);
			parser.TreeAdaptor = new ExpressionLanguageTreeAdaptor();
			var ast = parser.expression().Tree as ExpressionLanguageCommonTree;

		}

		private static Expression ConvertToExpressionTree(ExpressionLanguageCommonTree ast, ParameterExpression parameter)
		{
			var binFunc = binaryFunctions.Where(t => t.Key == ast.Type);
			if (binFunc.Count() == 1)
			{
				return Expression.MakeBinary(
					binFunc.First().Value,
					FormulaConverter.ConvertToExpressionTree(ast.ExpressionLanguageChildren.First(), parameter),
					FormulaConverter.ConvertToExpressionTree(ast.ExpressionLanguageChildren.Last(), parameter));
			}
			else if ( ast.Type == ExpressionLanguageParser.MEMBERACCESS )
			{
				return Expression.PropertyOrField(parameter, ast.Text);
			}
			else if (ast.Type == ExpressionLanguageParser.IIF)
			{
				return Expression.Condition(
					FormulaConverter.ConvertToExpressionTree(ast.ExpressionLanguageChildren.First(), parameter),
					FormulaConverter.ConvertToExpressionTree(ast.ExpressionLanguageChildren.Skip(1).First(), parameter),
					FormulaConverter.ConvertToExpressionTree(ast.ExpressionLanguageChildren.Last(), parameter));
			}
			else if (ast.Type == ExpressionLanguageParser.LITERALSTRING)
			{
				return Expression.Constant(ast.Text.Substring(1, ast.Text.Length - 2));
			}
			else if (ast.Type == ExpressionLanguageParser.LITERALBOOLEAN)
			{
				return Expression.Constant(bool.Parse(ast.Text));
			}
			else if (ast.Type == ExpressionLanguageParser.LITERALNUMERIC)
			{
				return Expression.Constant(decimal.Parse(ast.Text));
			}
			else
			{
				throw new ApplicationException("Unknown AST type!");
			}
		}
	}
}
