﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Linq.Expressions;
using Antlr.Runtime;
using TreeNurseryWpf.Grammar;
using TreeNurseryWpf.Model;

namespace TreeNurseryWpf.ViewModel
{
	public sealed class ProjectList : INotifyPropertyChanged
	{
		private static Dictionary<int, ExpressionType> binaryFunctions
			= new Dictionary<int, ExpressionType>();

		static ProjectList()
		{
			binaryFunctions.Add(ExpressionLanguageParser.OR, ExpressionType.OrElse);
			binaryFunctions.Add(ExpressionLanguageParser.AND, ExpressionType.AndAlso);
			binaryFunctions.Add(ExpressionLanguageParser.EQUAL, ExpressionType.Equal);
			binaryFunctions.Add(ExpressionLanguageParser.DIFFERENT, ExpressionType.NotEqual);
			binaryFunctions.Add(ExpressionLanguageParser.LESSTHAN, ExpressionType.LessThan);
			binaryFunctions.Add(ExpressionLanguageParser.LTEQ, ExpressionType.LessThanOrEqual);
			binaryFunctions.Add(ExpressionLanguageParser.GREATERTHAN, ExpressionType.GreaterThan);
			binaryFunctions.Add(ExpressionLanguageParser.GTEQ, ExpressionType.GreaterThanOrEqual);
		}

		public ProjectList()
		{
			this.BackgroundFormula = this.CustomColumnFormula = string.Empty;
		}

		private IEnumerable<ExpressionLanguageCommonTree> AstValue;
		public IEnumerable<ExpressionLanguageCommonTree> Ast
		{
			get
			{
				return this.AstValue;
			}
			set
			{
				this.AstValue = value;
				if (this.PropertyChanged != null)
				{
					this.PropertyChanged(this, new PropertyChangedEventArgs("Ast"));
				}
			}
		}

		public IEnumerable Projects
		{
			get
			{
				return
					from p in Project.DemoData
					select new
					{
						p.ProjectName,
						p.Budget,
						p.TotalCost,
						CustomCol = this.CustomColumnFunction!=null ? this.CustomColumnFunction(p) : null,
						BackgroundColor = this.CustomColumnFunction!=null ? this.BackgroundFunction(p) : null
					};
			}
		}

		public string BackgroundFormula { get; set; }
		public string CustomColumnFormula { get; set; }

		private Func<Project, object> BackgroundFunction { get; set; }
		private Func<Project, object> CustomColumnFunction { get; set; }

		public void ParseFormulas()
		{
			this.Ast = new[] { ProjectList.ParseFormula(this.CustomColumnFormula) };
			var backgroundFuncAst = ProjectList.ParseFormula(this.BackgroundFormula);

			this.BackgroundFunction = ProjectList.CompileFormula(backgroundFuncAst);
			this.CustomColumnFunction = ProjectList.CompileFormula(this.Ast.First());

			if (this.PropertyChanged != null)
			{
				this.PropertyChanged(this, new PropertyChangedEventArgs("Projects"));
			}
		}

		private static Func<Project, object> CompileFormula(ExpressionLanguageCommonTree ast)
		{
			var parameter = Expression.Parameter(typeof(Project), "p");
			var expression = ProjectList.ConvertToExpressionTree(ast, parameter);
			var lambda = Expression.Lambda<Func<Project, object>>(
				Expression.Convert(expression, typeof(object)),
				parameter);

			return lambda.Compile();
		}

		private static ExpressionLanguageCommonTree ParseFormula(string formula)
		{
			var stream = new ANTLRStringStream(formula);
			var lexer = new ExpressionLanguageLexer(stream);
			var tokens = new CommonTokenStream(lexer);
			var parser = new ExpressionLanguageParser(tokens);
			parser.TreeAdaptor = new ExpressionLanguageTreeAdaptor();
			var ast = parser.expression().Tree as ExpressionLanguageCommonTree;
			return ast;
		}

		private static Expression ConvertToExpressionTree(ExpressionLanguageCommonTree ast, ParameterExpression parameter)
		{
			var binFunc = binaryFunctions.Where(t => t.Key == ast.Type);
			if (binFunc.Count() == 1)
			{
				return Expression.MakeBinary(
					binFunc.First().Value,
					ProjectList.ConvertToExpressionTree(ast.ExpressionLanguageChildren.First(), parameter),
					ProjectList.ConvertToExpressionTree(ast.ExpressionLanguageChildren.Last(), parameter));
			}
			else if (ast.Type == ExpressionLanguageParser.MEMBERACCESS)
			{
				return Expression.PropertyOrField(parameter, ast.Text);
			}
			else if (ast.Type == ExpressionLanguageParser.IIF)
			{
				return Expression.Condition(
					ProjectList.ConvertToExpressionTree(ast.ExpressionLanguageChildren.First(), parameter),
					ProjectList.ConvertToExpressionTree(ast.ExpressionLanguageChildren.Skip(1).First(), parameter),
					ProjectList.ConvertToExpressionTree(ast.ExpressionLanguageChildren.Last(), parameter));
			}
			else if (ast.Type == ExpressionLanguageParser.LITERALSTRING)
			{
				return Expression.Constant(ast.Text.Substring(1, ast.Text.Length - 2));
			}
			else if (ast.Type == ExpressionLanguageParser.LITERALBOOLEAN)
			{
				return Expression.Constant(bool.Parse(ast.Text));
			}
			else if (ast.Type == ExpressionLanguageParser.LITERALNUMERIC)
			{
				return Expression.Constant(decimal.Parse(ast.Text));
			}
			else
			{
				throw new ApplicationException("Unknown AST type!");
			}
		}

		public event PropertyChangedEventHandler PropertyChanged;
	}
}
