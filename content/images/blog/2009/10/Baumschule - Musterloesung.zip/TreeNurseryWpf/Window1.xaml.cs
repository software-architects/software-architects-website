﻿using System.Windows;
using TreeNurseryWpf.ViewModel;

namespace TreeNurseryWpf
{
	public partial class Window1 : Window
	{
		public Window1()
		{
			InitializeComponent();
			this.DataContext = new ProjectList();
		}

		private void Parse_Click(object sender, RoutedEventArgs e)
		{
			((ProjectList)this.DataContext).ParseFormulas();
		}
	}
}
