﻿using System;

namespace ParallelProgrammingTools
{
	public static class MeasuringTools
	{
		public static TimeSpan Measure(Action body)
		{
			var startTime = DateTime.UtcNow;
			body();
			return DateTime.UtcNow - startTime;
		}
	}
}
