﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ParallelProgrammingTools;
using System.Threading.Tasks;
using System.Threading;
using System.Collections.Concurrent;
using System.Net;

namespace ParallelLoops
{
	class Program
	{
		private const int Size = 20000000;

		static void Main(string[] args)
		{
			// ParallelLoops();

			//ParallelWebRequests();

			//CorrectProducerConsumer();

			Console.ReadKey();
		}

		private static void WrongProducerConsumer()
		{
			// ATTENTION! THIS IMPLEMENTATION HAS MANY BUGS

			var buffer = new Queue<long>();
			var cancelTokenSource = new CancellationTokenSource();
			var done = false;

			var producer = Task.Factory.StartNew((cancelTokenObj) =>
				{
					var counter = 10000000;
					var cancelToken = (CancellationToken)cancelTokenObj;
					try
					{
						while (!cancelToken.IsCancellationRequested && counter-- > 0)
						{
							// Here we get some data (e.g. reading it from a file)
							var value = DateTime.Now.Ticks;

							// Write it to the buffer with values that have to be processed
							buffer.Enqueue(value);
						}
					}
					finally
					{
						done = true;
					}
				}, cancelTokenSource.Token);

			var consumer = Task.Factory.StartNew((cancelTokenObj) =>
				{
					var cancelToken = (CancellationToken)cancelTokenObj;
					while (!cancelToken.IsCancellationRequested && !done)
					{
						// Get the next value to process
						lock (buffer)
						{
							var value = buffer.Dequeue();
						}

						// Here we do some expensive procesing
						Thread.SpinWait(1000);
					}
				}, cancelTokenSource.Token);

			// Wait until user presses key
			while (!Console.KeyAvailable && !done)
			{
				Thread.Sleep(100);
			}

			// Cancel producer and quit
			cancelTokenSource.Cancel();
			Task.WaitAll(producer, consumer);
			Console.WriteLine("done!");
		}

		private static void CorrectProducerConsumer()
		{
			var buffer = new BlockingCollection<long>(10);
			var cancelTokenSource = new CancellationTokenSource();

			var producer = Task.Factory.StartNew((cancelTokenObj) =>
			{
				var counter = 10000000;
				var cancelToken = (CancellationToken)cancelTokenObj;
				try
				{
					while (!cancelToken.IsCancellationRequested && counter-- > 0)
					{
						// Here we get some data (e.g. reading it from a file)
						var value = DateTime.Now.Ticks;

						// Write it to the buffer with values that have to be processed
						buffer.Add(value);
					}
				}
				finally
				{
					buffer.CompleteAdding();
				}
			}, cancelTokenSource.Token);

			var consumer = Task.Factory.StartNew((cancelTokenObj) =>
			{
				var cancelToken = (CancellationToken)cancelTokenObj;
				foreach (var value in buffer.GetConsumingEnumerable())
				{
					if ( cancelToken.IsCancellationRequested )
					{
						break;
					}

					// Here we do some expensive procesing
					Thread.SpinWait(1000);
				}
			}, cancelTokenSource.Token);

			// Wait until user presses key
			while (!Console.KeyAvailable)
			{
				Thread.Sleep(100);
			}

			// Cancel producer and quit
			cancelTokenSource.Cancel();
			Task.WaitAll(producer, consumer);
			Console.WriteLine("done!");
		}

		private static void ParallelWebRequests()
		{
			var urls = new[] {
				"http://www.microsoft.com",
				"http://msdn.microsoft.com",
				"http://www.basta.net",
				"http://www.createordie.de",
				"http://www.software-architects.at",
				"http://www.timecockpit.com",
				"http://www.ftd.de",
				"http://www.codeproject.com"
			};

			Console.WriteLine(
				"Serielles Lesen: {0}",
				MeasuringTools.Measure(() =>
				{
					foreach (var url in urls)
					{
						var request = WebRequest.Create(url);
						using (var response = request.GetResponse())
						{
							using (var stream = response.GetResponseStream())
							{
								var content = new byte[1024];
								while (stream.Read(content, 0, 1024) != 0) ;
							}
						}
					}
				}));

			Console.WriteLine(
				"Paralleles Lesen: {0}",
				MeasuringTools.Measure(() =>
				{
					Parallel.ForEach(urls, url =>
					{
						var request = WebRequest.Create(url);
						using (var response = request.GetResponse())
						{
							using (var stream = response.GetResponseStream())
							{
								var content = new byte[1024];
								while (stream.Read(content, 0, 1024) != 0) ;
							}
						}
					});
				}));

			Console.WriteLine(
				"Paralleles Lesen mit vielen Threads: {0}",
				MeasuringTools.Measure(() =>
				{
					urls.AsParallel().WithDegreeOfParallelism(urls.Length)
						.Select(url => WebRequest.Create(url))
						.Select(request => request.GetResponse())
						.Select(response => new { Response = response, Stream = response.GetResponseStream() })
						.ForAll(stream =>
							{
								var content = new byte[1024];
								while (stream.Stream.Read(content, 0, 1024) != 0) ;
								stream.Stream.Dispose();
								stream.Response.Close();
							});
				}));

			Console.WriteLine(
				"Paralleles Lesen mit TaskFactory: {0}",
				MeasuringTools.Measure(() =>
					{
						var tasks = new Task[urls.Length];
						for (int i = 0; i < urls.Length; i++)
						{
							var tmp = i;
							tasks[i] = Task.Factory.StartNew(() => ReadUrl(urls[tmp]));
						}

						Task.WaitAll(tasks);
					}
				));

			Console.WriteLine(
				"Paralleles Lesen mit TaskFactory: {0}",
				MeasuringTools.Measure(() =>
				{
					var tasks = new Task[urls.Length];
					for (int i = 0; i < urls.Length; i++)
					{
						tasks[i] = Task.Factory.StartNew(ReadUrl, urls[i]);
					}

					Task.WaitAll(tasks);
				}
				));
		}

		private static void ReadUrl(object url)
		{
			var request = WebRequest.Create(url.ToString());
			using (var response = request.GetResponse())
			{
				using (var stream = response.GetResponseStream())
				{
					var content = new byte[1024];
					while (stream.Read(content, 0, 1024) != 0) ;
				}
			}
		}

		private static void ParallelLoops()
		{
			var source = Enumerable.Range(0, Program.Size).ToArray();
			var destination = new double[Program.Size];

			#region Parallel.For
			Console.WriteLine(
				"Serielle for-Schleife: {0}",
				MeasuringTools.Measure(() =>
				{
					for (int i = 0; i < Program.Size; i++)
					{
						destination[i] = Math.Pow(source[i], 2);
					}
				}));

			Console.WriteLine(
				"Parallele for-Schleife: {0}",
				MeasuringTools.Measure(() =>
				{
					Parallel.For(0, Program.Size, (i) => destination[i] = Math.Pow(source[i], 2));
				}));
			#endregion

			#region Parallel.Foreach
			Console.WriteLine(
				"Serieller Durchlauf mit foreach: {0}",
				MeasuringTools.Measure(() =>
				{
					double sumOfSquares = 0;
					foreach (var square in Enumerable.Range(0, Program.Size).Select(i => Math.Pow(i, 2)))
					{
						sumOfSquares += square;
					}
				}));

			Console.WriteLine(
				"Paralleler Durchlauf mit foreach: {0}",
				MeasuringTools.Measure(() =>
				{
					double sumOfSquares = 0;
					Parallel.ForEach(Enumerable.Range(0, Program.Size).Select(i => Math.Pow(i, 2)), square => sumOfSquares += square);
				}));

			Console.WriteLine(
				"Paralleler Durchlauf mit PLINQ: {0}",
				MeasuringTools.Measure(() =>
				{
					double sumOfSquares = 0;
					sumOfSquares = ParallelEnumerable.Range(0, Program.Size).AsOrdered().Select(i => Math.Pow(i, 2)).Sum();
				}));
			#endregion

			#region Parallel.ForAll
			var result = new List<double>();
			Console.WriteLine(
				"Paralleler Durchlauf mit Parallel.ForEach: {0}",
				MeasuringTools.Measure(() =>
				{
					Parallel.ForEach(
						source.AsParallel(),
						i =>
						{
							if (i % 2 == 0)
							{
								lock (result)
								{
									result.Add(i);
								}
							}
						});
				}));

			result.Clear();
			GC.Collect();
			Console.WriteLine(
				"Paralleler Durchlauf mit Parallel.ForAll: {0}",
				MeasuringTools.Measure(() =>
				{
					source.AsParallel().ForAll(
						i =>
						{
							if (i % 2 == 0)
							{
								lock (result)
								{
									result.Add(i);
								}
							}
						});
				}));
			#endregion
		}
	}
}
