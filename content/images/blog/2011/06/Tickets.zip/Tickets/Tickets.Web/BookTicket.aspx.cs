﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.StorageClient;
using Microsoft.WindowsAzure.ServiceRuntime;
using System.Data;

namespace Tickets.Web
{
    public partial class BookTicket : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                var eventID = Guid.Parse(Request.QueryString["EventID"]);
                var userName = Request.QueryString["UserName"];
                var numberOfTickets = Int32.Parse(Request.QueryString["NumberOfTickets"]);

                using (var conn = new SqlConnection(
                    RoleEnvironment.GetConfigurationSettingValue("SqlConnectionString")))
                {
                    conn.Open();
                    using (var cmd = conn.CreateCommand())
                    {
                        cmd.Parameters.AddWithValue("@EventID", eventID);
                        cmd.Parameters.AddWithValue("@UserName", userName);
                        cmd.Parameters.AddWithValue("@NumberOfTickets", numberOfTickets);
                        cmd.CommandText = "SellTicket";
                        cmd.CommandType = CommandType.StoredProcedure;
                        var result = (int)cmd.ExecuteScalar();

                        this.Result.Text = (result == 0) ? "Success" : "Failure";
                    }
                }
            }
        }
    }
}