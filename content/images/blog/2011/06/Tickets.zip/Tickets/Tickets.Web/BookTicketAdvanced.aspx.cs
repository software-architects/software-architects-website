﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.ServiceRuntime;
using Microsoft.WindowsAzure.StorageClient;
using System.Data.Services.Client;

namespace Tickets.Web
{
    public partial class BookTicketAdvanced : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                var eventID = Guid.Parse(Request.QueryString["EventID"]);
                var userName = Request.QueryString["UserName"];
                var numberOfTickets = Int32.Parse(Request.QueryString["NumberOfTickets"]);

                var account = CloudStorageAccount.Parse(
                    RoleEnvironment.GetConfigurationSettingValue("AzureConnectionString"));
                var tableClient = account.CreateCloudTableClient();
                
                tableClient.CreateTableIfNotExist("ticket");
                var context = tableClient.GetDataServiceContext();

                var queueClient = account.CreateCloudQueueClient();
                var queue = queueClient.GetQueueReference("ticketqueue");
                queue.CreateIfNotExist();

                var ticketID = Guid.NewGuid();
                context.AddObject(
                    "ticket",
                    new TicketTableRow(ticketID, eventID, userName, numberOfTickets));

                context.SaveChanges();

                queue.AddMessage(new CloudQueueMessage(
                    string.Format("{0}\n{1}", eventID, ticketID)));

                this.Result.Text = "Wir werden ihnen Bestätigung zusenden...";
            }
        }
    }
}