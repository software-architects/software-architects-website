﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.WindowsAzure.StorageClient;

namespace Tickets.Web
{
    public class TicketTableRow : TableServiceEntity
    {
        public TicketTableRow()
        {
        }

        public TicketTableRow(
            Guid ticketID,
            Guid eventID,
            string userName,
            int numberOfTickets)
        {
            this.PartitionKey = eventID.ToString();
            this.RowKey = ticketID.ToString();
            this.UserName = userName;
            this.NumberOfTickets = numberOfTickets;
        }

        public string UserName { get; set; }
        public int NumberOfTickets { get; set; }
    }
}