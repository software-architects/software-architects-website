﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Threading;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.Diagnostics;
using Microsoft.WindowsAzure.ServiceRuntime;
using Microsoft.WindowsAzure.StorageClient;
using System.Data.SqlClient;
using System.Data;
using System.Data.Services.Client;
using Tickets.Web;

namespace Tickets.Worker
{
    public class WorkerRole : RoleEntryPoint
    {
        public override void Run()
        {
            var account = CloudStorageAccount.Parse(
                RoleEnvironment.GetConfigurationSettingValue("AzureConnectionString"));
            var tableClient = account.CreateCloudTableClient();

            tableClient.CreateTableIfNotExist("ticket");
            var context = tableClient.GetDataServiceContext();

            var queueClient = account.CreateCloudQueueClient();
            var queue = queueClient.GetQueueReference("ticketqueue");
            queue.CreateIfNotExist();

            while (true)
            {
                var msg = queue.GetMessage(TimeSpan.FromMinutes(5));
                if (msg != null)
                {
                    if (msg.DequeueCount > 2)
                    {
                        queue.DeleteMessage(msg);
                        continue;
                    }

                    var msgParts = msg.AsString.Split('\n');
                    var eventID = Guid.Parse(msgParts[0]);
                    var ticketID = Guid.Parse(msgParts[1]);

                    var payload =
                        (from t in context.CreateQuery<TicketTableRow>("ticket")
                         where t.PartitionKey == eventID.ToString()
                             && t.RowKey == ticketID.ToString()
                         select t).SingleOrDefault();

                    var userName = payload.UserName;
                    var numberOfTickets = payload.NumberOfTickets;

                    using (var conn = new SqlConnection(
                        RoleEnvironment.GetConfigurationSettingValue("SqlConnectionString")))
                    {
                        conn.Open();
                        using (var cmd = conn.CreateCommand())
                        {
                            cmd.Parameters.AddWithValue("@EventID", eventID);
                            cmd.Parameters.AddWithValue("@UserName", userName);
                            cmd.Parameters.AddWithValue("@NumberOfTickets", numberOfTickets);
                            cmd.CommandText = "SellTicket";
                            cmd.CommandType = CommandType.StoredProcedure;
                            var result = (int)cmd.ExecuteScalar();
                        }
                    }

                    queue.DeleteMessage(msg);

                    context.DeleteObject(payload);
                    context.SaveChanges();
                }
                else
                {
                    Thread.Sleep(5000);
                }
            }
        }

        public override bool OnStart()
        {
            // Set the maximum number of concurrent connections 
            ServicePointManager.DefaultConnectionLimit = 12;

            // For information on handling configuration changes
            // see the MSDN topic at http://go.microsoft.com/fwlink/?LinkId=166357.

            return base.OnStart();
        }
    }
}
