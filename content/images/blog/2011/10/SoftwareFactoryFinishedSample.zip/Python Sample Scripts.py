import clr
clr.AddReference("mscorlib")

from System.Threading import Thread

for i in range(0, 10):
  print str(i+1)
  Thread.Sleep(500)

print "Done!"

----------------------------------

import clr
clr.AddReference("SoftwareFactory")
from SoftwareFactory.DataAccess import EntityObject

for i in range(0, 10):
  cust = EntityObject.CreateObject(Context.Model.Entities["Customer"])
  cust.CustomerCode = "Cust" + str(i)
  cust.CustomerDescription = "Customer " + str(i)
  cust.RevenueYTD = i * 1000
  cust.RevenuePrevYear = i * 1000 - 100
  Context.Insert(cust)

print "Done!"

-----------------------------------

import clr
from System import *

for cust in Context.Select(Context.Model.Entities["Customer"], Guid.Empty):
  print cust.CustomerCode + " " + str(cust.TargetRatio)
  
------------------------------------

import clr
clr.AddReferenceByName("Microsoft.Office.Interop.Excel, Version=11.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c")
clr.AddReference("System.Core")
from Microsoft.Office.Interop import *
from Microsoft.Office.Interop.Excel import *
from System import *

ex = Excel.ApplicationClass()   
ex.Visible = True
ex.DisplayAlerts = False   
workbook = ex.Workbooks.Add()
ws = workbook.Worksheets[1]
rowIndex = 1
for cust in Context.Select(Context.Model.Entities["Customer"], Guid.Empty):
  ws.Cells[rowIndex, 1].Value2 = cust.CustomerCode
  ws.Cells[rowIndex, 2].Value2 = cust.CustomerDescription
  ws.Cells[rowIndex, 3].Value2 = cust.RevenueYTD
  ws.Cells[rowIndex, 4].Value2 = cust.RevenuePrevYear
  ws.Cells[rowIndex, 5].Value2 = cust.TargetRatio
  rowIndex = rowIndex + 1


