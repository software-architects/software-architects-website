﻿//------------------------------------------------------------------------------------------------------------
// <copyright file="DataContext.cs" company="software architects gmbh">
//     Copyright (c) software architects gmbh. All rights reserved.
// </copyright>
//------------------------------------------------------------------------------------------------------------

namespace SoftwareFactory.DataAccess
{
	using System;
	using System.Collections.Generic;
	using System.Data.SqlClient;
	using System.Diagnostics.CodeAnalysis;
	using System.Linq;
	using System.Threading.Tasks;
	using SoftwareFactory.DatabaseTemplates;
	using SoftwareFactory.Model;

	/// <summary>
	/// Represents a connection to the database.
	/// </summary>
	/// <remarks>
	/// <alert class="note">
	///   Please note that this is a simplified example and not production-ready code.
	///   In real life we would e.g. separate RDBMS-specific code to support multiple RDBMS
	///   systems.
	/// </alert>
	/// </remarks>
	public class DataContext
	{
		#region Constructors
		/// <summary>
		/// Initializes a new instance of the <see cref="DataContext"/> class.
		/// </summary>
		/// <param name="connectionString">The connection string.</param>
		/// <param name="model">The model.</param>
		/// <remarks>
		/// <alert class="note">
		///   Note that in this simplified example we did not implement the data model
		///   as a freezable or immutable. Therefore you must make sure that once you 
		///   passed the data model to the data context you must not make any changes 
		///   to the data model any more.
		/// </alert>
		/// </remarks>
		public DataContext(string connectionString, DataModel model)
		{
			this.ConnectionString = connectionString;
			this.Model = model;
		}
		#endregion

		#region Properties
		/// <summary>
		/// Gets the connection string.
		/// </summary>
		public string ConnectionString { get; private set; }

		/// <summary>
		/// Gets the model.
		/// </summary>
		public DataModel Model { get; private set; }
		#endregion

		#region Methods
		/// <summary>
		/// Creates the schema asynchronous.
		/// </summary>
		/// <returns>Task representing the creation task.</returns>
		[SuppressMessage("Microsoft.Security", "CA2100:ReviewSqlQueriesForSecurityVulnerabilities", Justification = "Checked")]
		public Task CreateSchemaAsync()
		{
			return Task.Factory.StartNew(() =>
				{
					var createScript = new CreateTable()
					{
						Model = this.Model
					};
					var commandText = createScript.TransformText();
					this.ExecuteCommandAction((command) =>
						{
							command.CommandText = commandText;
							command.ExecuteNonQuery();
						});
				});
		}

		/// <summary>
		/// Performs an async select.
		/// </summary>
		/// <param name="entity">The entity to query.</param>
		/// <param name="entityIdFilter">The entity id filter. Pass <see cref="System.Guid.Empty"/> if you want all entities.</param>
		/// <returns>Collection of result objects.</returns>
		[SuppressMessage("Microsoft.Security", "CA2100:ReviewSqlQueriesForSecurityVulnerabilities", Justification = "Checked")]
		[SuppressMessage("Microsoft.Design", "CA1006", Justification = "Necessary because of task async pattern.")]
		public Task<IEnumerable<EntityObject>> SelectAsync(Entity entity, Guid entityIdFilter)
		{
			return Task.Factory.StartNew<IEnumerable<EntityObject>>(() =>
				{
					var selectScript = new Select()
					{
						Entity = entity,
						EntityIDFilter = entityIdFilter
					};
					var commandText = selectScript.TransformText();
					var result = new List<EntityObject>();
					this.ExecuteCommandAction((command) =>
					{
						command.CommandText = commandText;
						using (var reader = command.ExecuteReader())
						{
							while (reader.Read())
							{
								var newObject = EntityObject.CreateObject(entity);
								foreach (var property in entity.Properties.OfType<PersistedProperty>())
								{
									newObject.TrySetMember(property.Code, reader[property.Code]);
								}

								result.Add(newObject);
							}
						}
					});
					return result;
				});
		}

		/// <summary>
		/// Performs an synchronous select.
		/// </summary>
		/// <param name="entity">The entity to query.</param>
		/// <param name="entityIdFilter">The entity id filter. Pass <see cref="System.Guid.Empty"/> if you want all entities.</param>
		/// <returns>Collection of result objects.</returns>
		public IEnumerable<EntityObject> Select(Entity entity, Guid entityIdFilter)
		{
			var t = this.SelectAsync(entity, entityIdFilter);
			t.Wait();
			return t.Result;
		}

		/// <summary>
		/// Performs an async insert.
		/// </summary>
		/// <param name="newObject">The entity object to insert.</param>
		/// <returns>Task representing the insert task.</returns>
		[SuppressMessage("Microsoft.Security", "CA2100:ReviewSqlQueriesForSecurityVulnerabilities", Justification = "Checked")]
		public Task InsertAsync(EntityObject newObject)
		{
			return Task.Factory.StartNew(() =>
			{
				var insertScript = new Insert()
				{
					EntityObject = newObject
				};
				var commandText = insertScript.TransformText();
				this.ExecuteCommandAction((command) =>
				{
					command.CommandText = commandText;
					command.Parameters.AddWithValue("@" + newObject.Entity.Code + "_ID", newObject.EntityId);
					foreach (var property in newObject.Entity.Properties.OfType<PersistedProperty>())
					{
						object value;
						newObject.TryGetMember(property.Code, out value);
						command.Parameters.AddWithValue("@" + property.Code, value);
					}

					command.ExecuteNonQuery();
				});
			});
		}

		/// <summary>
		/// Performs an synchronous insert.
		/// </summary>
		/// <param name="newObject">The entity object to insert.</param>
		public void Insert(EntityObject newObject)
		{
			var t = this.InsertAsync(newObject);
			t.Wait();
		}

		/// <summary>
		/// Executes an action on a command.
		/// </summary>
		/// <param name="body">Action to execute.</param>
		private void ExecuteCommandAction(Action<SqlCommand> body)
		{
			using (var connection = new SqlConnection(this.ConnectionString))
			{
				connection.Open();
				using (var command = connection.CreateCommand())
				{
					body(command);
				}
			}
		}
		#endregion
	}
}
