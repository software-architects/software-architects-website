﻿//------------------------------------------------------------------------------------------------------------
// <copyright file="EntityObject.cs" company="software architects gmbh">
//     Copyright (c) software architects gmbh. All rights reserved.
// </copyright>
//------------------------------------------------------------------------------------------------------------

namespace SoftwareFactory.DataAccess
{
	using System;
	using System.Collections.Generic;
	using System.Diagnostics.CodeAnalysis;
	using System.Dynamic;
	using System.Globalization;
	using SoftwareFactory.Model;

	/// <summary>
	/// Represents a object with metadata in <see cref="SoftwareFactory.Model.DataModel"/>
	/// </summary>
	public class EntityObject : DynamicObject
	{
		#region Fields
		/// <summary>
		/// Metadata for the entity object.
		/// </summary>
		private Entity entity;

		/// <summary>
		/// Holds the values of the dynamic properties.
		/// </summary>
		private Dictionary<string, dynamic> values;
		#endregion

		#region Constructors
		/// <summary>
		/// Initializes a new instance of the <see cref="EntityObject"/> class.
		/// </summary>
		/// <param name="entity">The metdata for the entity object.</param>
		internal EntityObject(Entity entity)
		{
			this.entity = entity;
			this.values = new Dictionary<string, dynamic>(entity.Properties.Count);
			this.EntityId = Guid.NewGuid();
		}
		#endregion

		#region Properties
		/// <summary>
		/// Gets or sets the entity ID.
		/// </summary>
		/// <value>
		/// The entity ID.
		/// </value>
		public Guid EntityId { get; set; }

		/// <summary>
		/// Gets the entity.
		/// </summary>
		internal Entity Entity
		{
			get
			{
				return this.entity;
			}
		}
		#endregion

		#region Methods
		/// <summary>
		/// Creates the object.
		/// </summary>
		/// <param name="entity">The entity.</param>
		/// <returns>New entity object</returns>
		public static EntityObject CreateObject(Entity entity)
		{
			return new EntityObject(entity);
		}

		/// <summary>
		/// Provides the implementation for operations that get member values.
		/// </summary>
		/// <param name="binder">Provides information about the object that called the dynamic operation.</param>
		/// <param name="result">The result of the get operation.</param>
		/// <returns>
		/// true if the operation is successful; otherwise, false. If this method returns false, the run-time binder of the language determines the behavior. (In most cases, a run-time exception is thrown.)
		/// </returns>
		[SuppressMessage("Microsoft.Design", "CA1062", Justification = "Called by framework; no need to check binder.")]
		public override bool TryGetMember(GetMemberBinder binder, out object result)
		{
			return this.TryGetMember(binder.Name, out result);
		}

		/// <summary>
		/// Provides the implementation for operations that set member values.
		/// </summary>
		/// <param name="binder">Provides information about the object that called the dynamic operation.</param>
		/// <param name="value">The value to set to the member.</param>
		/// <returns>
		/// true if the operation is successful; otherwise, false. If this method returns false, the run-time binder of the language determines the behavior. (In most cases, a language-specific run-time exception is thrown.)
		/// </returns>
		[SuppressMessage("Microsoft.Design", "CA1062", Justification = "Called by framework; no need to check binder.")]
		public override bool TrySetMember(SetMemberBinder binder, object value)
		{
			return this.TrySetMember(binder.Name, value);
		}

		/// <summary>
		/// Provides the implementation for operations that get member values.
		/// </summary>
		/// <param name="memberName">Name of the member.</param>
		/// <param name="result">The result of the get operation.</param>
		/// <returns>
		/// true if the operation is successful; otherwise, false.
		/// </returns>
		[SuppressMessage("Microsoft.Design", "CA1007", Justification = "In analogy to frameworks' TraGetMember")]
		public bool TryGetMember(string memberName, out object result)
		{
			if (this.entity.Properties.Contains(memberName))
			{
				if (this.values.ContainsKey(memberName))
				{
					{
						result = this.values[memberName];
						return true;
					}
				}
				else
				{
					var calcProp = this.entity.Properties[memberName] as CalculatedProperty;
					if (calcProp != null)
					{
						result = calcProp.CalculationFunction(this);
						return true;
					}
				}
			}

			result = null;
			return false;
		}

		/// <summary>
		/// Provides the implementation for operations that get member values.
		/// </summary>
		/// <param name="memberName">Name of the member.</param>
		/// <returns>
		/// Value of the member
		/// </returns>
		public object GetMember(string memberName)
		{
			object result;
			return this.TryGetMember(memberName, out result) ? result : null;
		}

		/// <summary>
		/// Provides the implementation for operations that set member values.
		/// </summary>
		/// <param name="memberName">Name of the member to set.</param>
		/// <param name="value">The value to set to the member. For example, for sampleObject.SampleProperty = "Test", where sampleObject is an instance of the class derived from the <see cref="T:System.Dynamic.DynamicObject"/> class, the <paramref name="value"/> is "Test".</param>
		/// <returns>
		/// true if the operation is successful; otherwise, false.
		/// </returns>
		public bool TrySetMember(string memberName, object value)
		{
			if (this.entity.Properties.Contains(memberName) && value != null)
			{
				if (this.entity.Properties[memberName] is NumericProperty)
				{
					this.values[memberName] = Convert.ToDecimal(value, CultureInfo.InvariantCulture);
				}
				else
				{
					this.values[memberName] = value.ToString();
				}

				return true;
			}

			return false;
		}
		#endregion
	}
}
