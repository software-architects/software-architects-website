﻿//------------------------------------------------------------------------------------------------------------
// <copyright file="CreateTableExtensions.cs" company="software architects gmbh">
//     Copyright (c) software architects gmbh. All rights reserved.
// </copyright>
//------------------------------------------------------------------------------------------------------------

namespace SoftwareFactory.DatabaseTemplates
{
	using SoftwareFactory.Model;

	/// <summary>
	/// Generator for CREATE TABLE statements for the <see cref="SoftwareFactory.Model.DataModel"/>
	/// </summary>
	public partial class CreateTable
	{
		#region Properties
		/// <summary>
		/// Gets or sets the model.
		/// </summary>
		/// <value>
		/// The model.
		/// </value>
		public DataModel Model { get; set; }
		#endregion
	}
}
