﻿//------------------------------------------------------------------------------------------------------------
// <copyright file="InsertExtensions.cs" company="software architects gmbh">
//     Copyright (c) software architects gmbh. All rights reserved.
// </copyright>
//------------------------------------------------------------------------------------------------------------

namespace SoftwareFactory.DatabaseTemplates
{
	using SoftwareFactory.DataAccess;

	/// <summary>
	/// Generator for INSERT statements for the <see cref="SoftwareFactory.Model.DataModel"/>
	/// </summary>
	public partial class Insert
	{
		#region Properties
		/// <summary>
		/// Gets or sets the entity object.
		/// </summary>
		public EntityObject EntityObject { get; set; }
		#endregion
	}
}
