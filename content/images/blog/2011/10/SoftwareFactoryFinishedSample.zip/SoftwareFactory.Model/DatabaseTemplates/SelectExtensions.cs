﻿//------------------------------------------------------------------------------------------------------------
// <copyright file="SelectExtensions.cs" company="software architects gmbh">
//     Copyright (c) software architects gmbh. All rights reserved.
// </copyright>
//------------------------------------------------------------------------------------------------------------

namespace SoftwareFactory.DatabaseTemplates
{
	using System;
	using SoftwareFactory.Model;

	/// <summary>
	/// Generator for SELECT statements for the <see cref="SoftwareFactory.Model.DataModel"/>
	/// </summary>
	public partial class Select
	{
		#region Constructors
		/// <summary>
		/// Initializes a new instance of the <see cref="Select"/> class.
		/// </summary>
		public Select()
		{
			this.EntityIDFilter = Guid.Empty;
		}
		#endregion

		#region Properties
		/// <summary>
		/// Gets or sets the entity.
		/// </summary>
		public Entity Entity { get; set; }

		/// <summary>
		/// Gets or sets the entity ID filter.
		/// </summary>
		public Guid EntityIDFilter { get; set; }
		#endregion
	}
}
