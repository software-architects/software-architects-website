﻿//------------------------------------------------------------------------------------------------------------
// <copyright file="CalculatedProperty.cs" company="software architects gmbh">
//     Copyright (c) software architects gmbh. All rights reserved.
// </copyright>
//------------------------------------------------------------------------------------------------------------

namespace SoftwareFactory.Model
{
	using System;
	using SoftwareFactory.DataAccess;

	/// <summary>
	/// Represents a dynamically calculated property.
	/// </summary>
	/// <remarks>
	/// <alert class="note">
	///   Please note that this is a simplified example and not production-ready code.
	///   In real life the whole model should be implemented as a freezable (see e.g. WPF
	///   Freezable-concept) or as a immutable. This would have big advantages when it comes
	///   to sharing models across threads.
	/// </alert>
	/// </remarks>
	public class CalculatedProperty : ModelProperty
	{
		#region Fields
		/// <summary>
		/// Holds the compiled function for <see cref="Formula"/>.
		/// </summary>
		private Func<EntityObject, decimal> function;
		#endregion

		#region Properties
		/// <summary>
		/// Gets or sets the formula.
		/// </summary>
		/// <remarks>
		/// <para>
		///   In real world we would describe the formula language here...
		/// </para>
		/// </remarks>
		public string Formula { get; set; }

		/// <summary>
		/// Gets the compiled calculation function.
		/// </summary>
		/// <remarks>
		///   <see cref="Formula"/> is compiled the first time when
		///   this method is called. If you change the value of <see cref="Formula"/>
		///   afterwards the change will not be reflected in the function in 
		///   <see cref="CalculationFunction"/>. This is done to keep the sample
		///   simple.
		/// </remarks>
		public Func<EntityObject, decimal> CalculationFunction
		{
			get
			{
				if (this.function != null)
				{
					return this.function;
				}
				else
				{
					this.function = CalculationCompiler.Compile(this.Formula);
					return this.function;
				}
			}
		}
		#endregion
	}
}
