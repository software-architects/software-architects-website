﻿//------------------------------------------------------------------------------------------------------------
// <copyright file="CalculationCompiler.cs" company="software architects gmbh">
//     Copyright (c) software architects gmbh. All rights reserved.
// </copyright>
//------------------------------------------------------------------------------------------------------------

namespace SoftwareFactory.Model
{
	using System;
	using System.Globalization;
	using System.Linq;
	using System.Linq.Expressions;
	using Antlr.Runtime;
	using Antlr.Runtime.Tree;
	using SoftwareFactory.DataAccess;

	/// <summary>
	/// Implements the compiler for the domain-specific formula language.
	/// </summary>
	/// <remarks>
	/// <para>
	///   In real world we would describe the formula language here...
	/// </para>
	/// <example>
	///   Column1 / Column2 * 100
	/// </example>
	/// </remarks>
	public static class CalculationCompiler
	{
		/// <summary>
		/// Compiles the specified formula.
		/// </summary>
		/// <param name="formula">The formula.</param>
		/// <returns>Compiled function</returns>
		public static Func<EntityObject, decimal> Compile(string formula)
		{
			var stream = new ANTLRStringStream(formula);
			var lexer = new CalculatedPropertiesDslLexer(stream);
			var tokens = new CommonTokenStream(lexer);
			var parser = new CalculatedPropertiesDslParser(tokens);

			// Translate to expression tree and execute in memory
			var ast = parser.formula().Tree;
			var parameter = Expression.Parameter(typeof(EntityObject), "eo");
			var expression = TranslateAst(ast, parameter);
			var lambda = Expression.Lambda<Func<EntityObject, decimal>>(
				Expression.Convert(expression, typeof(decimal)),
				parameter);
			return lambda.Compile();
		}

		/// <summary>
		/// Translates the ast.
		/// </summary>
		/// <param name="element">The element.</param>
		/// <param name="entityObject">The entity object.</param>
		/// <returns>Expression tree.</returns>
		private static Expression TranslateAst(CommonTree element, ParameterExpression entityObject)
		{
			var binaryTranslationTable = new[] 
			{
				new { AntlrAstType = CalculatedPropertiesDslParser.PLUS, ExprTreeType = ExpressionType.Add },
				new { AntlrAstType = CalculatedPropertiesDslParser.MINUS, ExprTreeType = ExpressionType.Subtract },
				new { AntlrAstType = CalculatedPropertiesDslParser.MULT, ExprTreeType = ExpressionType.Multiply },
				new { AntlrAstType = CalculatedPropertiesDslParser.DIV, ExprTreeType = ExpressionType.Divide }
			};

			var translation = binaryTranslationTable
				.Where(t => t.AntlrAstType == element.Type)
				.SingleOrDefault();
			if (translation != null)
			{
				return Expression.MakeBinary(
					translation.ExprTreeType,
					TranslateAst(((CommonTree)element.Children[0]), entityObject),
					TranslateAst(((CommonTree)element.Children[1]), entityObject));
			}
			else
			{
				if (element.Type == CalculatedPropertiesDslParser.INT)
				{
					return Expression.Constant(Convert.ToDecimal(element.Token.Text, CultureInfo.InvariantCulture));
				}
				else
				{
					if (element.Type == CalculatedPropertiesDslParser.IDENT)
					{
						var methodInfo = typeof(EntityObject).GetMethod("GetMember");
						return Expression.Convert(
							Expression.Call(
								entityObject,
								methodInfo,
								Expression.Constant(element.Token.Text)),
							typeof(decimal));
					}
					else
					{
						throw new InvalidOperationException();
					}
				}
			}
		}
	}
}
