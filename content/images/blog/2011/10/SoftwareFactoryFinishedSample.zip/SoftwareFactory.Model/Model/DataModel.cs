﻿//------------------------------------------------------------------------------------------------------------
// <copyright file="DataModel.cs" company="software architects gmbh">
//     Copyright (c) software architects gmbh. All rights reserved.
// </copyright>
//------------------------------------------------------------------------------------------------------------

namespace SoftwareFactory.Model
{
	/// <summary>
	/// Acts as a container for all elements in the data model.
	/// </summary>
	/// <remarks>
	/// <alert class="note">
	///   Please note that this is a simplified example and not production-ready code.
	///   In real life the whole model should be implemented as a freezable (see e.g. WPF
	///   Freezable-concept) or as a immutable. This would have big advantages when it comes
	///   to sharing models across threads.
	/// </alert>
	/// </remarks>
	public class DataModel : NamedModelElement
	{
		#region Constructors
		/// <summary>
		/// Initializes a new instance of the <see cref="DataModel"/> class.
		/// </summary>
		public DataModel()
		{
			this.Entities = new NamedModelElementCollection<Entity>();
		}
		#endregion

		#region Properties
		/// <summary>
		/// Gets the entities in the data model.
		/// </summary>
		public NamedModelElementCollection<Entity> Entities { get; private set; }
		#endregion Properties
	}
}
