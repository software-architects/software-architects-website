﻿//------------------------------------------------------------------------------------------------------------
// <copyright file="Entity.cs" company="software architects gmbh">
//     Copyright (c) software architects gmbh. All rights reserved.
// </copyright>
//------------------------------------------------------------------------------------------------------------

namespace SoftwareFactory.Model
{
	/// <summary>
	/// Represents an entitiy in a <see cref="DataModel"/>.
	/// </summary>
	/// <remarks>
	/// <alert class="note">
	///   Please note that this is a simplified example and not production-ready code.
	///   In real life the whole model should be implemented as a freezable (see e.g. WPF
	///   Freezable-concept) or as a immutable. This would have big advantages when it comes
	///   to sharing models across threads.
	/// </alert>
	/// </remarks>
	public class Entity : NamedModelElement
	{
		#region Constructors
		/// <summary>
		/// Initializes a new instance of the Entity class.
		/// </summary>
		public Entity()
		{
			this.Properties = new NamedModelElementCollection<ModelProperty>();
		}
		#endregion

		#region Properties
		/// <summary>
		/// Gets the collection of properties.
		/// </summary>
		public NamedModelElementCollection<ModelProperty> Properties { get; private set; }
		#endregion
	}
}
