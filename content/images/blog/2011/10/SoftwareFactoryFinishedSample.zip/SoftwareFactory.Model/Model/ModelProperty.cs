﻿//------------------------------------------------------------------------------------------------------------
// <copyright file="ModelProperty.cs" company="software architects gmbh">
//     Copyright (c) software architects gmbh. All rights reserved.
// </copyright>
//------------------------------------------------------------------------------------------------------------

namespace SoftwareFactory.Model
{
	/// <summary>
	/// Acts as the base class for all properties.
	/// </summary>
	public abstract class ModelProperty : NamedModelElement
	{
	}
}
