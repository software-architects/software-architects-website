﻿//------------------------------------------------------------------------------------------------------------
// <copyright file="NamedModelElement.cs" company="software architects gmbh">
//     Copyright (c) software architects gmbh. All rights reserved.
// </copyright>
//------------------------------------------------------------------------------------------------------------

namespace SoftwareFactory.Model
{
	using System;
	using System.Text.RegularExpressions;

	/// <summary>
	/// Acts as a base class for all model elements that have a
	/// code, a GUID and a culture-invariant friendly name.
	/// </summary>
	/// <remarks>
	/// <alert class="note">
	///   Please note that this is a simplified example and not production-ready code.
	///   In real life the whole model should be implemented as a freezable (see e.g. WPF
	///   Freezable-concept) or as a immutable. This would have big advantages when it comes
	///   to sharing models across threads.
	/// </alert>
	/// </remarks>
	public abstract class NamedModelElement
	{
		#region Fields
		/// <summary>
		/// Regex used to check the <see cref="Code"/> property.
		/// </summary>
		private static Regex codeRegex = new Regex(@"^\p{L}(\p{L}|\d|_)*$", RegexOptions.Compiled);

		/// <summary>
		/// Holds the value for the <see cref="Code"/> property.
		/// </summary>
		private string codeValue;
		#endregion

		#region Constructors
		/// <summary>
		/// Initializes a new instance of the NamedModelElement class.
		/// </summary>
		protected NamedModelElement()
		{
			this.ElementGuid = Guid.NewGuid();
		}
		#endregion

		#region Properties
		/// <summary>
		/// Gets or sets the unique identifier of the element.
		/// </summary>
		public Guid ElementGuid { get; set; }

		/// <summary>
		/// Gets or sets the technical code of the element.
		/// </summary>
		/// <exception cref="System.ArgumentException">Thrown if supplied value does not follow naming conventions.</exception>
		/// <remarks>
		/// Code has to start with a letter. It can be followed by any comination of letters, 
		/// digits and underscores.
		/// </remarks>
		public string Code 
		{
			get
			{
				return this.codeValue;
			}

			set
			{
				if (!codeRegex.IsMatch(value))
				{
					throw new ArgumentException("No valid identifier");
				}

				this.codeValue = value;
			}
		}

		/// <summary>
		/// Gets or sets the culture-invariant friendly name of the element.
		/// </summary>
		public string InvariantFriendlyName { get; set; }
		#endregion
	}
}
