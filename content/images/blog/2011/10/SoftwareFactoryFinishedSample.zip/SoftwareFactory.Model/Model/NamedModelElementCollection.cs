﻿//------------------------------------------------------------------------------------------------------------
// <copyright file="NamedModelElementCollection.cs" company="software architects gmbh">
//     Copyright (c) software architects gmbh. All rights reserved.
// </copyright>
//------------------------------------------------------------------------------------------------------------

namespace SoftwareFactory.Model
{
	using System.Collections.ObjectModel;

	/// <summary>
	/// Implements a collection of <see cref="NamedModelElement"/> instances.
	/// </summary>
	/// <typeparam name="T">Class derived from <see cref="NamedModelElement"/>.</typeparam>
	/// <remarks>
	/// <alert class="note">
	///   Please note that this is a simplified example and not production-ready code.
	///   In real life the whole model should be implemented as a freezable (see e.g. WPF
	///   Freezable-concept) or as a immutable. This would have big advantages when it comes
	///   to sharing models across threads.
	/// </alert>
	/// </remarks>
	public class NamedModelElementCollection<T> : KeyedCollection<string, T> where T : NamedModelElement
	{
		/// <summary>
		/// Gets the <see cref="NamedModelElement.Code"/> for item.
		/// </summary>
		/// <param name="item">The item.</param>
		/// <returns><see cref="NamedModelElement.Code"/> for the item.</returns>
		protected override string GetKeyForItem(T item)
		{
			return item.Code;
		}
	}
}
