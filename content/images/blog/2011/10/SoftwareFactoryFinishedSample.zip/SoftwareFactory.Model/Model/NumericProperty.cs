﻿//------------------------------------------------------------------------------------------------------------
// <copyright file="NumericProperty.cs" company="software architects gmbh">
//     Copyright (c) software architects gmbh. All rights reserved.
// </copyright>
//------------------------------------------------------------------------------------------------------------

namespace SoftwareFactory.Model
{
	using System.Globalization;

	/// <summary>
	/// Represents a property with text content
	/// </summary>
	/// <remarks>
	/// <alert class="note">
	///   Please note that this is a simplified example and not production-ready code.
	///   In real life the whole model should be implemented as a freezable (see e.g. WPF
	///   Freezable-concept) or as a immutable. This would have big advantages when it comes
	///   to sharing models across threads.
	/// </alert>
	/// </remarks>
	public class NumericProperty : PersistedProperty
	{
		#region Properties
		/// <summary>
		/// Gets or sets the precision.
		/// </summary>
		public int Precision { get; set; }

		/// <summary>
		/// Gets or sets the scale.
		/// </summary>
		public int Scale { get; set; }

		/// <summary>
		/// Gets the DB type of the property.
		/// </summary>
		/// <value>
		/// The type of property in the database.
		/// </value>
		internal override string DBDataType
		{
			get 
			{ 
				return string.Format(
					CultureInfo.InvariantCulture, 
					"DECIMAL({0}, {1})", 
					this.Scale, 
					this.Precision); 
			}
		}
		#endregion
	}
}
