﻿//------------------------------------------------------------------------------------------------------------
// <copyright file="PersistedProperty.cs" company="software architects gmbh">
//     Copyright (c) software architects gmbh. All rights reserved.
// </copyright>
//------------------------------------------------------------------------------------------------------------

namespace SoftwareFactory.Model
{
	using System;
	using System.Linq;

	/// <summary>
	/// Acts as the base class for model properties whose value is stored in the database.
	/// </summary>
	public abstract class PersistedProperty : ModelProperty
	{
		#region Properties
		/// <summary>
		/// Gets the DB type of the property.
		/// </summary>
		/// <value>
		/// The type of property in the database.
		/// </value>
		/// <remarks>
		/// <alert class="note">
		///   This is extremely simplified. In reality there would be different data type
		///   codes for different RDBMS vendors. This is not covered in this sample. We just
		///   cover SQL Server.
		/// </alert>
		/// </remarks>
		internal abstract string DBDataType { get; }
		#endregion
	}
}
