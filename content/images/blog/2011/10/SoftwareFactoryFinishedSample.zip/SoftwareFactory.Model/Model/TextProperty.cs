﻿//------------------------------------------------------------------------------------------------------------
// <copyright file="TextProperty.cs" company="software architects gmbh">
//     Copyright (c) software architects gmbh. All rights reserved.
// </copyright>
//------------------------------------------------------------------------------------------------------------

namespace SoftwareFactory.Model
{
	using System.Globalization;

	/// <summary>
	/// Represents a property with text content
	/// </summary>
	/// <remarks>
	/// <alert class="note">
	///   Please note that this is a simplified example and not production-ready code.
	///   In real life the whole model should be implemented as a freezable (see e.g. WPF
	///   Freezable-concept) or as a immutable. This would have big advantages when it comes
	///   to sharing models across threads.
	/// </alert>
	/// </remarks>
	public class TextProperty : PersistedProperty
	{
		#region Properties
		/// <summary>
		/// Gets or sets the maximum length.
		/// </summary>
		public int MaximumLength { get; set; }

		/// <summary>
		/// Gets the DB type of the property.
		/// </summary>
		/// <value>
		/// The type of property in the database.
		/// </value>
		internal override string DBDataType
		{
			get 
			{ 
				return string.Format(
					CultureInfo.InvariantCulture, 
					"NVARCHAR({0})", 
					this.MaximumLength); 
			}
		}
		#endregion
	}
}
