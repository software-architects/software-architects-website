﻿//------------------------------------------------------------------------------------------------------------
// <copyright file="CustomerListControl.xaml.cs" company="software architects gmbh">
//     Copyright (c) software architects gmbh. All rights reserved.
// </copyright>
//------------------------------------------------------------------------------------------------------------

namespace SoftwareFactory.ModuleLibrary
{
	using System;
	using System.ComponentModel;
	using System.Linq;
	using System.Windows.Controls;
	using SoftwareFactory.DataAccess;

	/// <summary>
	/// Interaction logic for CustomerListControl.xaml
	/// </summary>
	public partial class CustomerStatisticControl : UserControl, INotifyPropertyChanged
	{
		#region Fields
		/// <summary>
		/// The current data context.
		/// </summary>
		private DataContext currentDataContext;
		#endregion

		#region Constructors
		/// <summary>
		/// Initializes a new instance of the <see cref="CustomerStatisticControl"/> class.
		/// </summary>
		/// <param name="dataContext">The data context that is used to access the underlying database.</param>
		public CustomerStatisticControl(DataContext dataContext)
		{
			this.currentDataContext = dataContext;
			this.DataContext = this;
			this.InitializeComponent();
			this.Loaded += this.OnLoaded;
		}
		#endregion

		/// <summary>
		/// Occurs when a property value changes.
		/// </summary>
		public event PropertyChangedEventHandler PropertyChanged;

		#region Properties
		/// <summary>
		/// Gets the number of customers.
		/// </summary>
		public int NumberOfCustomers { get; private set; }
		#endregion

		#region Methods
		/// <summary>
		/// Called when the Loaded event occurs.
		/// </summary>
		/// <param name="sender">The sender.</param>
		/// <param name="eventArgs">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private async void OnLoaded(object sender, EventArgs eventArgs)
		{
			var customers = await this.currentDataContext.SelectAsync(
				this.currentDataContext.Model.Entities["Customer"], Guid.Empty);
			this.NumberOfCustomers = customers.Count();
			if (this.PropertyChanged != null)
			{
				this.PropertyChanged(this, new PropertyChangedEventArgs("NumberOfCustomers"));
			}
		}
		#endregion
	}
}
