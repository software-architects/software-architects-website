﻿//------------------------------------------------------------------------------------------------------------
// <copyright file="CustomerListModule.cs" company="software architects gmbh">
//     Copyright (c) software architects gmbh. All rights reserved.
// </copyright>
//------------------------------------------------------------------------------------------------------------

namespace SoftwareFactory.ModuleLibrary
{
	using System;
	using System.ComponentModel.Composition;
	using System.Windows.Controls;
	using System.Windows.Media.Imaging;
	using SoftwareFactory.DataAccess;
	using SoftwareFactory.UIBase;

	/// <summary>
	/// Implements a module for maintaining customers
	/// </summary>
	[Export(typeof(ModuleBase))]
	public class CustomerListModule : ModuleBase
	{
		/// <summary>
		/// Control displaying the content of this module;
		/// </summary>
		private CustomerStatisticControl control;

		/// <summary>
		/// Initializes a new instance of the <see cref="CustomerListModule"/> class.
		/// </summary>
		/// <param name="dataContext">Current data context.</param>
		[ImportingConstructor]
		public CustomerListModule(
			[Import("CurrentDataContext")]
			DataContext dataContext)
			: base(dataContext)
		{
		}

		/// <summary>
		/// Gets the content.
		/// </summary>
		public override Control Content
		{
			get
			{
				return this.control;
			}
		}

		/// <summary>
		/// Initializes the component.
		/// </summary>
		public override void InitializeComponent()
		{
			base.InitializeComponent();

			this.ModuleActivationButton.Label = "CustomerStatistic";
			this.ModuleActivationButton.SmallImageSource = new BitmapImage(new Uri("/Icons/index2_small.png", UriKind.Relative));
			this.ModuleActivationButton.LargeImageSource = new BitmapImage(new Uri("/Icons/index2_large.png", UriKind.Relative));

			this.control = new CustomerStatisticControl(this.DataContext);
		}
	}
}
