﻿//------------------------------------------------------------------------------------------------------------
// <copyright file="DataModelingConsoleControl.cs" company="software architects gmbh">
//     Copyright (c) software architects gmbh. All rights reserved.
// </copyright>
//------------------------------------------------------------------------------------------------------------

namespace SoftwareFactory.ModuleLibrary
{
	using System;
	using System.IO;
	using System.Xaml;
	using SoftwareFactory.DataAccess;
	using SoftwareFactory.Model;

	/// <summary>
	/// Implements the Script Console.
	/// </summary>
	public class DataModelingConsoleControl : GenericScriptConsoleControl
	{
		#region Constructors
		/// <summary>
		/// Initializes a new instance of the <see cref="DataModelingConsoleControl"/> class.
		/// </summary>
		/// <param name="dataContext">Data context used to access the underlying database.</param>
		public DataModelingConsoleControl(DataContext dataContext)
			: base(dataContext)
		{
		}
		#endregion

		#region Methods
		/// <summary>
		/// Called when the user clicks 'run'.
		/// </summary>
		protected override async void OnRun()
		{
			try
			{
				using (var reader = new StringReader(this.ScriptContent))
				{
					var dataModel = XamlServices.Load(reader) as DataModel;
					var newDataContext = new DataContext(
						this.UnderlyingDataContext.ConnectionString,
						dataModel);
					await newDataContext.CreateSchemaAsync();
				}
			}
			catch (Exception e)
			{
				this.AppendToScriptOutput(e.Message + "\n");
				this.OnPropertyChanged("ScriptOutput");
			}
			finally
			{
				this.AppendToScriptOutput("Done!\n");
				this.OnPropertyChanged("ScriptOutput");
			}
		}
		#endregion
	}
}
