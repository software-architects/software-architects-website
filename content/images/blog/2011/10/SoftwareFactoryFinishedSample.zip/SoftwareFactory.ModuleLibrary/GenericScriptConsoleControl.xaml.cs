﻿//------------------------------------------------------------------------------------------------------------
// <copyright file="GenericScriptConsoleControl.xaml.cs" company="software architects gmbh">
//     Copyright (c) software architects gmbh. All rights reserved.
// </copyright>
//------------------------------------------------------------------------------------------------------------

namespace SoftwareFactory.ModuleLibrary
{
	using System;
	using System.ComponentModel;
	using System.Text;
	using System.Windows.Controls;
	using System.Windows.Input;
	using SoftwareFactory.DataAccess;
	using SoftwareFactory.UIBase;

	/// <summary>
	/// Interaction logic for CustomerListControl.xaml
	/// </summary>
	public abstract partial class GenericScriptConsoleControl : UserControl, INotifyPropertyChanged
	{
		/// <summary>
		/// Holds the ouput of the script.
		/// </summary>
		private StringBuilder scriptOutput = new StringBuilder();

		/// <summary>
		/// Initializes a new instance of the <see cref="GenericScriptConsoleControl"/> class.
		/// </summary>
		/// <param name="dataContext">Data context used to access the underlying database.</param>
		public GenericScriptConsoleControl(DataContext dataContext)
		{
			this.UnderlyingDataContext = dataContext;
			this.DataContext = this;
			this.RunScriptCommand = new GenericAlwaysExecutableCommand((p) => this.OnRun());
			this.InitializeComponent();
		}

		/// <summary>
		/// Occurs when a property value changes.
		/// </summary>
		public event PropertyChangedEventHandler PropertyChanged;

		/// <summary>
		/// Gets the script output.
		/// </summary>
		public string ScriptOutput
		{
			get
			{
				lock (this.scriptOutput)
				{
					return this.scriptOutput.ToString();
				}
			}
		}

		/// <summary>
		/// Gets or sets the content of the script.
		/// </summary>
		public string ScriptContent { get; set; }

		/// <summary>
		/// Gets the run script command.
		/// </summary>
		public ICommand RunScriptCommand { get; private set; }

		/// <summary>
		/// Gets the underlying data context.
		/// </summary>
		protected DataContext UnderlyingDataContext { get; private set; }

		/// <summary>
		/// Appends to script output.
		/// </summary>
		/// <param name="value">The value.</param>
		internal void AppendToScriptOutput(string value)
		{
			lock (this.scriptOutput)
			{
				this.scriptOutput.Append(value);
			}
		}

		/// <summary>
		/// Appends to script output.
		/// </summary>
		/// <param name="format">The format.</param>
		/// <param name="args">The args.</param>
		internal void AppendToScriptOutput(string format, params object[] args)
		{
			lock (this.scriptOutput)
			{
				this.scriptOutput.AppendFormat(format, args);
			}
		}

		/// <summary>
		/// Fires <see cref="PropertyChanged"/> event.
		/// </summary>
		/// <param name="propertyName">Name of the property.</param>
		internal void OnPropertyChanged(string propertyName)
		{
			if (this.PropertyChanged != null)
			{
				this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		/// <summary>
		/// Called when the user clicks 'run'.
		/// </summary>
		protected abstract void OnRun();
	}
}
