﻿//------------------------------------------------------------------------------------------------------------
// <copyright file="ScriptConsoleControl.cs" company="software architects gmbh">
//     Copyright (c) software architects gmbh. All rights reserved.
// </copyright>
//------------------------------------------------------------------------------------------------------------

namespace SoftwareFactory.ModuleLibrary
{
	using System;
	using System.Diagnostics.CodeAnalysis;
	using System.Text;
	using System.Threading.Tasks;
	using IronPython.Hosting;
	using Microsoft.Scripting;
	using SoftwareFactory.DataAccess;

	/// <summary>
	/// Implements the Script Console.
	/// </summary>
	public class ScriptConsoleControl : GenericScriptConsoleControl
	{
		#region Constructors
		/// <summary>
		/// Initializes a new instance of the <see cref="ScriptConsoleControl"/> class.
		/// </summary>
		/// <param name="dataContext">Data context used to access the underlying database.</param>
		public ScriptConsoleControl(DataContext dataContext)
			: base(dataContext)
		{
		}
		#endregion

		#region Methods
		/// <summary>
		/// Called when the user clicks 'run'.
		/// </summary>
		[SuppressMessage("Microsoft.Design", "CA1031", Justification = "Catching of Exception is ok here.")]
		protected override async void OnRun()
		{
			try
			{
				await Task.Factory.StartNew(() =>
					{
						var engine = Python.CreateEngine();
						var scope = engine.CreateScope();
						scope.SetVariable("Context", this.UnderlyingDataContext);
						using (var stream = new ScriptOutputStream(
							s =>
							{
								this.AppendToScriptOutput(s);
								this.Dispatcher.BeginInvoke(new Action(() => this.OnPropertyChanged("ScriptOutput")));
							},
							Encoding.UTF8))
						{
							engine.Runtime.IO.SetOutput(stream, Encoding.UTF8);
							var scriptSource = engine.CreateScriptSourceFromString(this.ScriptContent);
							scriptSource.Execute(scope);
						}
					});
			}
			catch (SyntaxErrorException e)
			{
				this.AppendToScriptOutput("Syntax error (line {0}, column {1}): {2}", e.Line, e.Column, e.Message);
				this.OnPropertyChanged("ScriptOutput");
			}
			catch (Exception e)
			{
				this.AppendToScriptOutput(e.Message + "\n");
				this.OnPropertyChanged("ScriptOutput");
			}
		}
		#endregion
	}
}
