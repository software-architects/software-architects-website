﻿//------------------------------------------------------------------------------------------------------------
// <copyright file="ScriptConsoleModule.cs" company="software architects gmbh">
//     Copyright (c) software architects gmbh. All rights reserved.
// </copyright>
//------------------------------------------------------------------------------------------------------------

namespace SoftwareFactory.ModuleLibrary
{
	using System;
	using System.ComponentModel.Composition;
	using System.Diagnostics.CodeAnalysis;
	using System.Windows.Controls;
	using System.Windows.Media.Imaging;
	using SoftwareFactory.DataAccess;
	using SoftwareFactory.UIBase;

	/// <summary>
	/// Implements a module for maintaining customers
	/// </summary>
	[Export(typeof(ModuleBase))]
	public class ScriptConsoleModule : ModuleBase
	{
		/// <summary>
		/// Control displaying the content of this module;
		/// </summary>
		private ScriptConsoleControl control;

		/// <summary>
		/// Initializes a new instance of the <see cref="ScriptConsoleModule"/> class.
		/// </summary>
		/// <param name="dataContext">Current data context.</param>
		[ImportingConstructor]
		public ScriptConsoleModule(
			[Import("CurrentDataContext")]
			DataContext dataContext)
			: base(dataContext)
		{
		}

		/// <summary>
		/// Gets the content.
		/// </summary>
		public override Control Content
		{
			get
			{
				return this.control;
			}
		}

		/// <summary>
		/// Initializes the component.
		/// </summary>
		[SuppressMessage("Microsoft.Design", "CA1031", Justification = "Exception has to be catched here.")]
		public override void InitializeComponent()
		{
			base.InitializeComponent();

			this.ModuleActivationButton.Label = "Script";
			this.ModuleActivationButton.SmallImageSource = new BitmapImage(new Uri("/Icons/scroll_small.png", UriKind.Relative));
			this.ModuleActivationButton.LargeImageSource = new BitmapImage(new Uri("/Icons/scroll_large.png", UriKind.Relative));

			this.control = new ScriptConsoleControl(this.DataContext);
		}
	}
}
