﻿//------------------------------------------------------------------------------------------------------------
// <copyright file="ScriptOutputStream.cs" company="software architects gmbh">
//     Copyright (c) software architects gmbh. All rights reserved.
// </copyright>
//------------------------------------------------------------------------------------------------------------

namespace SoftwareFactory.ModuleLibrary
{
	using System;
	using System.Collections.Concurrent;
	using System.Diagnostics.CodeAnalysis;
	using System.IO;
	using System.Text;
	using System.Threading.Tasks;

	/// <summary>
	/// Implements a stream for script output
	/// </summary>
	public sealed class ScriptOutputStream : Stream
	{
		/// <summary>
		/// Action used to write data to the stream.
		/// </summary>
		private Action<string> write;

		/// <summary>
		/// The Encoding of the stream.
		/// </summary>
		private Encoding encoding;

		/// <summary>
		/// Helper that holds chunks of bytes.
		/// </summary>
		private BlockingCollection<byte[]> chunks;

		/// <summary>
		/// Task used to do processing in the background.
		/// </summary>
		private Task processingTask;

		/// <summary>
		/// Initializes a new instance of the <see cref="ScriptOutputStream"/> class.
		/// </summary>
		/// <param name="write">The action used to write data to the stream.</param>
		/// <param name="encoding">The encoding.</param>
		public ScriptOutputStream(Action<string> write, Encoding encoding)
		{
			this.write = write;
			this.encoding = encoding;
			this.chunks = new BlockingCollection<byte[]>();
			this.processingTask = Task.Factory.StartNew(this.WriteChunksProzess, TaskCreationOptions.LongRunning);
		}

		/// <summary>
		/// When overridden in a derived class, gets the length in bytes of the stream.
		/// </summary>
		/// <returns>A long value representing the length of the stream in bytes.</returns>
		[SuppressMessage("Microsoft.Design", "CA1065", Justification = "Just for demo purposes")]
		public override long Length
		{
			get { throw new NotImplementedException(); }
		}

		/// <summary>
		/// When overridden in a derived class, gets or sets the position within the current stream.
		/// </summary>
		/// <returns>The current position within the stream.</returns>
		[SuppressMessage("Microsoft.Design", "CA1065", Justification = "Just for demo purposes")]
		public override long Position
		{
			get
			{
				throw new NotImplementedException();
			}

			set
			{
				throw new NotImplementedException();
			}
		}

		/// <summary>
		/// When overridden in a derived class, gets a value indicating whether the current stream supports reading.
		/// </summary>
		/// <returns>true if the stream supports reading; otherwise, false.</returns>
		public override bool CanRead
		{
			get { return false; }
		}

		/// <summary>
		/// When overridden in a derived class, gets a value indicating whether the current stream supports writing.
		/// </summary>
		/// <returns>true if the stream supports writing; otherwise, false.</returns>
		public override bool CanWrite
		{
			get { return true; }
		}

		/// <summary>
		/// When overridden in a derived class, gets a value indicating whether the current stream supports seeking.
		/// </summary>
		/// <returns>true if the stream supports seeking; otherwise, false.</returns>
		public override bool CanSeek
		{
			get { return false; }
		}

		/// <summary>
		/// When overridden in a derived class, writes a sequence of bytes to the current stream and advances the current position within this stream by the number of bytes written.
		/// </summary>
		/// <param name="buffer">An array of bytes. This method copies <paramref name="count"/> bytes from <paramref name="buffer"/> to the current stream.</param>
		/// <param name="offset">The zero-based byte offset in <paramref name="buffer"/> at which to begin copying bytes to the current stream.</param>
		/// <param name="count">The number of bytes to be written to the current stream.</param>
		public override void Write(byte[] buffer, int offset, int count)
		{
			var chunk = new byte[count];
			Buffer.BlockCopy(buffer, offset, chunk, 0, count);
			this.chunks.Add(chunk);
		}

		/// <summary>
		/// Closes the current stream and releases any resources (such as sockets and file handles) associated with the current stream.
		/// </summary>
		public override void Close()
		{
			this.chunks.CompleteAdding();
			try
			{
				this.processingTask.Wait();
			}
			finally
			{
				base.Close();
			}
		}

		/// <summary>
		/// When overridden in a derived class, clears all buffers for this stream and causes any buffered data to be written to the underlying device.
		/// </summary>
		/// <exception cref="T:System.IO.IOException">An I/O error occurs. </exception>
		public override void Flush()
		{
		}

		/// <summary>
		/// When overridden in a derived class, reads a sequence of bytes from the current stream and advances the position within the stream by the number of bytes read.
		/// </summary>
		/// <param name="buffer">An array of bytes. When this method returns, the buffer contains the specified byte array with the values between <paramref name="offset"/> and (<paramref name="offset"/> + <paramref name="count"/> - 1) replaced by the bytes read from the current source.</param>
		/// <param name="offset">The zero-based byte offset in <paramref name="buffer"/> at which to begin storing the data read from the current stream.</param>
		/// <param name="count">The maximum number of bytes to be read from the current stream.</param>
		/// <returns>
		/// The total number of bytes read into the buffer. This can be less than the number of bytes requested if that many bytes are not currently available, or zero (0) if the end of the stream has been reached.
		/// </returns>
		public override int Read(byte[] buffer, int offset, int count)
		{
			throw new NotImplementedException();
		}

		/// <summary>
		/// When overridden in a derived class, sets the position within the current stream.
		/// </summary>
		/// <param name="offset">A byte offset relative to the <paramref name="origin"/> parameter.</param>
		/// <param name="origin">A value of type <see cref="T:System.IO.SeekOrigin"/> indicating the reference point used to obtain the new position.</param>
		/// <returns>
		/// The new position within the current stream.
		/// </returns>
		public override long Seek(long offset, SeekOrigin origin)
		{
			throw new NotImplementedException();
		}

		/// <summary>
		/// When overridden in a derived class, sets the length of the current stream.
		/// </summary>
		/// <param name="value">The desired length of the current stream in bytes.</param>
		public override void SetLength(long value)
		{
			throw new NotImplementedException();
		}

		/// <summary>
		/// Writes the chunks.
		/// </summary>
		private void WriteChunksProzess()
		{
			foreach (var chunk in this.chunks.GetConsumingEnumerable())
			{
				this.write(this.encoding.GetString(chunk));
			}
		}
	}
}
