﻿//------------------------------------------------------------------------------------------------------------
// <copyright file="TestModel.cs" company="software architects gmbh">
//     Copyright (c) software architects gmbh. All rights reserved.
// </copyright>
//------------------------------------------------------------------------------------------------------------

namespace SoftwareFactory.Test
{
	using System;
	using System.Configuration;
	using System.Data.SqlClient;
	using System.IO;
	using System.Linq;
	using System.Reflection;
	using System.Xaml;
	using Microsoft.VisualStudio.TestTools.UnitTesting;
	using SoftwareFactory.DataAccess;
	using SoftwareFactory.Model;

	/// <summary>
	/// Test class for project SoftwareFactory.Model
	/// </summary>
	[TestClass]
	public class TestModel
	{
		/// <summary>
		/// Tests the xaml deserialization.
		/// </summary>
		/// <remarks>
		/// Tries to load the file DataModel.xaml
		/// </remarks>
		[TestMethod]
		public void TestXamlDeserialization()
		{
			var dataModel = ReadModelFromXaml();

			Assert.AreEqual(2, dataModel.Entities.Count);
			Assert.AreEqual(5, dataModel.Entities["Customer"].Properties.Count());
			Assert.AreEqual(3, dataModel.Entities["Employees"].Properties.Count());
		}

		/// <summary>
		/// Tests the creation of tables based on a model.
		/// </summary>
		[TestMethod]
		public void TestModelDatabaseCreation()
		{
			var testConnectionString = ConfigurationManager.AppSettings["TestServerTestDB"];
			RecreateTestDatabase();

			var dataModel = ReadModelFromXaml();
			var context = new DataContext(testConnectionString, dataModel);
			context.CreateSchemaAsync().Wait();

			EntityObject newCustomer;
			dynamic dynamicCustomer = newCustomer = EntityObject.CreateObject(dataModel.Entities["Customer"]);
			dynamicCustomer.CustomerCode = "1000";
			dynamicCustomer.CustomerDescription = "software architects gmbh";
			dynamicCustomer.RevenueYTD = 1000;
			dynamicCustomer.RevenuePrevYear = 1500;
			context.InsertAsync(newCustomer).Wait();

			context.SelectAsync(dataModel.Entities["Customer"], Guid.Empty).ContinueWith(task =>
				{
					Assert.AreEqual(1, task.Result.Count());

					var firstResult = task.Result.First();
					Assert.AreEqual(
						Convert.ToDecimal(dynamicCustomer.RevenueYTD / dynamicCustomer.RevenuePrevYear * 100),
						firstResult.GetMember("TargetRatio"));
				}).Wait();
		}

		/// <summary>
		/// Reads the model from xaml.
		/// </summary>
		/// <returns>The Model.</returns>
		private static DataModel ReadModelFromXaml()
		{
			var path = Path.Combine(
				Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location),
				"DataModel.xaml");
			return XamlServices.Load(path) as DataModel;
		}

		/// <summary>
		/// Recreates the test database.
		/// </summary>
		private static void RecreateTestDatabase()
		{
			var masterConnectionString = ConfigurationManager.AppSettings["TestServerMasterDB"];

			using (var connection = new SqlConnection(masterConnectionString))
			{
				connection.Open();
				using (var command = connection.CreateCommand())
				{
					command.CommandText = @"
IF EXISTS(SELECT 1 FROM sys.databases WHERE name = 'SoftwareFactoryTest')
	DROP DATABASE SoftwareFactoryTest;
CREATE DATABASE SoftwareFactoryTest ON PRIMARY
( NAME = 'SoftwareFactoryTest', FILENAME = 'c:\Program Files\Microsoft SQL Server\MSSQL10_50.SQLEXPRESS\MSSQL\DATA\SoftwareFactoryTest.mdf' )
LOG ON ( NAME = 'SoftwareFactoryTest_log', FILENAME = 'c:\Program Files\Microsoft SQL Server\MSSQL10_50.SQLEXPRESS\MSSQL\DATA\SoftwareFactoryTest_log.ldf' )
";
					command.ExecuteNonQuery();
				}
			}
		}
	}
}
