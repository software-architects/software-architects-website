﻿//------------------------------------------------------------------------------------------------------------
// <copyright file="App.xaml.cs" company="software architects gmbh">
//     Copyright (c) software architects gmbh. All rights reserved.
// </copyright>
//------------------------------------------------------------------------------------------------------------

namespace SoftwareFactory.UI
{
	using System;
	using System.Collections.Generic;
	using System.Configuration;
	using System.Data;
	using System.Linq;
	using System.Windows;

	/// <summary>
	/// Interaction logic for App.xaml
	/// </summary>
	public partial class App : Application
	{
	}
}
