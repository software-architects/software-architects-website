﻿//------------------------------------------------------------------------------------------------------------
// <copyright file="MainWindow.xaml.cs" company="software architects gmbh">
//     Copyright (c) software architects gmbh. All rights reserved.
// </copyright>
//------------------------------------------------------------------------------------------------------------

namespace SoftwareFactory.UI
{
	using System.Collections.Generic;
	using System.Collections.ObjectModel;
	using System.ComponentModel.Composition;
	using System.ComponentModel.Composition.Hosting;
	using System.Configuration;
	using System.IO;
	using System.Linq;
	using System.Reflection;
	using System.Threading.Tasks;
	using System.Xaml;
	using Microsoft.Windows.Controls.Ribbon;
	using SoftwareFactory.DataAccess;
	using SoftwareFactory.Model;
	using SoftwareFactory.UIBase;

	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : RibbonWindow
	{
		#region Constructors
		/// <summary>
		/// Initializes a new instance of the <see cref="MainWindow"/> class.
		/// </summary>
		public MainWindow()
		{
			this.ModuleButtons = new ObservableCollection<RibbonButton>();

			this.DataContext = this;
			this.InitializeComponent();

			// Load modules asynchronous to keep UI fast and fluid.
			this.RefreshModuleButtons();
		}
		#endregion

		#region Properties
		/// <summary>
		/// Gets or sets the modules.
		/// </summary>
		[ImportMany(typeof(ModuleBase), AllowRecomposition = true)]
		public List<ModuleBase> Modules { get; set; }

		/// <summary>
		/// Gets the module buttons.
		/// </summary>
		public ObservableCollection<RibbonButton> ModuleButtons { get; private set; }

		/// <summary>
		/// Gets the current data context.
		/// </summary>
		[Export("CurrentDataContext")]
		public DataContext CurrentDataContext { get; private set; }
		#endregion

		#region Methods
		/// <summary>
		/// Refreshes the module buttons.
		/// </summary>
		private async void RefreshModuleButtons()
		{
			// Time-consuming tasks are done in the background.
			this.CurrentDataContext = await this.GetDataContextAsync();
			await this.ComposePartsAsync();

			// Initialize modules (has to be done on UI thread; that's ok because
			// this will be fast).
			foreach (var module in this.Modules)
			{
				module.InitializeComponent();
			}

			// Initialize module buttons (has to be done on UI thread).
			this.ModuleButtons.Clear();
			var buttons = this.Modules.Select(m => new RibbonButton()
			{
				Label = m.ModuleActivationButton.Label,
				SmallImageSource = m.ModuleActivationButton.SmallImageSource,
				LargeImageSource = m.ModuleActivationButton.LargeImageSource,
				Command = new GenericAlwaysExecutableCommand(
					(p) => { this.ContentControl.Content = m.Content; })
			});
			foreach (var button in buttons)
			{
				this.ModuleButtons.Add(button);
			}
		}

		/// <summary>
		/// Gets the data context async.
		/// </summary>
		/// <returns>Task representing the job.</returns>
		private Task<DataContext> GetDataContextAsync()
		{
			return Task.Factory.StartNew<DataContext>(() =>
			{
				var path = Path.Combine(
					Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location),
					"DataModel.xaml");
				var dataModel = XamlServices.Load(path) as DataModel;

				return new DataContext(
					ConfigurationManager.AppSettings["TestServerTestDB"],
					dataModel);
			});
		}

		/// <summary>
		/// Composes the parts async.
		/// </summary>
		/// <returns>Task representing the job.</returns>
		private Task ComposePartsAsync()
		{
			return Task.Factory.StartNew(() =>
				{
					var catalog = new DirectoryCatalog(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));
					var assemblyCatalog = new AssemblyCatalog(this.GetType().Assembly);
					var container = new CompositionContainer(new AggregateCatalog(catalog, assemblyCatalog));
					container.ComposeParts(this);
				});
		}
		#endregion
	}
}
