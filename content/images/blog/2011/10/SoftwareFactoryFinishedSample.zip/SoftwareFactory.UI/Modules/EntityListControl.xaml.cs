﻿//------------------------------------------------------------------------------------------------------------
// <copyright file="EntityListControl.xaml.cs" company="software architects gmbh">
//     Copyright (c) software architects gmbh. All rights reserved.
// </copyright>
//------------------------------------------------------------------------------------------------------------

namespace SoftwareFactory.UI.Modules
{
	using System;
	using System.Collections.ObjectModel;
	using System.ComponentModel;
	using System.Linq;
	using System.Windows.Controls;
	using System.Windows.Data;
	using SoftwareFactory.DataAccess;
	using SoftwareFactory.Model;

	/// <summary>
	/// Interaction logic for EntityListControl.xaml
	/// </summary>
	public partial class EntityListControl : UserControl, INotifyPropertyChanged
	{
		#region Fields
		/// <summary>
		/// Currently selected entity.
		/// </summary>
		private Entity selectedEntity;
		#endregion

		#region Constructors
		/// <summary>
		/// Initializes a new instance of the <see cref="EntityListControl"/> class.
		/// </summary>
		/// <param name="dataContext">The data context that is used to access the underlying database.</param>
		public EntityListControl(DataContext dataContext)
		{
			this.CurrentDataContext = dataContext;
			this.DataContext = this;
			this.Rows = new ObservableCollection<dynamic>();
			this.InitializeComponent();

			this.SelectedEntity = dataContext.Model.Entities.FirstOrDefault();
		}
		#endregion

		/// <summary>
		/// Occurs when a property value changes.
		/// </summary>
		public event PropertyChangedEventHandler PropertyChanged;

		#region Properties
		/// <summary>
		/// Gets the customers collection.
		/// </summary>
		public ObservableCollection<dynamic> Rows { get; private set; }

		/// <summary>
		/// Gets the current data context.
		/// </summary>
		public DataContext CurrentDataContext { get; private set; }

		/// <summary>
		/// Gets or sets the selected entity.
		/// </summary>
		public Entity SelectedEntity 
		{
			get
			{
				return this.selectedEntity;
			}

			set
			{
				this.selectedEntity = value;
				if (this.PropertyChanged != null)
				{
					this.PropertyChanged(this, new PropertyChangedEventArgs("SelectedEntity"));
				}

				this.RefreshEntityListAsync();
			}
		}
		#endregion

		#region Methods
		/// <summary>
		/// Refreshes the entity list async.
		/// </summary>
		private async void RefreshEntityListAsync()
		{
			if (this.SelectedEntity != null)
			{
				this.ContentGrid.Columns.Clear();
				foreach (var property in this.SelectedEntity.Properties)
				{
					this.ContentGrid.Columns.Add(new DataGridTextColumn()
					{
						Header = property.InvariantFriendlyName,
						Binding = new Binding(property.Code)
					});
				}

				var result = await this.CurrentDataContext.SelectAsync(
					this.SelectedEntity,
					Guid.Empty);
				this.Rows.Clear();
				foreach (var row in result)
				{
					this.Rows.Add(row);
				}
			}
		}
		#endregion
	}
}
