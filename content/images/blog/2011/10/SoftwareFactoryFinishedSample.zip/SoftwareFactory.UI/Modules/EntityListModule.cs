﻿//------------------------------------------------------------------------------------------------------------
// <copyright file="EntityListModule.cs" company="software architects gmbh">
//     Copyright (c) software architects gmbh. All rights reserved.
// </copyright>
//------------------------------------------------------------------------------------------------------------

namespace SoftwareFactory.UI.Modules
{
	using System;
	using System.ComponentModel.Composition;
	using System.Windows.Controls;
	using System.Windows.Media.Imaging;
	using SoftwareFactory.DataAccess;
	using SoftwareFactory.UIBase;

	/// <summary>
	/// Implements a module for maintaining rows stored in an entity
	/// </summary>
	[Export(typeof(ModuleBase))]
	public class EntityListModule : ModuleBase
	{
		/// <summary>
		/// Control displaying the content of this module;
		/// </summary>
		private EntityListControl control;

		/// <summary>
		/// Initializes a new instance of the <see cref="EntityListModule"/> class.
		/// </summary>
		/// <param name="dataContext">Current data context.</param>
		[ImportingConstructor]
		public EntityListModule(
			[Import("CurrentDataContext")]
			DataContext dataContext)
			: base(dataContext)
		{
		}

		/// <summary>
		/// Gets the content.
		/// </summary>
		public override Control Content
		{
			get
			{
				return this.control;
			}
		}

		/// <summary>
		/// Initializes the component.
		/// </summary>
		public override void InitializeComponent()
		{
			base.InitializeComponent();

			this.ModuleActivationButton.Label = "Base Data";
			this.ModuleActivationButton.SmallImageSource = new BitmapImage(new Uri("/Icons/data_table_small.png", UriKind.Relative));
			this.ModuleActivationButton.LargeImageSource = new BitmapImage(new Uri("/Icons/data_table_large.png", UriKind.Relative));

			this.control = new EntityListControl(this.DataContext);
		}
	}
}
