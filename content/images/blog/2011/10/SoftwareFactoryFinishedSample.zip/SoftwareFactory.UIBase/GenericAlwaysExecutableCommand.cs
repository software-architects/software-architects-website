﻿//------------------------------------------------------------------------------------------------------------
// <copyright file="GenericAlwaysExecutableCommand.cs" company="software architects gmbh">
//     Copyright (c) software architects gmbh. All rights reserved.
// </copyright>
//------------------------------------------------------------------------------------------------------------

namespace SoftwareFactory.UIBase
{
	using System;
	using System.Windows.Input;

	/// <summary>
	/// Implements a generic command that can be initialized using a lambda expression.
	/// </summary>
	/// <remarks>
	///   This class does not support providing a lambda for "can execute". The command
	///   has to be always executable by definition.
	/// </remarks>
	public class GenericAlwaysExecutableCommand : ICommand
	{
		#region Fields
		/// <summary>
		/// Stores the action for <see cref="Execute"/>.
		/// </summary>
		private Action<object> execute;
		#endregion

		#region Constructors
		/// <summary>
		/// Initializes a new instance of the <see cref="GenericAlwaysExecutableCommand"/> class.
		/// </summary>
		/// <param name="execute">The execute.</param>
		public GenericAlwaysExecutableCommand(Action<object> execute)
		{
			this.execute = execute;
		}
		#endregion

#pragma warning disable 0067
		/// <summary>
		/// Occurs when changes occur that affect whether or not the command should execute.
		/// </summary>
		public event EventHandler CanExecuteChanged;
#pragma warning restore 0067

		/// <summary>
		/// Defines the method that determines whether the command can execute in its current state.
		/// </summary>
		/// <param name="parameter">Data used by the command. Not used.</param>
		/// <returns>
		/// In this implementation always true.
		/// </returns>
		public bool CanExecute(object parameter)
		{
			return true;
		}

		/// <summary>
		/// Defines the method to be called when the command is invoked.
		/// </summary>
		/// <param name="parameter">Data used by the command.</param>
		public void Execute(object parameter)
		{
			this.execute(parameter);
		}
	}
}
