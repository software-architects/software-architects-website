﻿//------------------------------------------------------------------------------------------------------------
// <copyright file="ModuleBase.cs" company="software architects gmbh">
//     Copyright (c) software architects gmbh. All rights reserved.
// </copyright>
//------------------------------------------------------------------------------------------------------------

namespace SoftwareFactory.UIBase
{
	using System;
	using System.Windows.Controls;
	using System.Windows.Media.Imaging;
	using Microsoft.Windows.Controls.Ribbon;
	using SoftwareFactory.DataAccess;

	/// <summary>
	/// Acts as the base class for all modules
	/// </summary>
	public abstract class ModuleBase
	{
		#region Constructors
		/// <summary>
		/// Initializes a new instance of the <see cref="ModuleBase"/> class.
		/// </summary>
		/// <param name="dataContext">Data context that the module can use to access the underlying database.</param>
		protected ModuleBase(DataContext dataContext)
		{
			this.DataContext = dataContext;
		}
		#endregion

		#region Properties
		/// <summary>
		/// Gets the module activation button.
		/// </summary>
		public RibbonButton ModuleActivationButton { get; private set; }

		/// <summary>
		/// Gets the content.
		/// </summary>
		public abstract Control Content { get; }

		/// <summary>
		/// Gets the data context.
		/// </summary>
		protected DataContext DataContext { get; private set; }
		#endregion

		#region Methods
		/// <summary>
		/// Initializes the component.
		/// </summary>
		/// <remarks>
		///   <para>
		///     Creates a default button in <see cref="ModuleActivationButton"/>.
		///     Classes that override this method should call this base implementation first.
		///     Afterwards they can customize the button in <see cref="ModuleActivationButton"/>
		///     as needed (e.g. set label, add image sources, etc.).
		///   </para>
		///   <para>
		///     Because this initialization method runs on the UI thread derived classes
		///     should not do expensive work here. Implement time-consuming initialization tasks
		///     in background processes instead.
		///   </para>
		/// </remarks>
		public virtual void InitializeComponent()
		{
			this.ModuleActivationButton = new RibbonButton()
			{
				Label = this.GetType().Name,
				SmallImageSource = new BitmapImage(new Uri("/Icons/window_error_small.png", UriKind.Relative)),
				LargeImageSource = new BitmapImage(new Uri("/Icons/window_error_large.png", UriKind.Relative)),
			};
		}
		#endregion
	}
}
