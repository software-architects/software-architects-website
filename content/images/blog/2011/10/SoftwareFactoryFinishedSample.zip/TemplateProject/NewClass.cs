﻿//------------------------------------------------------------------------------------------------------------
// <copyright file="$safeitemname$.cs" company="software architects gmbh">
//     Copyright (c) software architects gmbh. All rights reserved.
// </copyright>
//------------------------------------------------------------------------------------------------------------

namespace $rootnamespace$
{
	using System;
	using System.Linq;

	/// <summary>
	/// TODO: Add class documentation here
	/// </summary>
	class $safeitemname$
	{
		#region Fields
		#endregion

		#region Constructors
		#endregion

		#region Properties
		#endregion

		#region Methods
		#endregion
	}
}
