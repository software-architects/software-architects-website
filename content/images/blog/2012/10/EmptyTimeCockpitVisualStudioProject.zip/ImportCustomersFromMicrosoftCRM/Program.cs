﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TimeCockpit.Data;

namespace ImportCustomersFromMicrosoftCRM
{
	class Program
	{
		static void Main(string[] args)
		{
			try
			{
				// Connect to time cockpit
				using (var dataContext = DataContext.Create("username", "password"))
				{
					Console.WriteLine("Connected to time cockpit");
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.ToString());
			}

			Console.ReadKey();
		}
	}
}
