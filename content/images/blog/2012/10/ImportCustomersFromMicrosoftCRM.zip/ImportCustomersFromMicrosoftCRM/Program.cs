﻿using Microsoft.Xrm.Client;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using TimeCockpit.Data;

namespace ImportCustomersFromMicrosoftCRM
{
	class Program
	{
		static void Main(string[] args)
		{
			try
			{
				// Connect to time cockpit
				Console.WriteLine("Connect to time cockpit ...");
				using (var timeCockpitDataContext = DataContext.Create(ConfigurationManager.AppSettings["timecockpitUsername"], ConfigurationManager.AppSettings["timecockpitPassword"]))
				{
					// Connect to crm online
					Console.WriteLine("Connect to crm online ...");
					using (var crmContext = new CrmOrganizationServiceContext(new CrmConnection("Xrm")))
					{
						// Get customers from time cockpit
						Console.WriteLine("Get customers from time cockpit ...");
						var timeCockpitCustomers = timeCockpitDataContext.Select("From C In Customer Where C.CrmUuid <> Null Select C").ToDictionary(c => (Guid)c.GetMember("CrmUuid"));

						// Get countries from time cockpit
						Console.WriteLine("Get countries from time cockpit ...");
						var timeCockpitCountries = timeCockpitDataContext.Select("From C In Country Where C.CountryName <> Null Select C").ToDictionary(c => (string)c.GetMember("CountryName"));

						// Get customers from crm online
						Console.WriteLine("Get customers from crm online ...");
						var query = new QueryExpression();
						query.EntityName = "account";
						query.ColumnSet = new ColumnSet(new string[] { "accountid", "accountnumber", "name", "emailaddress1", "fax", "address1_telephone1", "address1_line1", "address1_city", "address1_postalcode", "address1_country" });
						var crmAccounts = crmContext.RetrieveMultiple(query);

						// Save customers
						Console.WriteLine("Save customers ...");
						var customerEntity = timeCockpitDataContext.Model.Entities["Customer"];

						foreach (var crmCustomer in crmAccounts.Entities)
						{
							try
							{
								// Check if customer exists in time cockpit
								EntityObject timeCockpitCustomer = null;
								if (timeCockpitCustomers.ContainsKey(crmCustomer.Id))
								{
									timeCockpitCustomer = timeCockpitCustomers[crmCustomer.Id];
								}

								if (timeCockpitCustomer == null)
								{
									// Add customer to time cockpit
									Console.WriteLine("\tAdd {0} - {1}", crmCustomer.Id, crmCustomer.Attributes["name"]);
									timeCockpitCustomer = customerEntity.CreateEntityObject<EntityObject>();
									timeCockpitCustomer.SetMember("CrmUuid", crmCustomer.Id);
								}
								else
								{
									// Customer already exists
									Console.WriteLine("\tUpdate {0} - {1}", crmCustomer.Id, crmCustomer.Attributes["name"]);
								}

								// Update properties of customer
								SetMember("name", "Code", crmCustomer, timeCockpitCustomer);
								SetMember("name", "CompanyName", crmCustomer, timeCockpitCustomer);
								SetMember("emailaddress1", "Email", crmCustomer, timeCockpitCustomer);
								SetMember("fax", "Fax", crmCustomer, timeCockpitCustomer);
								SetMember("address1_telephone1", "Phone", crmCustomer, timeCockpitCustomer);
								SetMember("address1_line1", "Street", crmCustomer, timeCockpitCustomer);
								SetMember("address1_city", "Town", crmCustomer, timeCockpitCustomer);
								SetMember("address1_postalcode", "ZipCode", crmCustomer, timeCockpitCustomer);
								SetRelation("address1_country", "Country", crmCustomer, timeCockpitCustomer, timeCockpitCountries);

								timeCockpitDataContext.SaveObject(timeCockpitCustomer);
							}
							catch (Exception ex)
							{
								Console.WriteLine("\tAccount {0} - {1} could not be saved: {2}", crmCustomer.Id, crmCustomer.Attributes["name"], ex.ToString());
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.ToString());
			}

			Console.ReadKey();
		}

		static void SetMember(string crmName, string timeCockpitName, Entity crmEntity, EntityObject timeCockpitEntity)
		{
			if (!string.IsNullOrEmpty(crmName) && crmEntity.Attributes.Contains(crmName))
			{
				timeCockpitEntity.SetMember(timeCockpitName, crmEntity.Attributes[crmName]);
			}
			else
			{
				timeCockpitEntity.SetMember(timeCockpitName, null);
			}
		}

		static void SetRelation(string crmName, string timeCockpitName, Entity crmEntity, EntityObject timeCockpitEntity, Dictionary<string, EntityObject> timeCockpitValues)
		{
			if (!string.IsNullOrEmpty(crmName) && crmEntity.Attributes.Contains(crmName))
			{
				if (timeCockpitValues.ContainsKey((string)crmEntity.Attributes[crmName]))
				{
					var value = timeCockpitValues[(string)crmEntity.Attributes[crmName]];
					timeCockpitEntity.SetMember(timeCockpitName, value);
					return;
				}
			}

			timeCockpitEntity.SetMember(timeCockpitName, null);
		}
	}
}
