﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Threading.Tasks.Dataflow;

namespace DataFlowDemo
{
	class Program
	{
		static void Main(string[] args)
		{
			var bb = new BufferBlock<int>();
			var ab = new ActionBlock<int>(n => Console.WriteLine(n));
			bb.LinkTo(ab);

			Producer(bb);
			bb.Complete();
			bb.Completion.Wait();

			ab.Complete();
			ab.Completion.Wait();

		}

		static void Producer(BufferBlock<int> q)
		{
			var rand = new Random();
			for (int i = 0; i < 100; i++)
			{
				Thread.Sleep(10);
				q.Post(rand.Next(100));
			}
		}
	}
}
