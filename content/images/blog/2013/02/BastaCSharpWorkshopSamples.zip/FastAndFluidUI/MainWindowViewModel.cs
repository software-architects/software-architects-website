﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Input;
using System.Data.SqlClient;
using Microsoft.Practices.Prism.Commands;
using Microsoft.Practices.Prism.ViewModel;

namespace FastAndFluidUI
{
	public class MainWindowViewModel : NotificationObject
	{
		public MainWindowViewModel()
		{
			this.Customers = new ObservableCollection<Customer>();

			this.RefreshButton = new DelegateCommand(
				DoRefreshDataAsync,
				() => !this.IsLoading);
		}

		public ObservableCollection<Customer> Customers { get; private set; }

		public DelegateCommand RefreshButton { get; private set; }

		public bool IsLoading { get; private set; }

		private async void DoRefreshDataAsync()
		{
			this.IsLoading = true;
			this.RaisePropertyChanged(() => this.IsLoading);
			this.RefreshButton.RaiseCanExecuteChanged();

			//var cts = new CancellationTokenSource();
			//cts.CancelAfter(200);
			await this.RefreshDataAsync(CancellationToken.None);

			this.IsLoading = false;
			this.RaisePropertyChanged(() => this.IsLoading);
			this.RefreshButton.RaiseCanExecuteChanged();
		}

		private async Task RefreshDataAsync(CancellationToken token)
		{
			using (var conn = new SqlConnection("Server=mydb.database.windows.net;Database=BastaWorkshop;User=BastaWorkshop;Password=P@ssW0rd!"))
			{
				await conn.OpenAsync(token);
				using (var cmd = conn.CreateCommand())
				{
					cmd.CommandText = @"
WAITFOR DELAY '0:0:5';
SELECT * FROM Customers;
";
					using (var reader = await cmd.ExecuteReaderAsync(token))
					{
						while (reader.Read())
						{
							var c = new Customer()
								{
									CustomerId = reader.GetInt32(0),
									CustomerName = reader.GetString(1),
									CustomerValue = reader.GetString(2)
								};
							this.Customers.Add(c);
						}
					}
				}
			}
		}
	}
}
