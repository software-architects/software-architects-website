﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParallelClassIntroduction
{
	class Program
	{
		static void Main(string[] args)
		{
			var rand = new Random();
			var randomNumbers = Enumerable.Range(0, 1000)
				.Select(_ => rand.Next(100))
				.ToArray();

			Parallel.For(0, randomNumbers.Length, i =>
			{
				randomNumbers[i] = randomNumbers[i] * randomNumbers[i];
			});
		}
	}
}
