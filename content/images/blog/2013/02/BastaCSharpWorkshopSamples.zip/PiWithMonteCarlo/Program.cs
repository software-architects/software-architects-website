﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace PiWithMonteCarlo
{
	public class ThreadSafeRandom
	{
		private static Random _global = new Random();

		[ThreadStatic]
		private static Random _local;

		public static double NextDouble()
		{
			var inst = _local;
			if (inst == null)
			{
				int seed;
				lock (_global) seed = _global.Next();
				_local = inst = new Random(seed);
			}

			return inst.NextDouble();
		}

	}
	class Program
	{
		static void Main(string[] args)
		{
			//ImplementationOne();
			ImplementationTwo();
		}

		private static void ImplementationTwo()
		{
			Console.WriteLine(
				(double)ParallelEnumerable.Range(0, 30000000)
					.Select(_ => new { X = ThreadSafeRandom.NextDouble(), Y = ThreadSafeRandom.NextDouble() })
					.Count(pt => Math.Sqrt(pt.X * pt.X + pt.Y * pt.Y) <= 1)
					* 4 / 30000000);
		}

		private static void ImplementationOne()
		{
			var startDateTime = DateTime.Now;

			long numberOfCalculations = 0;
			long numberOfValuesInside = 0;
			object counterLockObject = new Object();
			while (true)
			{
				Parallel.For(0, 100000, _ =>
				{
					var rand = new Random();
					long localNumberOfCalculations = 0;
					long localNumberOfValuesInside = 0;
					for (int i = 0; i < 1000; i++)
					{
						// Do monte carlo simulation
						var a = rand.NextDouble();
						var b = rand.NextDouble();
						var c = Math.Sqrt(a * a + b * b);

						if (c <= 1)
						{
							localNumberOfValuesInside++;
						}

						localNumberOfCalculations++;
					}

					lock (counterLockObject)
					{
						numberOfValuesInside += localNumberOfValuesInside;
						numberOfCalculations += localNumberOfCalculations;

						if (numberOfCalculations % 10000000 == 0)
						{
							Console.WriteLine("{0}\t{1}",
								numberOfCalculations / 1000 / (DateTime.Now - startDateTime).TotalSeconds,
								(double)numberOfValuesInside / numberOfCalculations * 4);
						}
					}
				});
			}
		}
	}
}
