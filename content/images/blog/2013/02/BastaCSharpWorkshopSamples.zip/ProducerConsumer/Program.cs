﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Concurrent;

namespace ProducerConsumer
{
	class Program
	{
		static void Main(string[] args)
		{
			var q = new BlockingCollection<int>(10);

			var tProducers = new Task[10];
			for (var i = 0; i < tProducers.Length; i++)
			{
				tProducers[i] = Task.Factory.StartNew(() => Producer(q));
			}
			var tConsumer = Task.Factory.StartNew(() => Consumer(q));

			Task.WaitAll(tProducers);
			q.CompleteAdding();

			tConsumer.Wait();
		}

		static void Producer(BlockingCollection<int> q)
		{
			var rand = new Random();
			for (int i = 0; i < 100; i++)
			{
				Thread.Sleep(10);
				q.Add(rand.Next(100));
			}
		}

		static void Consumer(BlockingCollection<int> q)
		{
			foreach (var item in q.GetConsumingEnumerable())
			{
				Console.WriteLine(item);
			}
		}
	}
}
