﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Linq.Expressions;
using IronPython.Hosting;
using IronPython.Runtime;
using Microsoft.Scripting;
using Microsoft.Scripting.Hosting; 

namespace RoslynAndExpressionTrees
{
	public class Person
	{
		public string FirstName { get; set; }
		public string LastName { get; set; }
	}

	class Program
	{
		static void Main(string[] args)
		{
			var a = 5;
			var b = 7;
			var c = 3;

			Func<int, int, int, bool> f = (x, y, z) =>
				x==5 && ( y==7 || z==3 || y==5 );

			Expression<Func<int, int, int, bool>> ex = (x, y, z) =>
				x == 5 && (y == 7 || z == 3 || y == 5);

			var p1 = Expression.Parameter(typeof(int), "x");
			var p2 = Expression.Parameter(typeof(int), "y");
			Expression<Func<int, int, int>> ex2 =
				Expression.Lambda<Func<int, int, int>>(
					Expression.Add(
						p1,
						p2),
					new[] { p1, p2 });
			Func<int, int, int> resultFunc = ex2.Compile();

			var engine = Python.CreateEngine();
			var scope = engine.CreateScope();
			var p = new Person() { FirstName = "Mad", LastName = "Max" };
			scope.SetVariable("p", p);
			var script = engine.CreateScriptSourceFromString("p.FirstName=\"Rainer\"");
			script.Execute(scope);

			Console.WriteLine(p.FirstName);
		}
	}
}
