﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TaskBasics
{
	class Program
	{
		static void Main(string[] args)
		{
			Action<Action> measure = (subTask) =>
				{
					var watch = new Stopwatch();
					watch.Start();
					subTask();
					Console.WriteLine(
						"Thread ID: {0}\t{1}",
						Thread.CurrentThread.ManagedThreadId,
						watch.Elapsed);
				};

			Action calculationTask = () =>
			{
				for (int i = 0; i < 500000000; i++) ;
			};
			Action waitTask = () =>
			{
				Thread.Sleep(1000);
			};

			ThreadPool.SetMinThreads(50, 50);

			measure(() =>
				{
					var tArray = new Task[200];
					for (var i = 0; i < tArray.Length; i++)
					{
						tArray[i] = Task.Factory.StartNew(
							()=> measure(waitTask));
					}

					Task.WaitAll(tArray);
				});
		}
	}
}
