﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace TaskContinuations
{
	class Program
	{
		static void Main(string[] args)
		{
			var are = new AutoResetEvent(false);

			var tDatabase = new Task<int>[2];
			tDatabase[0] = Task<int>.Factory.StartNew(GetValueFromDatabase);
			tDatabase[1] = Task<int>.Factory.StartNew(GetValueFromDatabase);
			Task.Factory.ContinueWhenAll(
					tDatabase,
					tDatabaseResult => Add(tDatabaseResult[0].Result, tDatabaseResult[1].Result))
				.ContinueWith(tAddResult =>
				{
					// Simulate writing the result in a log file
					Task.Factory.StartNew(() =>
						{
							Thread.Sleep(200);
							Print(tAddResult.Result);
						},
						TaskCreationOptions.AttachedToParent);
				})
				.ContinueWith(_ => are.Set());

			Console.WriteLine("Do something interesting on UI thread");

			are.WaitOne();
		}

		private static int GetValueFromDatabase()
		{
			var rand = new Random();
			return rand.Next(100);
		}

		private static int Add(int x, int y)
		{
			return x + y;
		}

		private static void Print(int x)
		{
			Console.WriteLine(x);
		}
	}
}
