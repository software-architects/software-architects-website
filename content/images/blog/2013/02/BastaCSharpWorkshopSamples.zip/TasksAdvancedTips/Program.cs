﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Diagnostics;

namespace TasksAdvancedTips
{
	class Program
	{
		static void Main(string[] args)
		{
			ExecuteProcessAsync("cmd", "/C echo done").Wait();
		}

		static Task ExecuteProcessAsync(string commandLine, string arguments)
		{
			var taskCompletionSource = new TaskCompletionSource<object>();
			var p = Process.Start(commandLine, arguments);
			p.EnableRaisingEvents = true;
			p.Exited += (_, __) =>
				{
					// Process is done!
					taskCompletionSource.SetResult(null);
				};
			p.Start();
			return taskCompletionSource.Task;
		}

		/// <summary>
		/// Ineffizient!
		/// </summary>
		static Task<int> DivideInefficientAsync(int x, int y)
		{
			return Task.Factory.StartNew(() =>
				{
					if (y == 0)
					{
						return 0;
					}
					else
					{
						Thread.Sleep(1000);
						return x / y;
					}
				});
		}

		static Task<int> NullTask = Task.FromResult(0);
		static Task<int> DivideAsync(int x, int y)
		{
			if (y == 0)
			{
				return NullTask;
			}
			return Task.Factory.StartNew(() =>
			{
				Thread.Sleep(1000);
				return x / y;
			});
		}
	}
}
