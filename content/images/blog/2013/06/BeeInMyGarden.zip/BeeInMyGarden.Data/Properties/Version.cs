﻿//------------------------------------------------------------------------------------------------------------
// <copyright file="Version.cs" company="software architects og">
//     Copyright (c) software architects og. All rights reserved.
// </copyright>
//------------------------------------------------------------------------------------------------------------

using System.Reflection;
[assembly: AssemblyVersion("0.0.0.0")]
[assembly: AssemblyFileVersion("0.0.0.0")]
[assembly: AssemblyConfiguration("DesktopBuild")]
[assembly: AssemblyCopyright("Copyright © software architects gmbh 2013. All rights reserved.")]
[assembly: AssemblyCompany("software architects gmbh")]