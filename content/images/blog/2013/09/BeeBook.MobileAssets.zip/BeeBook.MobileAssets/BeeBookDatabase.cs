using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Threading.Tasks;

namespace BeeBook.Mobile
{
	public abstract class BeeBookDatabase : IDisposable
	{
		private bool disposed = false;

		~BeeBookDatabase()
		{
			this.Dispose(false);
			GC.SuppressFinalize(this);
		}

		protected DbConnection Connection { get; set; }

		private static BeeBookDatabase current;
		public static BeeBookDatabase Current 
		{
			get
			{
				if (current == null)
				{
					// Lazy create and open global database
					BeeBookDatabase.current = GlobalContainer.Container.GetExportedValue<BeeBookDatabase>();
					BeeBookDatabase.current.CreateOrOpenDatabaseAsync();
				}

				return BeeBookDatabase.current;
			}
		}

		#region Abstract method used to stay independent of RDBMS
		public abstract string DatabaseFileLocation { get; }
		public abstract Task CreateOrOpenDatabaseAsync();
		protected abstract string GenerateSqlHiveTableCreate();
		protected abstract IReadOnlyList<string> GenerateSqlDemoDataInserts();
		protected abstract string GenerateSqlNumberOfHives();
		protected abstract string GenerateSqlGetAllHives();
		protected abstract string GenerateSqlGetHiveById(int hiveId);
		#endregion 

		public async Task CreateOrUpdateSchema()
		{
			this.CheckDisposed();

			using (var command = this.Connection.CreateCommand())
			{
				command.CommandText = this.GenerateSqlHiveTableCreate();
				command.CommandType = CommandType.Text;
				await command.ExecuteNonQueryAsync();
			}
		}

		public async Task GenerateDemodata()
		{
			this.CheckDisposed();

			using (var command = this.Connection.CreateCommand())
			{
				command.CommandType = CommandType.Text;
				command.CommandText = this.GenerateSqlNumberOfHives();
				var numberOfHives = (long)await command.ExecuteScalarAsync();
				if (numberOfHives == 0)
				{
					foreach (var stmt in this.GenerateSqlDemoDataInserts())
					{
						command.CommandText = stmt;
						await command.ExecuteNonQueryAsync();
					}
				}
			}
		}

		public async Task<IReadOnlyList<Hive>> GetAllHives()
		{
			this.CheckDisposed();

			var result = new List<Hive>();
			using (var command = this.Connection.CreateCommand())
			{
				command.CommandType = CommandType.Text;
				command.CommandText = this.GenerateSqlGetAllHives();
				using (var reader = await command.ExecuteReaderAsync())
				{
					var idOrdinal = reader.GetOrdinal("Id");
					var hiveNameOrdinal = reader.GetOrdinal("hiveName");
					var latOrdinal  = reader.GetOrdinal("lat");
					var longOrdinal = reader.GetOrdinal("long");
					while (await reader.ReadAsync())
					{
						result.Add(new Hive()
						{
							Id = (int)reader.GetInt64(idOrdinal),
							HiveName = reader.GetString(hiveNameOrdinal),
							Lat = reader.GetDouble(latOrdinal),
							Long = reader.GetDouble(longOrdinal)
						});
					}
				}
			}

			return result;
		}
		
		public async Task<Hive> GetHiveById(int hiveId)
		{
			this.CheckDisposed();

			Hive result = null;
			using (var command = this.Connection.CreateCommand())
			{
				command.CommandType = CommandType.Text;
				command.CommandText = this.GenerateSqlGetHiveById(hiveId);
				using (var reader = await command.ExecuteReaderAsync())
				{
					if (await reader.ReadAsync())
					{
						var idOrdinal = reader.GetOrdinal("Id");
						var hiveNameOrdinal = reader.GetOrdinal("hiveName");
						var latOrdinal = reader.GetOrdinal("lat");
						var longOrdinal = reader.GetOrdinal("long");
						result = new Hive()
						{
							Id = reader.GetInt32(idOrdinal),
							HiveName = reader.GetString(hiveNameOrdinal),
							Lat = reader.GetDouble(latOrdinal),
							Long = reader.GetDouble(longOrdinal)
						};
					}
				}
			}

			return result;
		}

		public void CloseDatabase()
		{
			this.CheckDisposed();

			if (this.Connection != null)
			{
				this.Connection.Close();
				this.Connection.Dispose();
				this.Connection = null;
			}
		}
		public void Dispose()
		{
			this.Dispose(true);
		}
		public void Dispose(bool disposing)
		{
			if (disposing)
			{
				this.CloseDatabase();
			}

			this.disposed = true;
		}
		protected void CheckDisposed()
		{
			if (this.disposed)
			{
				throw new ObjectDisposedException(this.ToString());
			}
		}
	}
}

