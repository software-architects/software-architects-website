using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Mono.Data.Sqlite;
using System.ComponentModel.Composition;
using System.Collections.Generic;

namespace BeeBook.Mobile
{
	[Export(typeof(BeeBookDatabase))]
	[PartCreationPolicy(CreationPolicy.Shared)]
	public class BeeBookDatabaseMobile : BeeBookDatabase
	{
		public override string DatabaseFileLocation
		{
			get
			{
				this.CheckDisposed();
				return Path.Combine(
					System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal),
					"hives.db3");
			}
		}

		public override async Task CreateOrOpenDatabaseAsync()
		{
			this.CheckDisposed();

			// If database is already open, close it
			if (this.Connection != null)
			{
				this.CloseDatabase();
			}

			// Create database file if it does not exist
			var dbFileName = this.DatabaseFileLocation;
			if (!File.Exists(dbFileName))
			{
				SqliteConnection.CreateFile(dbFileName);
			}

			// Create connection and open it async
			this.Connection = new SqliteConnection(string.Format("Data Source={0}", this.DatabaseFileLocation));
			await this.Connection.OpenAsync();
		}

		protected override string GenerateSqlHiveTableCreate()
		{
			return "CREATE TABLE IF NOT EXISTS Hive ( Id INTEGER CONSTRAINT PK_Hive PRIMARY KEY ASC AUTOINCREMENT, hiveName TEXT, lat REAL, long REAL );";
		}

		protected override IReadOnlyList<string> GenerateSqlDemoDataInserts()
		{
			return new[] {
				"INSERT INTO Hive ( hiveName, lat, long ) values ( 'N�he Rapsfeld', 48.279381, 14.239203 )",
				"INSERT INTO Hive ( hiveName, lat, long ) values ( 'K�rnbergerwald', 48.285819, 14.2355 )"
			};
		}

		protected override string GenerateSqlNumberOfHives()
		{
			return "SELECT COUNT(*) FROM Hive;";
		}
		protected override string GenerateSqlGetAllHives()
		{
			return "SELECT * FROM Hive;";
		}
		protected override string GenerateSqlGetHiveById(int hiveId)
		{
			return string.Format("SELECT * FROM Hive WHERE Id = {0};", hiveId);
		}

	}
}

