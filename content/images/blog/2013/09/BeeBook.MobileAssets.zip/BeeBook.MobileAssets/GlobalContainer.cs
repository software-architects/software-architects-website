using System.ComponentModel.Composition.Hosting;
using System.Reflection;

namespace BeeBook.Mobile
{
	/// <summary>
	/// Application-level composition container
	/// </summary>
	/// <remarks>
	/// In this sample we use MEF for injecting the database implementation. This should
	/// demonstrate that you can use the .NET BCL features you are used to even on
	/// Android/iOS.
	/// </remarks>
	public static class GlobalContainer
	{
		private static CompositionContainer container;

		public static CompositionContainer Container
		{
			get
			{
				if (GlobalContainer.container == null)
				{
					var catalog = new AssemblyCatalog(Assembly.GetExecutingAssembly());
					GlobalContainer.container = new CompositionContainer(catalog);
				}

				return GlobalContainer.container;
			}
		}
	}
}