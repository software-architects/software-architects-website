using System.Runtime.Serialization;

namespace BeeBook.Mobile
{
	public class Hive
	{
		public int Id { get; set; }

		// Note that DataMember attributes are necessary 
		// for Azure Mobile Services
		[DataMember(Name = "hiveName")]
		public string HiveName { get; set; }
	
		[DataMember(Name = "lat")]
		public double Lat { get; set; }

		[DataMember(Name = "long")]
		public double Long { get; set; }
	}
}