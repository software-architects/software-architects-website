using Android.Content;
using Android.Views;
using Android.Widget;
using System.Collections.Generic;

namespace BeeBook.Mobile
{
	public class HiveAdapter : BaseAdapter<Hive>
	{
		private IReadOnlyList<Hive> items = new List<Hive>();
		private readonly LayoutInflater inflater;

		public HiveAdapter(Context context)
		{
			this.inflater = (LayoutInflater)context.GetSystemService(Context.LayoutInflaterService);
			this.RefreshAsync();
		}

		public override bool HasStableIds { get { return true; } }
		public override int Count { get { return this.items.Count; } }
		public override Hive this[int position] { get { return this.items[position]; } }
		public override long GetItemId(int position) { return this.items[position].Id; }

		public override View GetView(int position, View convertView, ViewGroup parent)
		{
			var item = this.items[position];

			var view = this.inflater.Inflate(Resource.Layout.HiveItem, null);
			var itemTextView = view.FindViewById<TextView>(Resource.Id.ItemText);
			itemTextView.Text = item.HiveName;

			itemTextView.Click += (o, e) =>
			{
				var hiveDetailsActivity = new Intent(this.inflater.Context, typeof(HiveDetails));
				hiveDetailsActivity.PutExtra("Id", item.Id);
				this.inflater.Context.StartActivity(hiveDetailsActivity);
			};

			return view;
		}

		public async void RefreshAsync()
		{
			this.items = await BeeBookDatabase.Current.GetAllHives();
			this.NotifyDataSetChanged();
		}
	}
}