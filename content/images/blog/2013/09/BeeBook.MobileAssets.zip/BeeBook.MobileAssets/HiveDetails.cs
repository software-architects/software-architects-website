using Android.App;
using Android.Content;
using Android.OS;
using Android.Widget;

namespace BeeBook.Mobile
{
	[Activity(Label = "Hive Details")]
	public class HiveDetails : Activity
	{
		protected override async void OnCreate(Bundle bundle)
		{
			base.OnCreate(bundle);
			this.SetContentView(Resource.Layout.HiveDetails);

			var hiveId = this.Intent.GetIntExtra("Id", -1);
			if (hiveId != (-1))
			{
				var hive = await BeeBookDatabase.Current.GetHiveById(hiveId);
				if (hive != null)
				{
					this.FindViewById<EditText>(Resource.Id.HiveNameText).Text = hive.HiveName;
					this.FindViewById<EditText>(Resource.Id.LongitudeText).Text = hive.Long.ToString();
					this.FindViewById<EditText>(Resource.Id.LatitudeText).Text = hive.Lat.ToString();
	
					this.FindViewById<Button>(Resource.Id.DisplayLocation).Click += (s, e) =>
						{
							var uriString = string.Format("https://maps.google.com/maps?q=loc:{0}+{1}", hive.Lat, hive.Long);
							var uri = Android.Net.Uri.Parse(uriString);
							var intent = new Intent(Intent.ActionView, uri);
							this.StartActivity(intent);
						};
				}
			}
		}
	}
}