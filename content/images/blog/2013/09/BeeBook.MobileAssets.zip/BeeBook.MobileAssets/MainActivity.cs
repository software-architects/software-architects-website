using Android.App;
using Android.OS;
using Android.Views;

namespace BeeBook.Mobile
{
	[Activity(Label = "BeeBook.Mobile", MainLauncher = true)]
	public class MainActivity : ListActivity
	{
		//private static readonly MobileServiceClient MobileService =
		//	new MobileServiceClient("https://yourmobileservice.azure-mobile.net/", "YourMobileServiceKey");

		protected override async void OnCreate(Bundle bundle)
		{
			base.OnCreate(bundle);

			// Activate the action bar
			this.RequestWindowFeature(WindowFeatures.ActionBar);

			var db = BeeBookDatabase.Current;
			await db.CreateOrUpdateSchema();
			await db.GenerateDemodata();

			this.ListAdapter = new HiveAdapter(this);
		}

		//public override bool OnCreateOptionsMenu(Android.Views.IMenu menu)
		//{
		//	var inflater = this.MenuInflater;
		//	inflater.Inflate(Resource.Menu.MainMenu, menu);
		//	return true;
		//}

		//public override bool OnOptionsItemSelected(IMenuItem item)
		//{
		//	if (item.ItemId == Resource.Id.menu_sync)
		//	{
		//		Task.Run(async () =>
		//			{
		//				var hivesInLocalDb = await BeeBookDatabase.Current.GetAllHives();

		//				var table = MainActivity.MobileService.GetTable<Hive>();
		//				var hivesInRemoteDb = await table.ToListAsync();

		//				foreach (var missingHive in hivesInLocalDb.Where(h => hivesInRemoteDb.Count(hRemote => hRemote.HiveName == h.HiveName) == 0).ToArray())
		//				{
		//					missingHive.Id = 0;
		//					await table.InsertAsync(missingHive);
		//				}
		//			});

		//		return true;
		//	}
		//	else
		//	{
		//		return base.OnOptionsItemSelected(item);
		//	}
		//}
	}
}


