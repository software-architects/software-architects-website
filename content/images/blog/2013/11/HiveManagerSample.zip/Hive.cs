﻿using Newtonsoft.Json;
using System;

namespace HiveManager
{
	public class Hive
	{
		public int Id { get; set; }

		[JsonProperty(PropertyName = "name")]
		public string Name { get; set; }

		[JsonProperty(PropertyName = "imageUri")]
		public string ImageUri { get; set; }

		[JsonProperty(PropertyName = "lat")]
		public double Lat { get; set; }

		[JsonProperty(PropertyName = "long")]
		public double Long { get; set; }

		[JsonProperty(PropertyName = "constructionDate")]
		public DateTimeOffset ConstructionDate { get; set; }

		public enum HiveForms { Bienenkiste, Dadant }

		[JsonProperty(PropertyName = "hiveForm")]
		public HiveForms HiveForm { get; set; }
	}
}
