﻿using System.Collections.Generic;
using System.Net.Http;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace HiveManager
{
	public sealed partial class MainPage : Page
	{
		private MainPageViewModel ViewModel;

		public MainPage()
		{
			this.InitializeComponent();
			this.DataContext = this.ViewModel = new MainPageViewModel();
		}

		public async void SuggestionsRequested(object pane, SearchBoxSuggestionsRequestedEventArgs ea)
		{
			// Use deferral object to indicate that the request is NOT completed when the
			// event handler exits. It will continue until the async request completes.
			var deferral = ea.Request.GetDeferral();
			try
			{
				ea.Request.SearchSuggestionCollection.AppendQuerySuggestions(await this.ViewModel.QueryHiveNames(ea.QueryText));
			}
			finally
			{
				deferral.Complete();
			}
		}
	}
}
