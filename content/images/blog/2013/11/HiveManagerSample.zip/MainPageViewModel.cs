﻿using Bing.Maps;
using Microsoft.WindowsAzure.MobileServices;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Input;
using Windows.Media.Capture;
using Windows.Networking.BackgroundTransfer;
using Windows.UI.Xaml;

namespace HiveManager
{
	public class MainPageViewModel : INotifyPropertyChanged
	{
		public MainPageViewModel()
		{
			this.HiveForms = Enum.GetValues(typeof(Hive.HiveForms)).OfType<Hive.HiveForms>().ToArray();
			this.HiveMap = new Lazy<Map>(() => new Map() { Credentials = "yourBingCredentials" });

			this.GenerateDemoDataCommand = new DelegateCommand(this.GenerateDemoData, () => true);
			this.TakePictureAndUploadCommand = new DelegateCommand(this.TakePictureAndUpload, () => true);
		}

		#region Search functionality
		private string QueryTextValue;
		public string QueryText
		{
			get
			{
				return this.QueryTextValue;
			}

			set
			{
				if (this.QueryTextValue != value)
				{
					this.QueryTextValue = value;
					this.RaisePropertyChanged();
				}
			}
		}

		public async Task<IEnumerable<string>> QueryHiveNames(string queryString)
		{
			if (!string.IsNullOrEmpty(queryString))
			{
				// Query string is not empty --> Lookup hives async using web request
				return await App.MobileService.GetTable<Hive>()
					.Where(h => h.Name.StartsWith(queryString))
					.Select(h => h.Name)
					.ToCollectionAsync();
			}

			// Query string is empty --> return empty result
			return Enumerable.Empty<string>();
		}
		#endregion

		#region Authentication functionality
		private MobileServiceUser user = null;

		public bool IsAuthenticated
		{
			get
			{
				return this.user != null;
			}
		}

		public async void Authenticate()
		{
			while (user == null)
			{
				try
				{
					this.user = await App.MobileService.LoginAsync(MobileServiceAuthenticationProvider.MicrosoftAccount);
					this.RaisePropertyChanged("IsAuthenticated");
					this.RefreshHives();
				}
				catch (InvalidOperationException)
				{
					this.user = null;
				}
			}
		}
		#endregion

		#region Manage list of hives
		private IEnumerable<Hive> HivesValue;
		public IEnumerable<Hive> Hives
		{
			get
			{
				return this.HivesValue;
			}

			set
			{
				if (this.HivesValue != value)
				{
					this.HivesValue = value;
					this.RaisePropertyChanged();
				}
			}
		}

		public async void RefreshHives()
		{
			// Use mobile service api to query hives
			var table = App.MobileService.GetTable<Hive>();
			if (!string.IsNullOrEmpty(this.QueryText))
			{
				// Respect current query text
				this.Hives = await table.Where(h => h.Name == this.QueryText).ToCollectionAsync(); ;
			}
			else
			{
				this.Hives = await table.ToCollectionAsync();
			}
		}
		#endregion

		#region Manage currently selected hive
		private Hive SelectedHiveValue;
		public Hive SelectedHive
		{
			get
			{
				return this.SelectedHiveValue;
			}

			set
			{
				if (this.SelectedHiveValue != value)
				{
					this.SelectedHiveValue = value;
					this.RaisePropertyChanged();
					this.RaisePropertyChanged("HiveDetailsVisible");
					UpdateHiveMap();
				}
			}
		}

		public Visibility HiveDetailsVisible
		{
			get
			{
				return this.SelectedHive != null ? Visibility.Visible : Visibility.Collapsed;
			}
		}

		public IEnumerable<Hive.HiveForms> HiveForms { get; set; }
		#endregion

		#region Map functionality
		private void UpdateHiveMap()
		{
			var map = this.HiveMap.Value;
			map.ZoomLevel = 15;

			var pushpin = new Pushpin();
			pushpin.Text = this.SelectedHive.Name;
			Location location;
			MapLayer.SetPosition(pushpin, location = new Location(this.SelectedHive.Lat, this.SelectedHive.Long));
			map.Children.Clear();
			map.Children.Add(pushpin);

			map.Center = location;
		}

		public Lazy<Map> HiveMap { get; private set; }
		#endregion

		#region Generating demo data
		public ICommand GenerateDemoDataCommand { get; private set; } 

		private async void GenerateDemoData()
		{
			var table = App.MobileService.GetTable<Hive>();

			// Delete existing data
			var hives = await table.ToCollectionAsync();
			var deleteTasks = new Task[hives.Count];
			for (var i = 0; i < hives.Count; i++)
			{
				deleteTasks[i] = table.DeleteAsync(hives[i]);
			}

			await Task.WhenAll(deleteTasks);

			// Insert demo data
			await table.InsertAsync(new Hive()
				{
					Name = "Near Wood",
					ImageUri = "http://farm6.staticflickr.com/5498/9473472186_9e09f13934.jpg",
					Lat = 48.282325,
					Long = 14.255194,
					HiveForm = Hive.HiveForms.Dadant,
					ConstructionDate = DateTimeOffset.Now
				});
			await table.InsertAsync(new Hive()
			{
				Name = "In Garden",
				ImageUri = "http://farm8.staticflickr.com/7334/8920349019_2b4c95f6f9.jpg",
				Lat = 48.292325,
				Long = 14.275194,
				HiveForm = Hive.HiveForms.Dadant,
				ConstructionDate = DateTimeOffset.Now
			});
			await table.InsertAsync(new Hive()
			{
				Name = "On Farm",
				ImageUri = "http://farm6.staticflickr.com/5328/9589436557_81eb38a57d.jpg",
				Lat = 48.382325,
				Long = 14.355194,
				HiveForm = Hive.HiveForms.Bienenkiste,
				ConstructionDate = DateTimeOffset.Now
			});

			this.RefreshHives();
		}
		#endregion

		#region Picture and blob
		public ICommand TakePictureAndUploadCommand { get; private set; }
		public async void TakePictureAndUpload()
		{
			var camera = new CameraCaptureUI();
			camera.PhotoSettings.Format = CameraCaptureUIPhotoFormat.Jpeg;
			var media = await camera.CaptureFileAsync(CameraCaptureUIMode.Photo);
			var imageName = "image_" + Guid.NewGuid().ToString().Replace("-", "") + ".jpg";

			var parameters = new Dictionary<string, string>();
			parameters.Add("imageName", imageName);
			var resultJson = await App.MobileService.InvokeApiAsync("getsasforimage", HttpMethod.Get, parameters);
			var result = JsonConvert.DeserializeObject<SharedAccessSignatureInformation>(resultJson.ToString());

			if (!string.IsNullOrEmpty(result.SasQueryString.ToString()))
			{
				// Get the new image as a stream.
				using (var fileStream = await media.OpenReadAsync())
				{
					var uploader = new BackgroundUploader();
					uploader.Method = "PUT";
					var targetUri = new Uri(result.ImageUri + "?" + result.SasQueryString, UriKind.Absolute);
					var upload = await uploader.CreateUploadFromStreamAsync(targetUri, fileStream);
					var operation = await upload.StartAsync();
				}
			}

			// Todo: Change ImageUri of hive to new image in the cloud
		}
		#endregion

		#region INotifyPropertyChanged handling
		private void RaisePropertyChanged([CallerMemberName]string propertyName = null)
		{
			if (this.PropertyChanged != null)
			{
				this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		public event PropertyChangedEventHandler PropertyChanged;
		#endregion
	}
}
