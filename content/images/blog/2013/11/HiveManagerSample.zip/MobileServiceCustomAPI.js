var azure = require('azure');
var qs = require('querystring');

exports.get = function(request, response) {
    var accountName = '...yourAccountName...';
    var accountKey = '...yourAccountKey...';
    var containerName = 'images';
    var host = accountName + '.blob.core.windows.net';
    var imageName = request.query.imageName;

    var blobService = azure.createBlobService(accountName, accountKey, host);
    var sharedAccessPolicy = {
        AccessPolicy: {
            Permissions: azure.Constants.BlobConstants.SharedAccessPermissions.WRITE,
            Expiry: new Date(new Date().getTime() + 5 * 60 * 1000)
        }};

    // Generate the upload URL with SAS for the new image.
    var sasQueryUrl = 
        blobService.generateSharedAccessSignature(containerName, 
            imageName, sharedAccessPolicy);

    // Set the query string.
    var sasQueryString = qs.stringify(sasQueryUrl.queryString);

    // Set the full path on the new new item, 
    // which is used for data binding on the client. 
    var imageUri = sasQueryUrl.baseUrl + sasQueryUrl.path;
    
    response.send(statusCodes.OK, { 'sasQueryString': sasQueryString, 'imageUri': imageUri });
};