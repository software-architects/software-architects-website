﻿using Newtonsoft.Json;

namespace HiveManager
{
	public class SharedAccessSignatureInformation
	{
		[JsonProperty("sasQueryString")]
		public string SasQueryString { get; set; }

		[JsonProperty("imageUri")]
		public string ImageUri { get; set; }
	}
}
