﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace WebApiSample.Controllers
{
    [RoutePrefix("api/sample")]
    public class SampleController : ApiController
    {
        [Route("{id:int}")]
        public async Task<IHttpActionResult> GetTestClass(int id)
        {
            return Ok(new TestClass { Property1 = "Hello", Property2 = string.Format("Integer: {0}", id) });
        }

        [Route("{id:alpha}")]
        public async Task<IHttpActionResult> GetTestClass(string id)
        {
            return Ok(new TestClass { Property1 = "Hello", Property2 = string.Format("String: {0}", id) });
        }

        public async Task<IHttpActionResult> PostTestClass(TestClass testClass)
        {
            if (!ModelState.IsValid)
                return BadRequest();

            return Ok();
        }
    }
}
