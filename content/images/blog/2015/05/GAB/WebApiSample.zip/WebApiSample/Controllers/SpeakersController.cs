﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using System.Web.Http.OData;
using System.Web.Http.OData.Extensions;
using System.Web.Http.OData.Query;
using WebApiSample.Models;

namespace WebApiSample.Controllers
{
    public class SpeakersController : ApiController
    {
        private EventContext db = new EventContext();

        // GET: api/Speakers
        //[EnableQuery]
        public PageResult<Speaker> GetSpeakers(ODataQueryOptions<Speaker> options)
        {
            var settings = new ODataQuerySettings {
                PageSize = 2
            };

            var result = options.ApplyTo(db.Speakers, settings);

            var speakers = ((IEnumerable<Speaker>)result).ToList();

            var paged = new PageResult<Speaker>(
                    speakers,
                    Request.ODataProperties().NextLink,
                    Request.ODataProperties().TotalCount
                );

            return paged;
        }

        // GET: api/Speakers/5
        [ResponseType(typeof(Speaker))]
        public async Task<IHttpActionResult> GetSpeaker(int id)
        {
            Speaker speaker = await db.Speakers.Include(p => p.Sessions).FirstOrDefaultAsync(p => p.SpeakerId == id);
            if (speaker == null) {
                return NotFound();
            }

            return Ok(speaker);
        }

        // GET: api/Sessions/5/Speaker
        [Route("api/sessions/{id}/Speaker")]
        [ResponseType(typeof(Speaker))]
        public async Task<IHttpActionResult> GetSpeakerBySession(int id)
        {
            Speaker speaker = await db.Sessions.Where(p => p.SessionId == id).Select(p => p.Speaker).FirstOrDefaultAsync();
            if (speaker == null) {
                return NotFound();
            }

            return Ok(speaker);
        }

        // PUT: api/Speakers/5
        [ResponseType(typeof(void))]
        public async Task<IHttpActionResult> PutSpeaker(int id, Speaker speaker)
        {
            if (!ModelState.IsValid) {
                return BadRequest(ModelState);
            }

            if (id != speaker.SpeakerId) {
                return BadRequest();
            }

            db.Entry(speaker).State = EntityState.Modified;

            try {
                await db.SaveChangesAsync();
            } catch (DbUpdateConcurrencyException) {
                if (!SpeakerExists(id)) {
                    return NotFound();
                } else {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Speakers
        [ResponseType(typeof(Speaker))]
        public async Task<IHttpActionResult> PostSpeaker(Speaker speaker)
        {
            if (!ModelState.IsValid) {
                return BadRequest(ModelState);
            }

            db.Speakers.Add(speaker);
            await db.SaveChangesAsync();

            return CreatedAtRoute("DefaultApi", new { id = speaker.SpeakerId }, speaker);
        }

        // DELETE: api/Speakers/5
        [ResponseType(typeof(Speaker))]
        public async Task<IHttpActionResult> DeleteSpeaker(int id)
        {
            Speaker speaker = await db.Speakers.FindAsync(id);
            if (speaker == null) {
                return NotFound();
            }

            db.Speakers.Remove(speaker);
            await db.SaveChangesAsync();

            return Ok(speaker);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool SpeakerExists(int id)
        {
            return db.Speakers.Count(e => e.SpeakerId == id) > 0;
        }
    }
}