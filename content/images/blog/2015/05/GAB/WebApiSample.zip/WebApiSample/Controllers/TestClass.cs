﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WebApiSample.Controllers
{
    public class TestClass
    {
        public string Property2 { get; set; }

        public string Property1 { get; set; }
    }
}
