namespace WebApiSample.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;
    using WebApiSample.Models;

    internal sealed class Configuration : DbMigrationsConfiguration<WebApiSample.Models.EventContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(WebApiSample.Models.EventContext context)
        {
            //  This method will be called after migrating to the latest version.


            var schacherl = new Speaker { FirstName = "Roman", LastName = "Schacherl" };
            var stropek = new Speaker { FirstName = "Rainer", LastName = "Stropek" };
            var schwarz = new Speaker { FirstName = "Raphael", LastName = "Schwarz" };
            var lintner = new Speaker { FirstName = "Oliver", LastName = "Lintner" };

            context.Speakers.AddOrUpdate(p => new { p.FirstName, p.LastName },
                    schacherl,
                    stropek,
                    schwarz,
                    lintner
                );

            context.Sessions.AddOrUpdate(p => p.Title,
                    new Session { Speaker = stropek, Title = "Web Development with Azure Websites" },
                    new Session { Speaker = schacherl, Title = "Think big, start small: Software-Architekturen f�r die Cloud" },
                    new Session { Speaker = lintner, Title = "Azure - State of the Union" },
                    new Session { Speaker = schwarz, Title = "Erfahrungsbericht aus vier Jahren Betrieb eines IT-Unternahmens ohne Server" },
                    new Session { Speaker = schwarz, Title = "Datenbasierte Services mit ASP.NET Web API und Entity Framework" }
                );
        }
    }
}
