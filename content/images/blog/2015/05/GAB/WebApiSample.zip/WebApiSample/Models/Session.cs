﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace WebApiSample.Models
{
    [DataContract(IsReference = true)]
    public class Session
    {
        [DataMember]
        public int SessionId { get; set; }

        [DataMember]
        [StringLength(500)]
        public string Title { get; set; }

        [DataMember]
        public int SpeakerId { get; set; }

        [DataMember]
        public Speaker Speaker { get; set; }
    }
}