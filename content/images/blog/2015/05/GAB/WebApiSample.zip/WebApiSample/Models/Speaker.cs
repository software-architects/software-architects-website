﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace WebApiSample.Models
{
    [DataContract(IsReference = true)]
    public class Speaker
    {
        [DataMember]
        public int SpeakerId { get; set; }

        [DataMember]
        [StringLength(50)]
        public string FirstName { get; set; }

        [DataMember]
        [StringLength(50)]
        public string LastName { get; set; }

        [DataMember]
        public ICollection<Session> Sessions { get; set; }
    }
}
