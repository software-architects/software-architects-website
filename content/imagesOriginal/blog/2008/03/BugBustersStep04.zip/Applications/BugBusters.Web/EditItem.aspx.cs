﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class EditItem : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		InsertForm.ItemInserting += new DetailsViewInsertEventHandler(InsertForm_ItemInserting);
		InsertForm.ItemInserted += new DetailsViewInsertedEventHandler(InsertForm_ItemInserted);

		if (!IsPostBack)
		{
			InsertForm.ChangeMode(DetailsViewMode.Insert);
		}
	}

	private void InsertForm_ItemInserting(object sender, DetailsViewInsertEventArgs e)
	{
		e.Values["ProjectID"] = ((DropDownList)InsertForm.Rows[0].FindControl("lstProjects")).SelectedValue;
		e.Values["TaskTypeID"] = ((DropDownList)InsertForm.Rows[0].FindControl("lstTaskTypes")).SelectedValue;
		e.Values["UserID"] = ((DropDownList)InsertForm.Rows[0].FindControl("lstUsers")).SelectedValue;
		e.Values["StartTime"] = DateTime.Parse(((TextBox)InsertForm.Rows[0].FindControl("txtStartTime")).Text);
		e.Values["EndTime"] = DateTime.Parse(((TextBox)InsertForm.Rows[0].FindControl("txtEndTime")).Text);
		e.Values["Comment"] = ((TextBox)InsertForm.Rows[0].FindControl("txtComment")).Text;
	}

	private void InsertForm_ItemInserted(object sender, DetailsViewInsertedEventArgs e)
	{
		InsertForm.ChangeMode(DetailsViewMode.Insert);
		this.RegisterStartupScript("closeWindow", 
			@"<script language=""javascript"">opener.__doPostBack(""DataBind"", """"); self.close();</script>");
	}

}
