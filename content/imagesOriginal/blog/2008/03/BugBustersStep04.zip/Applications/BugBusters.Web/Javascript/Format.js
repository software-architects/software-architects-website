function CompareDates(year1, month1, day1, year2, month2, day2)
{
	var returnValue = 0;
	
	if (year1 == year2)
	{
		if (month1 == month2)
		{
			if (day1 < day2)
			{
				returnValue = 1;
			}
			else if (day1 > day2)
			{
				returnValue = -1;
			}
		}
		else
		{
			if (month1 < month2)
			{
				returnValue = 1;
			}
			else
			{
				returnValue = -1;
			}
		}
	}
	else
	{
		if (year1 < year2)
		{
			returnValue = 1;
		}
		else
		{
			returnValue = -1;
		}
	}
	
	return returnValue;
}

function CheckNumber(control, decNum, format, separator)
{
	if (separator == null)
	{
		separator = 1;
	}
	control.value = ReformatNum(control.value, decNum, format, separator);
}

function CheckNumberAndRound(control, decNum, format, separator)
{
	if (separator == null)
	{
		separator = 1;
	}

	var num = GetNumber(control.value, format);
	var multiplikator = Math.pow(10, decNum);
	num = num * multiplikator;
	num = Math.round(num);
	num = num / multiplikator;
	num = SetNumber(num, format);
	
	control.value = ReformatNum(num, decNum, format, separator);
}

function CheckDateBaseDatePicker(value, format)
{
	return ReformatDate(value, format);
}

function CheckDateWithBaseDateBaseDatePicker(value, baseControl, format)
{
	return ReformatDateExt(value, format, baseControl.id);
}

function CheckDate(control, format)
{
	control.value = ReformatDate(control.value, format);
}

function CheckDateWithBaseDate(control, baseControl, format)
{
	control.value = ReformatDateExt(control.value, format, baseControl.id);
}

function CheckDateTime(control, format)
{
	var date;
	var time;
	var dateTime = "";
	if (control.value.indexOf(" ") != -1)
	{
		date = control.value.substr(0, control.value.indexOf(" "));
		time = control.value.substring(control.value.indexOf(" ") + 1, control.value.length);
		
		date = ReformatDate(date, format);
		time = ReformatTime(time, format);
		if (date != "" && time != "")
		{
			dateTime = date + " " + time;
		}
	}
	else
	{
		var date = new Date();
		date = date.getDate() + '.' + (date.getMonth() + 1) + '.' + date.getFullYear() ;
		time = control.value;
		date = ReformatDate(date, format);
		time = ReformatTime(time, format);
		if (date != "" && time != "")
		{
			dateTime = date + " " + time;
		}
	}
	control.value = dateTime;
}

function CheckTime(control, format)
{
	control.value = ReformatTime(control.value, format);
}

function GetDate(date1)
{
	var month1 = 0;
	var year1 = 0;
	var day1 = 0;
	
	if (date1.substr(2, 1) == ".")
	{
		day1 = date1.substr(0, 2);
		month1 = date1.substr(3, 2);
		year1 = date1.substr(6, 4);
	}
	else
	{
		day1 = date1.substr(3, 2);
		month1 = date1.substr(0, 2);
		year1 = date1.substr(6, 4);
	}
	
	return year1 + "-" + month1 + "-" + day1;
}

function GetNumber(number1, format)
{
	if (format == 1)
	{
		number1 = number1.toString().replace(/\./g,"");
		number1 = number1.toString().replace(/,/,".");
	}
	else 
	{	
		number1 = number1.toString().replace(/,/,"");
	}
	return Number(number1);
}

function SetNumber(number1, format)
{
	if (format == 1)
	{
		number1 = number1.toString().replace(/\./g,",");
	}
	return number1;
}

function CompareDate(date1, date2)
{
	var month1 = 0;
	var year1 = 0;
	var day1 = 0;
	var month2 = 0;
	var year2 = 0;
	var day2 = 0;
	
	if (date1.substr(2, 1) == ".")
	{
		day1 = date1.substr(0, 2);
		month1 = date1.substr(3, 2);
		year1 = date1.substr(6, 4);
		day2 = date2.substr(0, 2);
		month2 = date2.substr(3, 2);
		year2 = date2.substr(6, 4);
	}
	else
	{
		day1 = date1.substr(3, 2);
		month1 = date1.substr(0, 2);
		year1 = date1.substr(6, 4);
		day2 = date2.substr(3, 2);
		month2 = date2.substr(0, 2);
		year2 = date2.substr(6, 4);
	}
	
	day1 = Number(day1);
	month1 = Number(month1);
	year1 = Number(year1);
	day2 = Number(day2);
	month2 = Number(month2);
	year2 = Number(year2);
	
	if (day1 == day2 && month1 == month2 && year1 == year2)
	{
		return 0;
	}
	else if (year2 > year1 || (year2 == year1 && month2 > month1) || (year2 == year1 && month2 == month1 && day2 > day1))
	{
		return 1;
	}
	else
	{
		return -1;
	}
}

function ScrollPos()
{
	document.getElementById("__SCROLL").value = document.body.scrollLeft + "," + document.body.scrollTop;
}

// ----------------------------------------------------------------------------
	//  ReformatNum - Checks a number and reformats it (Format #.###,##)
	//  Parameter:   strValue    (in)Number to reformat as a string
	//               decNum      (in)Number of digits after comma
	//				 art		 (in)Number 1 for German, 2 for English	
	//  Returnvalue: String containing the reformated number
	//				(blank if strValue contained an invalid number)
	//
	function ReformatNumAndRound( strValue, decNum, art, separator)
	{
		var num = GetNumber(strValue, art);
		
		var multiplikator = Math.pow(10, decNum);
		num = num * multiplikator;
		num = Math.round(num);
		num = num / multiplikator;
		num = SetNumber(num, art);
		
		return ReformatNum(num, decNum, art, separator);
	}
	
	function ReformatNum( strValue, decNum, art, separator)
	{
		var strAmount = new String( strValue );
		var newstrValue = new String;
		var len;
		var re;
		var ok;
		var th;
		var cm;

		if (art==1){
			th=".";
			re=/\./g;
			cm=",";
		}
		else {
			if (art==2){
				th=",";
				re=/,/g;
				cm=".";
			}
		}
		strAmount = strAmount.replace(re, "" );	
		
		if (art==1) strAmount=strAmount.replace( cm, "." );
		
		var numAmount = new Number( parseFloat( strAmount ) );
		if ( isNaN(numAmount) )
			return( "" );
		else{
		strAmount=numAmount.toString();	
		
		ok=0;
		for (i=0;i<strAmount.length;i++) {
			if (strAmount.charAt(i)==".") ok=1;
		}
		digit=strAmount.split(".");
		if (decNum==0) newstrValue="";
		else if (!ok){
			for(i=1;i<=decNum;i++) newstrValue=newstrValue+"0";
			newstrValue=cm+newstrValue;
		}
		else{
			sub=decNum-digit[1].length;
			if (sub>0){
				for(i=1;i<=sub;i++) newstrValue=newstrValue+"0";
				newstrValue=digit[1]+newstrValue;
			}
			else if (sub==0)newstrValue=digit[1];
			else newstrValue=digit[1].slice(0,decNum);
			newstrValue=cm+newstrValue;
		}
		len=digit[0].length-1;
		newstrValue=digit[0].charAt(len)+newstrValue;
		
		len=len-1;
		for (i=2;i<=digit[0].length;i++){
			if (i%3==0) {
				newstrValue=digit[0].charAt(len)+newstrValue;
				if ((len!=0)&&(digit[0].charAt(len-1)!="-")) newstrValue=th+newstrValue;
			}
			else newstrValue=digit[0].charAt(len)+newstrValue;
			len=len-1;
		}
		
		if (separator == 0)
		{
			newstrValue = newstrValue.replace(th, "");
		}
		return newstrValue;
			
			}
	}


	function ReformatNumPercent( strValue, decNum, art )
	{
		var strAmount = new String( strValue );
		var newstrValue = new String;
		var len;
		var ok;
		
		if (art==1){
			th=".";
			cm=",";
		}
		else if (art==2){
			th=",";
			cm=".";
		}
		strAmount=strAmount.replace("%","");
		while ( strAmount.lastIndexOf(th)>=0 )
			strAmount = strAmount.replace( th, "" );
		if (art==1) strAmount=strAmount.replace( cm, "." );
	
		var numAmount = new Number( parseFloat( strAmount ) );
		if ( isNaN(numAmount) )
			return( "" );
		else{
		strAmount=numAmount.toString();
		
		ok=0;
		for (i=0;i<strAmount.length;i++) {
			if (strAmount.charAt(i)==".") ok=1;
		}
		digit=strAmount.split(".");
		if (decNum==0) newstrValue="";
		else if (!ok){
			for(i=1;i<=decNum;i++) newstrValue=newstrValue+"0";
			newstrValue=cm+newstrValue;
		}
		else{
			sub=decNum-digit[1].length;
			if (sub>0){
				for(i=1;i<=sub;i++) newstrValue=newstrValue+"0";
				newstrValue=digit[1]+newstrValue;
			}
			else if (sub==0)newstrValue=digit[1];
			else newstrValue=digit[1].slice(0,decNum);
			newstrValue=cm+newstrValue;
			
		}
		len=digit[0].length-1;
		newstrValue=digit[0].charAt(len)+newstrValue;
		len=len-1;
		for (i=2;i<=digit[0].length;i++){
			if (i%3==0) {
				newstrValue=digit[0].charAt(len)+newstrValue;
				if ((len!=0)&&(digit[0].charAt(len-1)!="-")) newstrValue=th+newstrValue;
			}
			else newstrValue=digit[0].charAt(len)+newstrValue;
			len=len-1;
		}
		return newstrValue;//+"%";
			
			}
	}



	// ----------------------------------------------------------------------------
	//  ReformatDate - Checks a date and reformats it (Format dd.mm.yyyy )
	//  Parameter:   strDateField(in)Date to reformat as a string
	//				 art		 (in)Number 1 for German, 2 for English	
	//  Returnvalue: String containing the reformated date
	//				(blank if strDateField contained an invalid date)
	//
	function ReformatDate( strDateField, art )
	{
	    return ReformatDateExt( strDateField, art, null);
	}
	
	function ReformatDateExt( strDateField, art , baseDateControlID)
	{
		var year, month, day;
		var monthYearDot, dayMonthDot;
		var strDate = new String( strDateField );
		var numberArr = new String ("1234567890");
		var valid = false;
		var trenn, rm, rd;
		var today = new Date();
		
		if (art==1) {
			trenn=".";
		}
		else{
			trenn="/";
		}
		
		// shortcuts for dates
		if(strDateField == "." || strDateField == "t")  // today
		{
		    year = today.getFullYear();
		    month = today.getMonth()+1;
		    day = today.getDate();
		    valid = true;
		}
		else if(strDateField == "l") // last day of month
		{
		    today = new Date(today.getFullYear(), today.getMonth()+1, 0);
		    year = today.getFullYear();
		    month = today.getMonth()+1;
		    day = today.getDate();
		    valid = true;
		}
		else if(strDateField == "p") // last day of previous month
		{
		    today = new Date(today.getFullYear(), today.getMonth(), 0);
		    year = today.getFullYear();
		    month = today.getMonth()+1;
		    day = today.getDate();
		    valid = true;
		}
		else if((strDate.length <= 2) && (strDate.length >= 1) && !isNaN(strDate)) // days without month and year
		{
		    today.setDate(strDate);  
		    year = today.getFullYear();
		    month = today.getMonth()+1;
		    day = today.getDate();
		    valid = true;
		}
		
		// timespans
		else if((strDate.match("[0-9]+[dwmy][+]*$$")))
		{
		    var baseDate = null;
		    
		    var control = document.getElementById(baseDateControlID);
		    if(control != null)
		    {
		        var strBaseDate = GetDate(ReformatDate(control.value, art));
		        baseDate = new Date(new Number(parseInt(strBaseDate.substr(0, 4), 10)), new Number(parseInt(strBaseDate.substr(5, 2), 10))-1, new Number(parseInt(strBaseDate.substr(8, 2), 10)));
		    }
		    else
		    {
		        baseDate = today;
		    }
		    
	        var addLastDay = false;
	        if(strDate.substr(strDate.length-1, 1) == "+")
	        {
	            strDate = strDate.substr(0, strDate.length-1)
	            addLastDay = true;
	        }
	        
	        var timespan = strDate.substr(strDate.length-1, 1);
	        var count = new Number(parseInt(strDate.substr(0, strDate.length-1), 10));
	        
	        if(timespan == "d")
	        {
	            today = new Date(baseDate.getTime() + (count-1)*24*60*60*1000);
	        }
	        else if(timespan == "w")
	        {
	            today = new Date(baseDate.getTime() + (count*7-1)*24*60*60*1000);
	        }
	        else if(timespan == "m")
	        {
	            var today = new Date(baseDate.getFullYear(), baseDate.getMonth(), baseDate.getDate());
                today.setMonth(baseDate.getMonth() + count);
                if (today.getDate() < baseDate.getDate()) 
                {
                    today.setDate(1);
                    today.setDate(today.getDate() - 2);
                }
                else
                {
                    today = new Date(today.getFullYear(), today.getMonth(), today.getDate() - 1);
                }
	        }
	        else if(timespan == "y")
	        {
                today = new Date(baseDate.getFullYear()+ count, baseDate.getMonth(), baseDate.getDate()-1);
	        }
	        if(addLastDay)
	        {
	            today = new Date(today.getTime() + 24*60*60*1000);
	        }
	        
	        year = today.getFullYear();
	        month = today.getMonth()+1;
	        day = today.getDate();
	        valid = true;
		}
		
		// "normal" date
    	else
    	{
		    monthYearDot = strDate.lastIndexOf( trenn );
		    if ( monthYearDot!=(-1) )
		    {
			    year = new Number( parseInt( strDate.substring( monthYearDot+1, strDate.length ),10 ) );
			    if ( year<100 ) 
				    year += 2000;
			    dayMonthDot = strDate.lastIndexOf( trenn, monthYearDot-1 );
			    if ( dayMonthDot!=(-1) )
			    {	
				    month = strDate.substring( dayMonthDot+1, monthYearDot);
				    if (month<"10") {
					    month=month.replace("0","");
				    }
				    month = new Number(parseInt(month));
				    day = strDate.substring( 0, dayMonthDot );
				    if (day!="10" && day!="20" && day!="30") {
					    day=day.replace("0","");
				    }
				    day = new Number(parseInt(day));
    				
				    if (art==2){
					    i=month;
					    month=day;
					    day=i;
				    }
				    if ( month>=1 && month<=12 && day>=1 && day<=31 )
					    if ( month==2 )
						    if ( (year%4==0 && year%100!=0) || year%400==0 )
							    valid = day<=29;
						    else
							    valid = day<=28;
					    else if ( month==4 || month==6 || month==9 || month==11 )
						    valid = day<=30;
					    else
						    valid = true;
			    }
		    }
		    // Date without any "." or "/"
		    else
		    {	i=-1;
			    do
			    {
				    i++;
				    valid=numberArr.indexOf(strDate.charAt(i))!=-1;
			    }
			    while (i<strDate.length-1 && valid )
    			
			    if (valid) 
			    {
				    d = new Date();
				    switch(strDate.length){
					    case 4:
							    day = strDate.substring(0,2);
							    month = strDate.substring(2,4);
							    year = d.getFullYear();
						    break;
					    case 6:
							    day = strDate.substring(0,2);
							    month = strDate.substring(2,4);
							    year = "20"+strDate.substring(4,6);
						    break;
					    case 8:
							    day = strDate.substring(0,2);
							    month = strDate.substring(2,4);
							    year = strDate.substring(4,8);
						    break;
					    default:
						    day=""; month="";year="0";
						    valid=false;
				    }
				    if (art==2) //english
				    {
					    z=day;
					    day=month;
					    month=z;
				    }
    				
				    if (month<"10") {
					    month=month.replace("0","");
				    }
				    if (day!="10" && day!="20" && day!="30") {
					    day=day.replace("0","");
				    }
    				
				    if (day!="" && month!="" && year!="0")
				    {
					    day = new Number(parseInt(day));
					    month = new Number(parseInt(month));
					    year = new Number(parseInt(year));
    					
					    if ( month>=1 && month<=12 && day>=1 && day<=31 )
						    if ( month==2 )
							    if ( (year%4==0 && year%100!=0) || year%400==0 )
								    valid = day<=29;
							    else
								    valid = day<=28;
						    else if ( month==4 || month==6 || month==9 || month==11 )
							    valid = day<=30;
						    else
							    valid = true;
					    else valid = false;
				    } 
				    else valid=false;
    				
			    }
			    else {valid=false;}		
    			
		    }
		}
		if ( !valid )
			return( "" );
		else
			if (month<10) { 
				rm="0"+month;
			}
			else{
				rm=""+month;
			}
			if (day<10) { 
				rd="0"+day;
			}
			else{
				rd=""+day;
			}
			if (art==1)	return( rd+"."+rm+"."+year );
			else if (art==2) return(rm+"/"+rd+"/"+year);
	}
	
	function ReformatTime( strDateField, art )
	{
		var hour = "";
		var minute = "";
		var valid = true;
		
		// if . is entered -> take current time
		if(strDateField == ".")
		{
		    var today = new Date();
		    hour = today.getHours();
		    minute = today.getMinutes();
		    valid = true;
		}
		else
		{
		    if(strDateField.indexOf(":") == -1)
		    {
		        if(strDateField.length == 4)
		        {
		            if(strDateField.substr(0,1) == "0")
		            {
		                hour = parseInt(strDateField.substr(1, 1));
		            }
		            else
		            {
		                hour = parseInt(strDateField.substr(0, 2));
		            }
		            minute = parseInt(strDateField.substr(2, 2));
		        }
		    }
		    else
		    {
		        if(strDateField.substr(0,1) == "0")
		        {
		            hour = parseInt(strDateField.substr(1, strDateField.indexOf(":")));
		        }
		        else
		        {
		            hour = parseInt(strDateField.substr(0, strDateField.indexOf(":")));
		        }
		        minute = parseInt(strDateField.substring(strDateField.indexOf(":") + 1, strDateField.length));
		    }
    	}
    	
	    if (isNaN(hour) || isNaN(minute) || (hour=="" && minute==""))
	    {
		    valid = false;
	    }
	    else
	    {
		    if (hour > 23 || minute > 59)
		    {
			    valid = false;
		    }
		    else
		    {
			    if (hour < 10)
			    {
				    hour = "0" + String(hour);
			    }
			    if (minute < 10)
			    {
				    minute = "0" + String(minute);
			    }
		    }
	    }
	    
		if (valid)
		{
			return String(hour) + ":" + String(minute);
		}
		else
		{
			return "";
		}
	}

	