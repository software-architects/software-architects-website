﻿using System;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Data.SqlClient;
using System.Configuration;
using WatiN.Core;
using BugBusters.Data;
using System.Globalization;
using WatiN.Core.DialogHandlers;
using WatiN.Core.UnitTests;
using Microsoft.VisualStudio.TestTools.UnitTesting.Web;

namespace BugBusters.Test
{
    [TestClass]
    public class UserInterfaceTests
    {
        private interface IAssertable
        {
            void AssertControls();
        }

        private abstract class Screen : IDisposable
        {
            public IE ie { get; private set; }

            public Screen(string url, bool attach)
            {
                ie = attach ? IE.AttachToIE(Find.ByUrl(url)) : new IE(url);
                Assert.IsFalse(ie.Html.Contains("Runtime Error"));
                if (this is IAssertable)
                    ((IAssertable)this).AssertControls();
            }

            public Screen(string url)
                : this(url, false)
            {
            }

            public void Dispose()
            {
                ie.Close();
                ie.Dispose();
                GC.SuppressFinalize(this);
            }
        }

        private class OverviewScreen : Screen, IAssertable
        {
            private const string Url = "http://localhost/BugBusters/Default.aspx";
            private const string Control_WindowsLoginFilter = "lstUsers";
            private const string Control_ResultGrid = "Result";
            private const string Control_AddNewLink = "lnkAddItem";
            private const string Control_HelpLink = "lnkHelp";
            public const string FilterItem_All = "All";
            public const int NumberOfResultColumns = 8;
            public const int ColumnIndex_StartTime = 3;
            public const int ColumnIndex_EndTime = 4;
            public const int ColumnIndex_Duration = 5;

            public OverviewScreen()
                : base(Url)
            {
            }

            public void AssertControls()
            {
                var loginFilter = ie.SelectList(Control_WindowsLoginFilter);
                Assert.IsTrue(loginFilter.Exists);
                var resultTable = ie.Table(Control_ResultGrid);
                Assert.IsTrue(resultTable.Exists);
            }

            public SelectList LoginFilter
            {
                get
                {
                    var loginFilter = ie.SelectList(Control_WindowsLoginFilter);
                    Assert.IsTrue(loginFilter.Exists);
                    return loginFilter;
                }
            }
            public void SetLoginFilter(string user)
            {
                // select the current user
                LoginFilter.Select(user);
                // page has been reloaded -> call AssertControls again to verify consistency
                AssertControls();
            }

            public Table ResultGrid
            {
                get
                {
                    var resultTable = ie.Table(Control_ResultGrid);
                    Assert.IsTrue(resultTable.Exists);
                    return resultTable;
                }
            }

            public Link HelpLink
            {
                get
                {
                    var link = ie.Link(Control_HelpLink);
                    Assert.IsTrue(link.Exists);
                    return link;
                }
            }

            public Link AddNewLink
            {
                get
                {
                    var link = ie.Link(Control_AddNewLink);
                    Assert.IsTrue(link.Exists);
                    return link;
                }
            }
        }

        private abstract class Dialog : IDisposable
        {
            protected HtmlDialog dialog { get; private set; }

            public Dialog(Screen parentScreen, string url)
            {
                dialog = parentScreen.ie.HtmlDialog(Find.ByUrl(url), 2);
                if (this is IAssertable)
                    ((IAssertable)this).AssertControls();
            }

            public void Dispose()
            {
                dialog.Close();
                GC.SuppressFinalize(this);
            }
        }

        private class HelpScreen : Dialog, IAssertable
        {
            private const string Url = "http://localhost/BugBusters/Help.aspx";

            public HelpScreen(Screen parentScreen)
                : base(parentScreen, Url)
            {
            }

            public void AssertControls()
            {
                Assert.IsTrue(dialog.Html.Contains("Help"));
                Assert.IsFalse(dialog.Html.Contains("Error"));
            }
        }

        private class AddEntryScreen : Screen, IAssertable
        {
            private const string Url = "http://localhost/BugBusters/EditItem.aspx";
            public const string Control_ProjectCode = "InsertForm_lstProjects";
            public const string Control_TaskTypeCode = "InsertForm_lstTaskTypes";
            public const string Control_WindowsLoginCode = "InsertForm_lstUsers";
            public const string Control_StartTimeCode = "InsertForm_txtStartTime";
            public const string Control_EndTimeCode = "InsertForm_txtEndTime";
            public const string Control_Comment = "InsertForm_txtComment";
            public const string Control_StoreLink = "InsertForm_lnkStore";
            public const string Control_CancelLink = "InsertForm_lnkCancel";

            public AddEntryScreen()
                : base(Url, true)
            {
            }

            public void AssertControls()
            {
                var projectCode = ie.SelectList(Control_ProjectCode);
                Assert.IsTrue(projectCode.Exists);
                var taskType = ie.SelectList(Control_TaskTypeCode);
                Assert.IsTrue(taskType.Exists);
                var windowsLogin = ie.SelectList(Control_WindowsLoginCode);
                Assert.IsTrue(windowsLogin.Exists);
                var startTime = ie.TextField(Control_StartTimeCode);
                Assert.IsTrue(startTime.Exists);
                var endTime = ie.TextField(Control_EndTimeCode);
                Assert.IsTrue(endTime.Exists);
                var comment = ie.TextField(Control_Comment);
                Assert.IsTrue(comment.Exists);
            }

            public SelectList ProjectCode
            {
                get
                {
                    var result = ie.SelectList(Control_ProjectCode);
                    Assert.IsTrue(result.Exists);
                    return result;
                }
            }
            public SelectList TaskType
            {
                get
                {
                    var result = ie.SelectList(Control_TaskTypeCode);
                    Assert.IsTrue(result.Exists);
                    return result;
                }
            }
            public SelectList Users
            {
                get
                {
                    var result = ie.SelectList(Control_WindowsLoginCode);
                    Assert.IsTrue(result.Exists);
                    return result;
                }
            }
            public TextField StartTime
            {
                get
                {
                    var result = ie.TextField(Control_StartTimeCode);
                    Assert.IsTrue(result.Exists);
                    return result;
                }
            }
            public TextField EndTime
            {
                get
                {
                    var result = ie.TextField(Control_EndTimeCode);
                    Assert.IsTrue(result.Exists);
                    return result;
                }
            }
            public TextField Comment
            {
                get
                {
                    var result = ie.TextField(Control_Comment);
                    Assert.IsTrue(result.Exists);
                    return result;
                }
            }
            public Link StoreLink
            {
                get
                {
                    var result = ie.Link(Control_StoreLink);
                    Assert.IsTrue(result.Exists);
                    return result;
                }
            }
            public Link CancelLink
            {
                get
                {
                    var result = ie.Link(Control_CancelLink);
                    Assert.IsTrue(result.Exists);
                    return result;
                }
            }

            public void EnterTestData()
            {
                StartTime.TypeText(DateTime.Now.ToString("g", CultureInfo.CreateSpecificCulture("de-DE")));
                EndTime.TypeText(DateTime.Now.AddHours(1).ToString("g", CultureInfo.CreateSpecificCulture("de-DE")));
                Comment.TypeText("Test entry");
            }
        }

        public UserInterfaceTests()
        {
        }

        #region TestContext Property
        private TestContext testContextInstance;
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }
        #endregion

        #region Test and class initialization and cleanup code
        private BugBustersDataContext db;
        /// <summary>
        /// Initialize test database using SQL initialization script and open data context
        /// </summary>
        [TestInitialize()]
        public void TimeTrackingUITestInitialize()
        {
            string connString = ConfigurationManager.ConnectionStrings["TestDatabase"].ConnectionString;
            db = new BugBustersDataContext(ConfigurationManager.ConnectionStrings["TestDatabase"].ConnectionString);
            db.Connection.Open();
            var cmd = new SqlCommand(ConfigurationManager.AppSettings["TestDatabaseInitializationScript"], (SqlConnection)db.Connection);
            cmd.ExecuteNonQuery();
            cmd = new SqlCommand(ConfigurationManager.AppSettings["UITestDatabaseInitializationScript"], (SqlConnection)db.Connection);
            cmd.ExecuteNonQuery();
        }
        /// <summary>
        /// Close data context after test is done
        /// </summary>
        [TestCleanup()]
        public void TimeTrackingConstraintsTestCleanup()
        {
            db.Dispose();
            db = null;
        }
        #endregion

        [TestMethod]
        public void Overview_Launch()
        {
            using (var screen = new OverviewScreen())
            {
                // Check that login filter contains the correct number of items (number of rows in db plus "All");
                Assert.AreEqual(db.Users.Count() + 1, screen.LoginFilter.AllContents.Count);
                // Check that item "All" is present
                Assert.IsTrue(screen.LoginFilter.AllContents.Contains(OverviewScreen.FilterItem_All));

                // Table has to have at least one row (header)
                Assert.IsTrue(screen.ResultGrid.TableRows.Length >= 1);
                // Table has to have 8 columns
                Assert.AreEqual(OverviewScreen.NumberOfResultColumns,
                    screen.ResultGrid.TableRows[0].Elements.Cast<Element>().Count(elem => elem.TagName == "TH"));
            }
        }

        [TestMethod]
        public void Overview_Filter()
        {
            using (var screen = new OverviewScreen())
            {
                // iterate over all users in the database plus "All"
                foreach (var user in (new string[] { OverviewScreen.FilterItem_All }).Union(from u in db.Users select u.WindowsLogin))
                {
                    // select the current user
                    screen.SetLoginFilter(user);

                    // check that the number of rows in the table corresponds to the number of entries in the database.
                    // would not work with paging and a large number of rows!! Just to keep it simple here...
                    if (user != OverviewScreen.FilterItem_All)
                        Assert.AreEqual(db.Users.Single(uu => uu.WindowsLogin == user).TimeTrackings.Count + 1, screen.ResultGrid.TableRows.Length);
                    else
                        Assert.AreEqual(db.TimeTrackings.Count() + 1, screen.ResultGrid.TableRows.Length);
                }
            }
        }

        [TestMethod]
        public void Overview_TimeColumns()
        {
            var formatDe = CultureInfo.CreateSpecificCulture("de-DE");

            using (var screen = new OverviewScreen())
            {
                screen.SetLoginFilter(OverviewScreen.FilterItem_All);

                // iterate through all lines (except header)
                for (int i = 1; i < screen.ResultGrid.TableRows.Length; i++)
                {
                    // parse start and end time and check if calculation is done correctly
                    TableRow tr = screen.ResultGrid.TableRows[i];
                    var startTime = DateTime.ParseExact(tr.TableCells[OverviewScreen.ColumnIndex_StartTime].InnerHtml, "g", formatDe);
                    var endTime = DateTime.ParseExact(tr.TableCells[OverviewScreen.ColumnIndex_EndTime].InnerHtml, "t", formatDe);
                    TimeSpan duration = endTime - startTime;
                    DateTime durationUI = DateTime.ParseExact(tr.TableCells[OverviewScreen.ColumnIndex_Duration].InnerHtml, "t", formatDe);
                    Assert.IsTrue(duration.Hours == durationUI.Hour && duration.Minutes == durationUI.Minute);
                }
            }
        }

        [TestMethod()]
        public void Overview_Delete()
        {
            using (var screen = new OverviewScreen())
            {
                screen.SetLoginFilter(OverviewScreen.FilterItem_All);

                // remember number of records before delete
                // (just to keep it simple; not a good idea if tests are running simulateously)
                var numberOfTimeTrackingRecords = db.TimeTrackings.Count();

                // press delete button for first row
                Assert.AreEqual(1, screen.ResultGrid.TableRows[1].TableCells[OverviewScreen.NumberOfResultColumns - 1].Links.Length);
                screen.ResultGrid.TableRows[1].TableCells[OverviewScreen.NumberOfResultColumns - 1].Links[0].Click();
                // page has been reloaded -> call AssertControls again to verify consistency
                screen.AssertControls();

                // check if row has been deleted and result grid has been refreshed
                Assert.AreEqual(numberOfTimeTrackingRecords - 1, db.TimeTrackings.Count());
                Assert.AreEqual(numberOfTimeTrackingRecords - 1, screen.ResultGrid.TableRows.Length - 1);
            }
        }

        /// <summary>
        /// Test for help-function on the "Overview"-Screen
        /// </summary>
        [TestMethod()]
        public void Overview_Help()
        {
            using (var screen = new OverviewScreen())
            {
                screen.HelpLink.ClickNoWait();
                using (var help = new HelpScreen(screen)) { };
            }
        }

        [TestMethod]
        public void AddEntry_Launch()
        {
            using (var overviewScreen = new OverviewScreen())
            {
                overviewScreen.AddNewLink.ClickNoWait();
                using (var screen = new AddEntryScreen())
                {
                    // Check that combo boxes contain the correct number of items
                    Assert.AreEqual(db.Projects.Count(), screen.ProjectCode.AllContents.Count);
                    Assert.AreEqual(db.TaskTypes.Count(), screen.TaskType.AllContents.Count);
                    Assert.AreEqual(db.Users.Count(), screen.Users.AllContents.Count);
                }
            }
        }

        [TestMethod]
        public void AddEntry_TimeFieldFormat()
        {
            using (var overviewScreen = new OverviewScreen())
            {
                overviewScreen.AddNewLink.ClickNoWait();
                using (var screen = new AddEntryScreen())
                {
                    // test format logic
                    TestDateTimeField(screen.StartTime);
                    TestDateTimeField(screen.EndTime);

                    // test copy logic
                    screen.EndTime.TypeText("");
                    screen.StartTime.TypeText("0800");
                    Assert.AreEqual(screen.StartTime.Text, screen.EndTime.Text);
                    screen.StartTime.TypeText("0900");
                    Assert.AreNotEqual(screen.StartTime.Text, screen.EndTime.Text);
                }
            }
        }
        /// <summary>
        /// Internal helper function for testing format logic in date/time fields
        /// </summary>
        /// <param name="field">Field to test</param>
        private static void TestDateTimeField(TextField field)
        {
            var formatDe = CultureInfo.CreateSpecificCulture("de-DE");
            field.TypeText("24.02.2008 15:00");
            Assert.AreEqual(new DateTime(2008, 2, 24, 15, 0, 0), DateTime.ParseExact(field.Text, "g", formatDe));

            field.TypeText("29.02.2008 15:00");
            Assert.AreEqual(new DateTime(2008, 2, 29, 15, 0, 0), DateTime.ParseExact(field.Text, "g", formatDe));

            field.TypeText("29022008 1500");
            Assert.AreEqual(new DateTime(2008, 2, 29, 15, 0, 0), DateTime.ParseExact(field.Text, "g", formatDe));

            field.TypeText("29.02.2007 15:00");
            Assert.IsNull(field.Text);

            field.TypeText("abc");
            Assert.IsNull(field.Text);
        }

        [TestMethod]
        public void AddEntry_Store()
        {
            using (var overviewScreen = new OverviewScreen())
            {
                overviewScreen.SetLoginFilter(OverviewScreen.FilterItem_All);

                // remember number of records before delete
                // (just to keep it simple; not a good idea if tests are running simulateously)
                var numberOfTimeTrackingRecords = db.TimeTrackings.Count();

                overviewScreen.AddNewLink.ClickNoWait();
                using (var screen = new AddEntryScreen())
                {
                    // fill in test data
                    screen.EnterTestData();
                    // click store-button and wait until parent page has been refreshed
                    screen.StoreLink.ClickNoWait();
                    overviewScreen.ie.WaitForComplete();

                    // check if row has been deleted and result grid has been refreshed
                    Assert.AreEqual(numberOfTimeTrackingRecords + 1, db.TimeTrackings.Count());
                    Assert.AreEqual(numberOfTimeTrackingRecords + 1, overviewScreen.ResultGrid.TableRows.Length - 1);
                }
            }
        }

        [TestMethod]
        public void AddEntry_CancelYes()
        {
            using (var overviewScreen = new OverviewScreen())
            {
                // remember number of records before delete
                // (just to keep it simple; not a good idea if tests are running simulateously)
                var numberOfTimeTrackingRecords = db.TimeTrackings.Count();

                overviewScreen.AddNewLink.ClickNoWait();
                using (var screen = new AddEntryScreen())
                {
                    // fill in test data
                    screen.EnterTestData();

                    // click cancel and then NO -> must return to dialog
                    var confirm = new ConfirmDialogHandler();
                    using (new UseDialogOnce(screen.ie.DialogWatcher, confirm))
                    {
                        screen.CancelLink.ClickNoWait();
                        confirm.WaitUntilExists();
                        confirm.CancelButton.Click();
                        screen.ie.WaitForComplete();
                    }

                    // click cancel and then YES -> must return to "Overview" screen
                    using (new UseDialogOnce(screen.ie.DialogWatcher, confirm))
                    {
                        screen.CancelLink.ClickNoWait();
                        confirm.WaitUntilExists();
                        confirm.OKButton.Click();
                        overviewScreen.ie.WaitForComplete();

                        // make sure nothing changed after cancel
                        Assert.AreEqual(numberOfTimeTrackingRecords, db.TimeTrackings.Count());
                        Assert.AreEqual(numberOfTimeTrackingRecords, overviewScreen.ResultGrid.TableRows.Length - 1);
                    }
                }
            }
        }
    }
}
