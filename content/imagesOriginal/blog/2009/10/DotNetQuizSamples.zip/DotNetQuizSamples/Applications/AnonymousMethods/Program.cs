﻿namespace AnonymousMethods
{
    class Program
    {
        delegate int CalcOperation(int x);
        static int PerformCalculation( int x, CalcOperation calc )
        {
            return calc(x);
        }
        static void Main()
        {
            System.Console.Write(PerformCalculation(5, delegate(int x) { return x * x; }));
            System.Console.Write(PerformCalculation(5, x => x*x ));
        }
    }
}
