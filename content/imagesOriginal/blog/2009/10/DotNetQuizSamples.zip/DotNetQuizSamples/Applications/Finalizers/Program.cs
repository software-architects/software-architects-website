﻿using System;
using System.IO;

namespace Finalizers
{
    internal class FileGenerator : IDisposable
    {
        public FileGenerator()
        {
        }
        ~FileGenerator()
        {
            // Just a debug output
            Console.WriteLine("Closing file!");
        }
        public void Generate(int Length)
        {
            // Here some work is done...
        }
        public void Dispose()
        {
            // Just a debug output
            Console.WriteLine("Disposing object!");
        }
    }

    class Program
    {
        static void Generate()
        {
            // Here it would be better to use the C# "using" keyword instead of implicitly calling Dispose!
            using ( var fGen = new FileGenerator() )
                fGen.Generate(512);
            //fGen.Dispose();
        }
        static void Main(string[] args)
        {
            Generate();
            // Here we do some work; simulated by ReadLine statement
            Console.Write("Please Press Enter...");
            Console.ReadLine();
        }
    }
}
