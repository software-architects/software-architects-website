﻿namespace ForeachVsFor
{
    class Program
    {
        static void Main()
        {
            var x = new[] { 1, 2, 3, 4, 5 };

            for (int i = 0; i < x.Length; i++)
                System.Console.WriteLine(x[i]);

            foreach (var i in x)
                System.Console.WriteLine(i);
        }
    }
}
