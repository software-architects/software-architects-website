﻿namespace ImplicitTypes
{
    class Program
    {
        static void Main()
        {
            var v = "Hello World!";

            /*
             * The following line does not compile. It produces the error "Cannot implicitly convert type 'int' to 'string'. 
             * The reason is that the new keyword "var" does not mean "variant"! It just means that the compiler determines 
             * and assigns the most appropriate type DURING COMPILE TIME!
             */
            // v = 10;

            System.Console.WriteLine(v);
        }
    }
}
