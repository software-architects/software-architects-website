﻿namespace JIT
{
    class Program
    {
        static void Method1()
        {
            System.Console.WriteLine("Method1");
        }
        static void Method2()
        {
            System.Console.WriteLine("Method2");
        }
        static void Main()
        {
            System.Console.ReadLine();
            Method1();
            System.Console.ReadLine();
            Method2();
            System.Console.ReadLine();
            Method1();
            System.Console.ReadLine();
        }
    }
}
