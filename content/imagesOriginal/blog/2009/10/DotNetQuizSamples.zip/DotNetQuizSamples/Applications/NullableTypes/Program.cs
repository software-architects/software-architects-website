﻿namespace NullableTypes
{
    class Program
    {
        static void Main()
        {
            int a = 10;
            //System.Nullable<int> b = 20;
            int? b = 20;
            int? c = null;
            System.Console.WriteLine( a + c ?? b );
        }
    }
}
