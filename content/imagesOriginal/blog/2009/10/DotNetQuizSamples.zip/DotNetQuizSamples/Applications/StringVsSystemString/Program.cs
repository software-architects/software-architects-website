﻿namespace StringVsSystemString
{
    internal class PersonString
    {
        public string FirstName { get; private set; }
        public string LastName { get; private set; }

        public PersonString(string FirstName, string LastName)
        {
            this.FirstName = FirstName;
            this.LastName = LastName;
        }

        public void Replace( string TextToFind, string ReplacingText )
        {
            FirstName = FirstName.Replace( TextToFind, ReplacingText );
            LastName = LastName.Replace( TextToFind, ReplacingText );
        }

        public override string ToString()
        {
            return FirstName + " " + LastName;
        }
    }

    internal class PersonSystemString
    {
        public System.String FirstName { get; private set; }
        public System.String LastName { get; private set; }

        public PersonSystemString(System.String FirstName, System.String LastName)
        {
            this.FirstName = FirstName;
            this.LastName = LastName;
        }

        public void Replace(System.String TextToFind, System.String ReplacingText)
        {
            FirstName = FirstName.Replace(TextToFind, ReplacingText);
            LastName = LastName.Replace(TextToFind, ReplacingText);
        }

        public override System.String ToString()
        {
            return FirstName + " " + LastName;
        }
    }

    static class Program
    {
        static void Main()
        {
            var pString = new PersonString("Rainer", "Stropek");
            System.Console.WriteLine(pString);

            var pSystemString = new PersonSystemString("Rainer", "Stropek");
            System.Console.WriteLine(pSystemString);
        }
    }
}
