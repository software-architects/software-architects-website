﻿namespace ValueVsReferenceTypes
{
    class Program
    {
        static void Main()
        {
            var stringValue = "Hello World!";
            var stringValue2 = stringValue;
            stringValue = "Hello Austria!";
            System.Console.WriteLine(stringValue2);

            var array = new[] { 1, 2, 3, 4 };
            var array2 = array;
            array[0] = 99;
            System.Console.WriteLine(array2[0]);
        }
    }
}
