﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using SoftwareArchitects.Windows.Controls;

namespace SoftwareArchitects.ScrollViewerUI
{
	public partial class MainPage : UserControl
	{
		public MainPage()
		{
			InitializeComponent();

			// Fill listboxes
			for (var i = 0; i < 100; i++)
			{
				// ListBoxes
				this.ListBox1.Items.Add(new ListBoxItem() { Content = string.Format("This is item {0}", i) });
				this.ListBox2.Items.Add(new ListBoxItem() { Content = string.Format("This is item {0}", i) });
				this.Loaded += new RoutedEventHandler(MainPage_Loaded);

				// ScrollViewers
				//this.Panel1.Children.Add(new TextBlock() { Text = string.Format("This is item {0}", i) });
				//this.Panel2.Children.Add(new TextBlock() { Text = string.Format("This is item {0}", i) });
			}
		}

		private void MainPage_Loaded(object sender, RoutedEventArgs e)
		{
			this.ListBox1.ApplyTemplate();
			this.ListBox2.ApplyTemplate();

			ScrollSynchronizer.SetScrollGroup((ScrollViewer)VisualTreeHelper.GetChild(VisualTreeHelper.GetChild(VisualTreeHelper.GetChild(this.ListBox1, 0), 0), 0), "Group1");
			ScrollSynchronizer.SetScrollGroup((ScrollViewer)VisualTreeHelper.GetChild(VisualTreeHelper.GetChild(VisualTreeHelper.GetChild(this.ListBox2, 0), 0), 0), "Group1");
		}
	}
}
