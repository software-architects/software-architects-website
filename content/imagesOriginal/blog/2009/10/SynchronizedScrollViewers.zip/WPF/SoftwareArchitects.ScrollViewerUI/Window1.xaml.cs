﻿using System.Windows;
using System.Windows.Controls;

namespace SoftwareArchitects.ScrollViewerUI
{
	/// <summary>
	/// Interaction logic for Window1.xaml
	/// </summary>
	public partial class Window1 : Window
	{
		public Window1()
		{
			InitializeComponent();

			// Fill listboxes
			for (var i = 0; i < 100; i++)
			{
				// ListBoxes
				this.ListBox1.Items.Add(new ListBoxItem() { Content = string.Format("This is item {0}", i) });
				this.ListBox2.Items.Add(new ListBoxItem() { Content = string.Format("This is item {0}", i) });

				// ScrollViewers
				//this.Panel1.Children.Add(new TextBlock() { Text = string.Format("This is item {0}", i) });
				//this.Panel2.Children.Add(new TextBlock() { Text = string.Format("This is item {0}", i) });
			}
		}
	}
}
