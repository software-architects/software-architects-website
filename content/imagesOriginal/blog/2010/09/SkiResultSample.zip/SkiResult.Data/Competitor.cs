﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SkiResult.Data
{
	partial class Competitor
	{
		partial void OnTotalTimeChanging(TimeSpan? value)
		{
			if (value.HasValue && value > TimeSpan.FromMinutes(10))
			{
				throw new ArgumentException(
					"Total time must not be greater than 10 minutes",
					"value");
			}
		}
	}
}
