﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using SkiResult.Data;
using System.Data;

namespace SkiResult.DataService
{
	[ServiceContract]
	public class SkiResultService 
	{
		[OperationContract]
		public IEnumerable<Event> GetEvents()
		{
			using (var context = new SkiResultEntities())
			{
				var result = context.Events.ToList();
				result.ForEach(e => context.Detach(e));
				return result;
			}
		}

		[OperationContract]
		public IEnumerable<Competitor> GetCompetitors(Guid eventIdFilter)
		{
			using (var context = new SkiResultEntities())
			{
				var result = context.Competitors.Include("Event")
					.Where(c => c.EventID == eventIdFilter).ToList();
				result.ForEach(e => context.Detach(e));
				return result;
			}
		}

		[OperationContract]
		public void SaveCompetitor(Competitor competitor)
		{
			using (var context = new SkiResultEntities())
			{
				context.Attach(competitor);
				context.ObjectStateManager.ChangeObjectState(competitor, EntityState.Modified);
				context.SaveChanges();
			}
		}
	}
}
