﻿using System.Collections.Generic;
using System.ComponentModel;
using SkiResult.UI.SkiResultService;
using System.Windows.Input;
using System;

namespace SkiResult.UI.ViewModel
{
	public class MaintenanceFormViewModel : INotifyPropertyChanged
	{
		private SkiResultServiceClient serviceClient =
			new SkiResultServiceClient();

		public MaintenanceFormViewModel()
		{
			this.RefreshEvents();
			this.saveCompetitor = new SaveCurrentCompetitor(this);
		}

		private void RefreshEvents()
		{
			this.serviceClient.GetEventsCompleted += (s, e) =>
				{
					this.Events = e.Result;
				};
			this.serviceClient.GetEventsAsync();
		}

		private IEnumerable<Event> events;
		public IEnumerable<Event> Events
		{
			get
			{
				return this.events;
			}

			set
			{
				this.events = value;
				this.OnPropertyChanged("Events");
			}
		}

		private Event currentEvent;
		public Event CurrentEvent
		{
			get
			{
				return this.currentEvent;
			}

			set
			{
				this.currentEvent = value;
				this.OnPropertyChanged("CurrentEvent");
				this.RefreshCompetitors();
			}
		}

		private Competitor currentCompetitor;
		public Competitor CurrentCompetitor
		{
			get
			{
				return this.currentCompetitor;
			}

			set
			{
				this.currentCompetitor = value;
				this.OnPropertyChanged("CurrentCompetitor");
			}
		}

		private IEnumerable<Competitor> competitors;
		public IEnumerable<Competitor> Competitors
		{
			get
			{
				return this.competitors;
			}

			set
			{
				this.competitors = value;
				OnPropertyChanged("Competitors");
			}
		}

		private void RefreshCompetitors()
		{
			this.serviceClient.GetCompetitorsCompleted += (s, e) =>
			{
				this.Competitors = e.Result;
			};
			this.serviceClient.GetCompetitorsAsync(this.CurrentEvent.EventID);
		}

		private void OnPropertyChanged(string propertyName)
		{
			if (this.PropertyChanged != null)
			{
				this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		public event PropertyChangedEventHandler PropertyChanged;

		private void SaveCompetitorImplementation()
		{
			this.serviceClient.SaveCompetitorAsync(this.CurrentCompetitor);
		}

		private SaveCurrentCompetitor saveCompetitor;
		public SaveCurrentCompetitor SaveCompetitor
		{
			get
			{
				return this.saveCompetitor;
			}
		}

		public class SaveCurrentCompetitor : ICommand
		{
			private MaintenanceFormViewModel viewModel;

			public SaveCurrentCompetitor(MaintenanceFormViewModel viewModel)
			{
				this.viewModel = viewModel;
				this.viewModel.PropertyChanged += (s, e) =>
					{
						if (this.CanExecuteChanged != null)
						{
							this.CanExecuteChanged(this, new EventArgs());
						}
					};
			}

			public bool CanExecute(object parameter)
			{
				return this.viewModel.CurrentCompetitor != null;
			}

			public event System.EventHandler CanExecuteChanged;

			public void Execute(object parameter)
			{
				this.viewModel.SaveCompetitorImplementation();
			}
		}
	}
}
