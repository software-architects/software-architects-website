﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SkiResult.UI.ViewModel;
using System.Threading;

namespace SkiResult.Test
{
	[TestClass]
	public class ViewModelTest
	{
		[TestMethod]
		public void TestEventListRefresh()
		{
			var vm = new MaintenanceFormViewModel();

			// View model has to load events within 3 seconds
			Thread.Sleep(3000);
			Assert.IsTrue(vm.Events.Count() > 0);
		}

		[TestMethod]
		public void TestCompetitorListRefresh()
		{
			var vm = new MaintenanceFormViewModel();

			// View model has to load events within 3 seconds
			Thread.Sleep(3000);

			var competitorRefreshEventRaised = false;
			vm.PropertyChanged += (s, e) =>
				{
					if (e.PropertyName == "Competitors")
					{
						competitorRefreshEventRaised = true;
					}
				};
			vm.CurrentEvent = vm.Events.Skip(1).First();

			// View model has to load competitors within 3 seconds
			Thread.Sleep(3000);

			Assert.IsTrue(competitorRefreshEventRaised);
			Assert.IsTrue(vm.Competitors.Count() > 0);
		}
	}
}
