﻿using System;
using System.IO;

namespace Events.Data
{
	public class LocalTemplateManager : TemplateManager
	{
		private const string RegistrationConfirmationSource = @"C:\temp\azuretests\Anmeldebestaetigung.docx";
		private const string SentEmailFolder = @"C:\temp\azuretests\";

		public override byte[] GetRegistrationConfirmationTemplate()
		{
			return File.ReadAllBytes(LocalTemplateManager.RegistrationConfirmationSource);			
		}

		public override void SendRegistration(Stream source, Guid registrationId)
		{
			var targetFileName = Path.Combine(LocalTemplateManager.SentEmailFolder, string.Format("Anmeldebestaetigung_{0}.docx", registrationId.ToString()));
			using (var destFileStream = new FileStream(targetFileName, FileMode.CreateNew))
			{
				source.CopyTo(destFileStream);
			}
		}
	}
}
