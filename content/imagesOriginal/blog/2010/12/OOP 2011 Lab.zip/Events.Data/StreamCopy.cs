﻿using System.IO;

namespace Events.Data
{
	public static class StreamCopy
	{
		public static void CopyTo(this Stream source, Stream destination)
		{
			// In C# 4 Stream has a pre-built CopyTo method; for the sake of Azure we have to implement it using an extension method:-(
			var buffer = new byte[4096];
			int length;
			while ((length = source.Read(buffer, 0, buffer.Length)) > 0)
			{
				destination.Write(buffer, 0, length);
			}
		}
	}
}
