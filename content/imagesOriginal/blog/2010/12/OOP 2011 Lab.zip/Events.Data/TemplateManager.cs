﻿using System;
using System.IO;
using Microsoft.WindowsAzure.ServiceRuntime;

namespace Events.Data
{
	public abstract class TemplateManager
	{
		protected TemplateManager()
		{ 
		}

		public abstract byte[] GetRegistrationConfirmationTemplate();

		public abstract void SendRegistration(Stream source, Guid registrationId);

		public virtual void QueueRegistration(Guid registrationId)
		{
			throw new NotImplementedException();
		}

		public static TemplateManager Create()
		{
			return new LocalTemplateManager();
		}
	}
}
