﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Events.Data;

namespace Events.Test
{
	[TestClass]
	public class TestEventRegistration
	{
		[TestInitialize]
		public void TestInitialize()
		{
			using (var context = new HelfenHelfenEntities())
			{
				foreach (var mission in context.Missions)
				{
					context.DeleteObject(mission);
				}

				context.SaveChanges();
			}
		}

		[TestMethod]
		public void TestRegistration()
		{
			using (var context = new HelfenHelfenEntities())
			{
				var eventId = context.DemandDetails.Select(dd => dd.DemandDetailsGUID).First();
				Assert.AreNotEqual(Guid.Empty, context.RegisterAndSaveChanges(eventId, "rainer@software-architects.at"));
			}
		}

		[TestMethod]
		public void TestDuplicateRegistration()
		{
			this.TestRegistration();
			using (var context = new HelfenHelfenEntities())
			{
				var eventId = context.DemandDetails.Select(dd => dd.DemandDetailsGUID).First();
				try
				{
					context.RegisterAndSaveChanges(eventId, "rainer@software-architects.at");
					Assert.Fail("There should have been an exception!");
				}
				catch (Exception ex)
				{
					Assert.IsInstanceOfType(ex, typeof(RegistrationException));
				}
			}
		}

		[TestMethod]
		public void TestInvalidEventId()
		{
			using (var context = new HelfenHelfenEntities())
			{
				try
				{
					context.RegisterAndSaveChanges(Guid.NewGuid(), "rainer@software-architects.at");
					Assert.Fail("There should have been an exception!");
				}
				catch (Exception ex)
				{
					Assert.IsInstanceOfType(ex, typeof(ArgumentException));
				}
			}
		}

		[TestMethod]
		public void TestInvalidEmail()
		{
			using (var context = new HelfenHelfenEntities())
			{
				var eventId = context.DemandDetails.Select(dd => dd.DemandDetailsGUID).First();
				try
				{
					context.RegisterAndSaveChanges(eventId, "test@test.at");
					Assert.Fail("There should have been an exception!");
				}
				catch (Exception ex)
				{
					Assert.IsInstanceOfType(ex, typeof(RegistrationException));
				}
			}
		}
	}
}
