﻿using System;
using System.Web.UI.WebControls;
using Events.Data;
using Microsoft.WindowsAzure.ServiceRuntime;
using System.Configuration;

namespace Events.Web
{
	public partial class Default : System.Web.UI.Page
	{
		private HelfenHelfenEntities context;

		public Default()
		{
			this.context = new HelfenHelfenEntities();
		}

		public override void Dispose()
		{
			this.context.Dispose();
			this.context = null;
			base.Dispose();
		}

		protected void Page_Load(object sender, EventArgs e)
		{
			this.DemandDataSource.ContextCreating += new EventHandler<LinqDataSourceContextEventArgs>(EventDataSource_ContextCreating);
		}

		private void EventDataSource_ContextCreating(object sender, LinqDataSourceContextEventArgs e)
		{
			e.ObjectInstance = this.context;
		}

		protected void OnRegisterClicked(object sender, EventArgs e)
		{
			if (!string.IsNullOrEmpty(this.Email.Text) && !string.IsNullOrEmpty(this.DemandSelection.SelectedValue))
			{
				Response.Redirect(string.Format(
					"RegisterForEvent.aspx?Email={0}&DemandId={1}",
					Server.UrlEncode(this.Email.Text),
					Server.UrlEncode(this.DemandSelection.SelectedValue)));
			}
		}
	}
}