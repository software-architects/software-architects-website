﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.WindowsAzure.ServiceRuntime;

namespace Events.Web
{
    public partial class Events : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            DateLabel.Text = DateTime.Now.ToLongDateString();
            if (RoleEnvironment.IsAvailable)
            {
                IsCloudLabel.Text = "Cloud-Version";
                IsCloudImage.ImageUrl = "~/img/iscloud.jpg";
            }
            else
            {
                IsCloudLabel.Text = "On-Premise Version";
                IsCloudImage.ImageUrl = "~/img/isnotcloud.jpg";
            }
        }
    }
}