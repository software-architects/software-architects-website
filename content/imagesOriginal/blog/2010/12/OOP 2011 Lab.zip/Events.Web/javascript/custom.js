﻿/// <reference path="/javascript/jquery-1.4.1.min.js" />
/// <reference path="/javascript/jquery.timers-1.2.js" />
/// <reference path="/javascript/jquery.syncheight.js" />
/// <reference path="/javascript/jquery.stringformat.js" />

function syncInfos() {
    $('.info').each(function () {
        var left = $('.left .box');
        var right = $('.right .box');

        var short_list = (left.size() < right.size() ? left : right);
        var long_list = (left.size() < right.size() ? right : left);

        var max_boxes = long_list.size();
        var combined = $();
        for (var a = 0; a < max_boxes; a++) {
            if (a < short_list.size() - 1) {
                $(left.get(a)).add(right.get(a)).syncHeight();
            } else {
                combined = combined.add(long_list.get(a));
            }
        }

        if (combined.size() !== 0) {
            var height = 0;
            combined.each(function (index) {
                height += $(this).height();
                height += 25; // adding margin and border
            });
            height -= 25; // subtracting last margin and last border

            $(short_list.get(short_list.size() - 1)).syncHeight({ 'height': height });
        }
    });
}

function syncBars() {
    $('.sidebar, .content').syncHeight();
}

$(window).load(function () {
    syncInfos();
    syncBars();
    $('a.datapager, span.datapager').after(' I ');
});

$(document).ready(function () {
    $('.photo_big img').roundedCorner('topleft');
});