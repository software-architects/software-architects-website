$(document).ready(function () {
    $('.info .box, .photo_big img').roundedCorner('topleft');
    $('.projectlist .pages').roundedCorner('bottomright', {}, 
                { '.roundedcorner_bottomright img': 
                        { border:0, 
                          bottom:'-1px', 
                          margin:0, 
                          position:'absolute', 
                          right:'-1px', 
                          width:'auto' } 
                });
    $('.menu .level1').roundedCorner('topleft', '/img/roundedcorner_topleft_navheader.png' );
    $('.footer .links').roundedCorner('bottomright', '/img/roundedcorner_bottomright_footer.png', 
                                    { '.roundedcorner_bottomright img':
                                        { border:0, 
                                          bottom:'-12px', 
                                          margin:0, 
                                          position:'absolute', 
                                          right:0, 
                                          width:'auto' }
                                    });
});