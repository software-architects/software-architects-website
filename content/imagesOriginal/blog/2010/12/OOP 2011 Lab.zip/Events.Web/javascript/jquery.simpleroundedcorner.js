﻿/**
 * Rounded Corners - jQuery plugin to create rounded corners
 * @requires jQuery v1.0.3
 *
 * Copyright (c) 2007-2009 
 * Stephan Pötschner
 * Licensed under the MIT license:
 * http://www.opensource.org/licenses/mit-license.php
 *
 * Version: 1.0
 *
 * Usage:
 	$(document).ready(function(){
        $('.element').roundedCorner('bottomright');
        $('.element').roundedCorner('topleft', 'img/roundedcorner_topleft_navheader.png' );
	});
 */

(function($) {
	$.fn.roundedCorner = function(position, config, css) {

		var defaults = { 'bottomright': '/img/roundedcorner_bottomright.png',
                         'bottomleft': '/img/roundedcorner_bottomleft.png',
                         'topright': '/img/roundedcorner_topright.png',
                         'topleft': '/img/roundedcorner_topleft.png' };
        if (typeof(config) === 'string') {
            var img = config
            config = {  };
            config[position] = img;
        }
		var options = $.extend(defaults, config);
        
        var css_defaults = { 
                    '.roundedcorner_topleft': { position: 'relative' },
                    '.roundedcorner_topleft img': { border:0, left:0, margin:0, position:'absolute', width:'auto' },
                    '.roundedcorner_bottomright': { position:'relative' },
                    '.roundedcorner_bottomright img': { border:0, bottom:0, margin:0, position:'absolute', right:0, width:'auto' }
                  };
        var css = $.extend(css_defaults, css);
		
 		$(this).each(function() {
            var that = $(this);
            var new_elements = $('<div class="roundedcorner_' + position + '"><img src="' + 
                    options[position] + '" alt="" /></div>');
            if(position.indexOf('top') === 0) {
                that.before(new_elements);
                new_elements = that.prev();
            } else {
                that.after(new_elements);
                new_elements = that.next();
            }
            
            $.each(css, function(index, element) {
                $(index, new_elements.parent()).css(element);
            });
		});
		
		return this;
	};	
})(jQuery);