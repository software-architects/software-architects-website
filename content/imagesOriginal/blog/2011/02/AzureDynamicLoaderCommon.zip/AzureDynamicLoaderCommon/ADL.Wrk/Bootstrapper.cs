﻿using System;
using System.Collections.Concurrent;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using AzureDynamicLoader.Common;

namespace ADL.Wrk
{
    internal class Bootstrapper : MarshalByRefObject
    {
        public bool TryStartup(string assemblyName)
        {
            var account = CloudStorageHelper.GetCloudStorageAccount();
            var logContext = CloudStorageHelper.GetCloudTableClient(account).GetDataServiceContext();

            try
            {
                // Check if assembly name also contains a type name
                var typeName = string.Empty;
                if (assemblyName.Contains(';'))
                {
                    var nameParts = assemblyName.Split(';');
                    assemblyName = nameParts[0];
                    typeName = nameParts[1];
                }

                // Get assembly from blob store
                CloudStorageHelper.WriteLog(logContext, string.Format("Trying to load {0} from blob store", assemblyName));
                var blobClient = CloudStorageHelper.GetCloudBlobClient(account);
                var assemblyBlob = blobClient
                    .GetContainerReference(ConfigurationCache.Current.ContainerName)
                    .GetBlobReference(assemblyName);
                var binaryAssembly = assemblyBlob.DownloadByteArray();

                // Load assembly needed for geo operations (SQL Server Feature Pack)
                Assembly.LoadFile(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Microsoft.SqlServer.Types.dll"));
                Assembly.Load(typeof(IObserver<,>).Assembly.FullName);
                Assembly.Load(typeof(ObservableExtensions).Assembly.FullName);
                Assembly.Load(typeof(EnumerableEx).Assembly.FullName);
                var assembly = Assembly.Load(binaryAssembly);

                // Look for startup type (has to implement IStartup)
                CloudStorageHelper.WriteLog(logContext, "Looking for type in dynamically loaded assembly");
                var startupType = assembly.GetTypes().Where(t => (typeName.Length == 0 || t.Name == typeName) && typeof(IStartup).IsAssignableFrom(t)).FirstOrDefault();
                if (startupType != null)
                {
                    CloudStorageHelper.WriteLog(logContext, string.Format("Found type {0}", startupType.FullName));

                    // Setup logging queue
                    var logQueue = new BlockingCollection<string>(5000);
                    Task.Factory.StartNew(() =>
                        {
                            foreach (var logItem in logQueue.GetConsumingEnumerable())
                            {
                                CloudStorageHelper.WriteLog(logContext, logItem);
                            }
                        });

                    // Create instance of startup type and start Run method in a separate thread
                    var startupObject = Activator.CreateInstance(startupType) as IStartup;
                    CloudStorageHelper.WriteLog(logContext, "Starting dynamically loaded component async.");
                    Task.Factory.StartNew(() =>
                        {
                            try
                            {
                                startupObject.Run(
                                    s => logQueue.Add(s),
                                    ex => logQueue.Add(CloudStorageHelper.GetExceptionText(ex)));
                            }
                            catch (Exception ex)
                            {
                                CloudStorageHelper.WriteLog(CloudStorageHelper.GetCloudTableClient().GetDataServiceContext(), ex);
                            }
                        });
                    CloudStorageHelper.WriteLog(logContext, "Launched dynamically loaded component async.");

                    // Return true to indicate that worker thread has been started successfully
                    return true;
                }
                else
                {
                    CloudStorageHelper.WriteLog(logContext, "Did not find a type that implements IStartup");
                }
            }
            catch (Exception ex)
            {
                CloudStorageHelper.WriteLog(logContext, ex);
            }

            // Return false to indicate that there has been an error
            return false;
        }
    }
}
