﻿using System;
using System.Net;
using System.Threading;
using AzureDynamicLoader.Common;
using Microsoft.WindowsAzure.ServiceRuntime;

namespace ADL.Wrk
{
    public class WorkerRole : RoleEntryPoint
    {
        public override void Run()
        {
            // Local helper variables
            var exeAssembly = typeof(Bootstrapper).Assembly.FullName;
            AppDomain subDomain = null;

            #region Setup storage
            var account = CloudStorageHelper.GetCloudStorageAccount();
            
            var tableClient = CloudStorageHelper.GetCloudTableClient(account);
            tableClient.CreateTableIfNotExist(ConfigurationCache.Current.LogTableName);
            var logContext = tableClient.GetDataServiceContext();

            var queueClient = CloudStorageHelper.GetCloudQueueClient(account);
            var enablerQueue = queueClient.GetQueueReference(ConfigurationCache.Current.EnablerQueueName);
            enablerQueue.CreateIfNotExist();
            var disablerQueue = queueClient.GetQueueReference(ConfigurationCache.Current.DisablerQueueName);
            disablerQueue.CreateIfNotExist();
            #endregion

            while (true)
            {
                try
                {
                    if (subDomain == null)
                    {
                        #region Wait for enabler message
                        var enableMsg = enablerQueue.GetMessage();
                        if (enableMsg != null)
                        {
                            var assemblyName = enableMsg.AsString;
                            enablerQueue.DeleteMessage(enableMsg);

                            subDomain = AppDomain.CreateDomain(
                                "Subdomain",
                                null,
                                new AppDomainSetup() { ApplicationBase = System.Environment.CurrentDirectory });
                            var bootstrapper = (Bootstrapper)subDomain.CreateInstanceAndUnwrap(
                                exeAssembly,
                                typeof(Bootstrapper).FullName);
                            if (!bootstrapper.TryStartup(assemblyName))
                            {
                                AppDomain.Unload(subDomain);
                                subDomain = null;
                            }
                        }
                        #endregion
                    }
                    else
                    {
                        #region Wait for disabler message
                        var disableMsg = disablerQueue.GetMessage();
                        if (disableMsg != null)
                        {
                            disablerQueue.DeleteMessage(disableMsg);
                            try
                            {
                                AppDomain.Unload(subDomain);
                            }
                            finally
                            {
                                subDomain = null;
                            }
                        }
                        #endregion
                    }

                    Thread.Sleep(10000);
                }
                catch (Exception ex)
                {
                    CloudStorageHelper.WriteLog(logContext, ex);
                }
            }
        }

        public override bool OnStart()
        {
            // Set the maximum number of concurrent connections 
            ServicePointManager.DefaultConnectionLimit = 12;

            // For information on handling configuration changes
            // see the MSDN topic at http://go.microsoft.com/fwlink/?LinkId=166357.

            return base.OnStart();
        }
    }
}
