﻿using System;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.ServiceRuntime;
using Microsoft.WindowsAzure.StorageClient;

namespace AzureDynamicLoader.Common
{
    public static class CloudStorageHelper
    {
        public static CloudStorageAccount GetCloudStorageAccount(string configurationName = null)
        {
            CloudStorageAccount.SetConfigurationSettingPublisher(
                (configName, setter) => setter(RoleEnvironment.GetConfigurationSettingValue(configName)));
            return CloudStorageAccount.FromConfigurationSetting(configurationName ?? ConfigurationCache.Current.StorageConnectionConfigName);
        }

        public static CloudQueueClient GetCloudQueueClient(CloudStorageAccount account = null)
        {
            return GetAccount(account).CreateCloudQueueClient();
        }

        public static CloudBlobClient GetCloudBlobClient(CloudStorageAccount account = null)
        {
            return GetAccount(account).CreateCloudBlobClient();
        }

        public static CloudTableClient GetCloudTableClient(CloudStorageAccount account = null)
        {
            return GetAccount(account).CreateCloudTableClient();
        }

        public static void WriteLog(TableServiceContext context, string log)
        {
            if (context == null)
            {
                context = GetCloudTableClient().GetDataServiceContext();
            }

            context.AddObject(
                ConfigurationCache.Current.LogTableName,
                new LogTableStorageRow() { LogText = log });
            context.SaveChanges();
        }

        public static void WriteLog(TableServiceContext context, Exception ex)
        {
            WriteLog(context, GetExceptionText(ex));
        }

        public static string GetExceptionText(Exception ex)
        {
            return string.Format(
                "Exception Message: {0}\nCall Stack: {1}\nInner Exception Message: {2}\nInner-inner Exception Message:{3}",
                ex.Message,
                ex.StackTrace,
                (ex.InnerException != null ? ex.InnerException.Message : "n.a."),
                (ex.InnerException != null && ex.InnerException.InnerException != null ? ex.InnerException.InnerException.Message : "n.a."));
        }

        private static CloudStorageAccount GetAccount(CloudStorageAccount account)
        {
            if (account == null)
            {
                account = GetCloudStorageAccount();
            }

            return account;
        }
    }
}
