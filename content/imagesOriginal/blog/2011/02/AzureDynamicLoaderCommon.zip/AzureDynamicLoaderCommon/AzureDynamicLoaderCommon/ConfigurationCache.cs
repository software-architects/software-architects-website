﻿using Microsoft.WindowsAzure.ServiceRuntime;

namespace AzureDynamicLoader.Common
{
    public class ConfigurationCache
    {
        static ConfigurationCache()
        {
            Current = new ConfigurationCache();
        }

        private ConfigurationCache()
        {
            this.StorageConnectionConfigName = "AzureStorage";
            this.AzureStorageConnectionString = RoleEnvironment.GetConfigurationSettingValue(
                this.StorageConnectionConfigName);
            this.ContainerName = RoleEnvironment.GetConfigurationSettingValue("ContainerName");
            this.LogTableName = RoleEnvironment.GetConfigurationSettingValue("LogTableName");
            this.SqlServerConnectionString = RoleEnvironment.GetConfigurationSettingValue("SqlConnectionString");
            this.TemporaryFilesPath = RoleEnvironment.GetLocalResource("TemporaryFiles").RootPath;
            this.EnablerQueueName = RoleEnvironment.GetConfigurationSettingValue("EnablerQueueName");
            this.DisablerQueueName = RoleEnvironment.GetConfigurationSettingValue("DisablerQueueName");
        }

        public static ConfigurationCache Current { get; private set; }

        public string StorageConnectionConfigName { get; private set; }
        public string AzureStorageConnectionString { get; private set; }
        public string ContainerName { get; private set; }
        public string LogTableName { get; private set; }
        public string SqlServerConnectionString { get; private set; }
        public string TemporaryFilesPath { get; private set; }
        public string EnablerQueueName { get; private set; }
        public string DisablerQueueName { get; private set; }
    }
}
