﻿namespace AzureDynamicLoader.Common
{
    using System;

    public interface IStartup
    {
        void Run(Action<string> logWriter, Action<Exception> exceptionWriter);
    }
}