﻿using System;
using System.Globalization;
using Microsoft.WindowsAzure.StorageClient;

namespace AzureDynamicLoader.Common
{
    public class LogTableStorageRow : TableServiceEntity
    {
        public LogTableStorageRow()
        {
            this.PartitionKey = "Log";
            this.RowKey = string.Format("{0}_{1}",
                (DateTime.MaxValue - TimeSpan.FromTicks(DateTime.Now.Ticks)).ToString(DateTimeFormatInfo.InvariantInfo.SortableDateTimePattern),
                Guid.NewGuid().ToString());
            this.Timestamp = this.LogTime = DateTime.Now;
        }

        public string LogText { get; set; }
        public DateTime LogTime { get; set; }
    }
}
