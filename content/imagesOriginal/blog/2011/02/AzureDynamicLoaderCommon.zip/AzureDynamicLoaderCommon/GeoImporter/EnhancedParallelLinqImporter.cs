﻿using System;
using System.Collections.Concurrent;
using System.Data.SqlTypes;
using System.Linq;
using System.Threading;
using System.Xml.Linq;
using AzureDynamicLoader.Common;
using GeoImporter;
using Microsoft.SqlServer.Types;

namespace LinqImporter
{
    public class EnhancedParallelLinqImporter : ImporterBase, IStartup
    {
        public void Run(Action<string> logWriter, Action<Exception> exceptionWriter)
        {
            try
            {
                this.StartStatisticsTicker(logWriter);

                var nodes = new ConcurrentDictionary<string, string>();
                var doc = XDocument.Load(@"https://loadtesting.blob.core.windows.net/osm/berlin.xml");

                doc.Root.Descendants("node")
                    .Select(n => new Tuple<string, string>(n.Attribute("id").Value, string.Format("{0} {1}", n.Attribute("lat").Value, n.Attribute("lon").Value)))
                    .AsParallel()
                    .ForAll(n =>
                        {
                            nodes.AddOrUpdate(n.Item1, n.Item2, (id, p) => p);
                            lock (this.statisticsLockObject)
                            {
                                this.nodesPerSecond++;
                            }
                        });


                using (var context = new GeoWriterContext())
                {
                    doc.Descendants("way")
                    .AsParallel()
                    .Where(w => w.Descendants("tag").Where(t => t.Attribute("k").Value == "highway").Count() > 0)
                    .Select(w =>
                        new
                        {
                            WayId = w.Attribute("id").Value,
                            WayType = w.Descendants("tag").Where(t => t.Attribute("k").Value == "highway").First().Attribute("v").Value,
                            Linestring = "LINESTRING(" + w.Descendants("nd")
                                .Aggregate<XElement, string>(string.Empty, (agg, node) =>
                                    agg
                                    + (agg.Length != 0 ? "," : string.Empty)
                                    + nodes[node.Attribute("ref").Value]) + ")",
                            StartingNodeId = w.Descendants("nd").First().Attribute("ref").Value,
                            EndNodeId = w.Descendants("nd").Last().Attribute("ref").Value
                        })
                    .ForAll(row =>
                    {
                        #region Write row to database
                        try
                        {
                            context.InsertHighway(
                                Int32.Parse(row.WayId),
                                SqlGeography.STLineFromText(new SqlChars(new SqlString(row.Linestring)), 4326),
                                row.WayType,
                                Int32.Parse(row.StartingNodeId),
                                Int32.Parse(row.EndNodeId));

                            lock (this.statisticsLockObject)
                            {
                                this.highwaysPerSecond++;
                            }
                        }
                        catch (Exception ex)
                        {
                            logWriter(string.Format("Could not write way {0}: {1}", row.WayId, row.Linestring));
                            exceptionWriter(ex);
                        }
                        #endregion
                    });
                }

                Thread.Sleep(2000);
                this.StopStatisticsTicker();
            }
            catch (Exception ex)
            {
                exceptionWriter(ex);
            }
        }
    }
}
