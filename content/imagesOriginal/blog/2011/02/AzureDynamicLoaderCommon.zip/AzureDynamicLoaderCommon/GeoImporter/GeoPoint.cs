﻿using System;
using Microsoft.SqlServer.Types;

namespace GeoHelper
{
    internal struct GeoPoint : IEquatable<GeoPoint>
    {
        public GeoPoint(double lat, double lng)
            : this()
        {
            this.Lat = lat;
            this.Lng = lng;
        }

        public double Lat { get; private set; }
        public double Lng { get; private set; }

        public bool Equals(GeoPoint other)
        {
            return this.Lat == other.Lat && this.Lng == other.Lng;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return base.Equals(obj);
            }

            if (!(obj is GeoPoint))
            {
                throw new InvalidCastException("Argument is not a GeoPoint obj.");
            }

            return this.Equals((GeoPoint)obj);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                int hash = 17;
                hash = hash * 23 + this.Lat.GetHashCode();
                hash = hash * 23 + this.Lng.GetHashCode();
                return hash;
            }
        }

        public static bool operator ==(GeoPoint x, GeoPoint y)
        {
            return x.Equals(y);
        }

        public static bool operator !=(GeoPoint x, GeoPoint y)
        {
            return !x.Equals(y);
        }

        public SqlGeography ToSqlGeography()
        {
            return SqlGeography.Point(this.Lat, this.Lng, 4326);
        }
    }
}
