﻿using System;
using System.Data;
using System.Data.SqlClient;
using AzureDynamicLoader.Common;
using Microsoft.SqlServer.Types;

namespace GeoImporter
{
    public class GeoWriterContext : IDisposable
    {
        private bool disposed;
        private SqlConnection connection;
        private SqlCommand highwayInsertCommand;
        private object lockObject = new object();

        public GeoWriterContext()
        {
            this.connection = new SqlConnection(ConfigurationCache.Current.SqlServerConnectionString);
            this.connection.Open();

            this.highwayInsertCommand = connection.CreateCommand();
            this.highwayInsertCommand.CommandText = @"INSERT INTO Highway ( HighwayID, HighwayGeo, HighwayType, StartingNodeID, EndNodeID ) 
                VALUES ( @HighwayID, @HighwayGeo, @HighwayType, @StartingNodeID, @EndNodeID )";
            this.highwayInsertCommand.Parameters.Add("@HighwayID", SqlDbType.Int);
            this.highwayInsertCommand.Parameters.Add("@HighwayGeo", SqlDbType.Udt).UdtTypeName = "geography";
            this.highwayInsertCommand.Parameters.Add("@HighwayType", SqlDbType.NVarChar, 100);
            this.highwayInsertCommand.Parameters.Add("@StartingNodeID", SqlDbType.Int);
            this.highwayInsertCommand.Parameters.Add("@EndNodeID", SqlDbType.Int);
        }

        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        public void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    this.highwayInsertCommand.Dispose();
                    this.connection.Dispose();
                }

                this.disposed = true;
            }
        }

        ~GeoWriterContext()
        {
            this.Dispose(false);
        }
        
        public void InsertHighway(int highwayId, SqlGeography highwayGeo, string highwayType, int startingNodeId, int endNodeId)
        {
            lock (this.lockObject)
            {
                this.highwayInsertCommand.Parameters[0].Value = highwayId;
                this.highwayInsertCommand.Parameters[1].Value = highwayGeo;
                this.highwayInsertCommand.Parameters[2].Value = highwayType;
                this.highwayInsertCommand.Parameters[3].Value = startingNodeId;
                this.highwayInsertCommand.Parameters[4].Value = endNodeId;
                this.highwayInsertCommand.ExecuteNonQuery();
            }
        }
    }
}
