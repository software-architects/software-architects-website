﻿using System;
using System.Timers;

namespace GeoImporter
{
    public abstract class ImporterBase
    {
        protected object statisticsLockObject = new object();
        protected int nodesPerSecond = 0;
        protected int highwaysPerSecond = 0;
        protected int tilesPerSecond = 0;

        private Timer statisticsTimer;
        private object statisticsTimerLockObject = new object();

        protected void StartStatisticsTicker(Action<string> logWriter)
        {
            lock (this.statisticsTimerLockObject)
            {
                if (this.statisticsTimer == null)
                {
                    this.statisticsTimer = new Timer(1000) { AutoReset = true };
                    this.statisticsTimer.Elapsed += new ElapsedEventHandler((s, e) =>
                    {
                        int currentNodesPerSecond = 0, currentHighwaysPerSecond = 0, currentTilesPerSecond = 0;
                        lock (statisticsLockObject)
                        {
                            // Copy statistics value to keep lock time as short as possible
                            currentNodesPerSecond = nodesPerSecond;
                            currentHighwaysPerSecond = highwaysPerSecond;
                            currentTilesPerSecond = tilesPerSecond;
                            nodesPerSecond = highwaysPerSecond = tilesPerSecond = 0;
                        }

                        logWriter(string.Format("Nodes/s;Highways/s;Tiles/s: {0}/{1}/{2}",
                            currentNodesPerSecond, currentHighwaysPerSecond, tilesPerSecond));
                    });
                    this.statisticsTimer.Start();
                }
            }
        }

        protected void StopStatisticsTicker()
        {
            lock (this.statisticsTimerLockObject)
            {
                if (this.statisticsTimer != null)
                {
                    this.statisticsTimer.Stop();
                    this.statisticsTimer = null;
                }
            }
        }
    }
}
