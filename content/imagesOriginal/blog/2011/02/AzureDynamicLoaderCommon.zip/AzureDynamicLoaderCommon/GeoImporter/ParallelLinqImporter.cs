﻿using System;
using System.Data.SqlTypes;
using System.Linq;
using System.Xml.Linq;
using AzureDynamicLoader.Common;
using GeoImporter;
using Microsoft.SqlServer.Types;

namespace LinqImporter
{
    public class ParallelLinqImporter : ImporterBase, IStartup
    {
        public void Run(Action<string> logWriter, Action<Exception> exceptionWriter)
        {
            this.StartStatisticsTicker(logWriter);

            using (var context = new GeoWriterContext())
            {
                XElement tmpNode;
                XDocument doc;
                (doc = XDocument.Load(@"https://loadtesting.blob.core.windows.net/osm/berlin.xml"))
                    .Descendants("way")
                    .AsParallel()
                    .Where(w => w.Descendants("tag").Where(t => t.Attribute("k").Value == "highway").Count() > 0)
                    .Select(w =>
                        new
                        {
                            WayId = w.Attribute("id").Value,
                            WayType = w.Descendants("tag").Where(t => t.Attribute("k").Value == "highway").First().Attribute("v").Value,
                            Linestring = "LINESTRING(" + w.Descendants("nd")
                                .Aggregate<XElement, string>(string.Empty, (agg, node) =>
                                    agg
                                    + (agg.Length != 0 ? "," : string.Empty)
                                    + (tmpNode = doc.Root.Descendants("node")
                                        .AsParallel()
                                        .Where(n => n.Attribute("id").Value == node.Attribute("ref").Value).First())
                                        .Attribute("lat").Value
                                    + " " + tmpNode.Attribute("lon").Value) + ")",
                            StartingNodeId = w.Descendants("nd").First().Attribute("ref").Value,
                            EndNodeId = w.Descendants("nd").Last().Attribute("ref").Value
                        })
                    .ForAll(row =>
                    {
                        #region Write row to database
                        try
                        {
                            context.InsertHighway(
                                Int32.Parse(row.WayId),
                                SqlGeography.STLineFromText(new SqlChars(new SqlString(row.Linestring)), 4326),
                                row.WayType,
                                Int32.Parse(row.StartingNodeId),
                                Int32.Parse(row.EndNodeId));

                            lock (this.statisticsLockObject)
                            {
                                this.highwaysPerSecond++;
                            }
                        }
                        catch (Exception ex)
                        {
                            exceptionWriter(ex);
                        }
                        #endregion
                    });
            }

            this.StopStatisticsTicker();
        }
    }
}
