﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Text;
using System.Xml;
using AzureDynamicLoader.Common;
using GeoImporter;
using Microsoft.SqlServer.Types;
using System.Threading;

namespace SimpleGeoImporter
{
    public class SimpleImporter : ImporterBase, IStartup
    {
        public void Run(Action<string> logWriter, Action<Exception> exceptionWriter)
        {
            try
            {
                this.StartStatisticsTicker(logWriter);

                var nodes = new Dictionary<string, string>();
                using (var context = new GeoWriterContext())
                {
                    using (var reader = XmlReader.Create(@"https://loadtesting.blob.core.windows.net/osm/berlin.xml"))
                    {
                        var isInWay = false;
                        var highwayType = string.Empty;
                        string motorwayId = string.Empty, startingNodeId = string.Empty, endNodeId = string.Empty;
                        var motorwayNodes = new List<string>();

                        while (reader.Read())
                        {
                            if (reader.NodeType == XmlNodeType.Element)
                            {
                                switch (reader.Name)
                                {
                                    case "node":
                                        nodes.Add(reader.GetAttribute("id"),
                                            string.Format("{0} {1}", reader.GetAttribute("lat"), reader.GetAttribute("lon")));
                                        lock (statisticsLockObject)
                                        {
                                            nodesPerSecond++;
                                        }

                                        break;

                                    case "way":
                                        motorwayId = reader.GetAttribute("id");
                                        isInWay = true;
                                        break;

                                    case "nd":
                                        var refNodeId = reader.GetAttribute("ref");
                                        if (isInWay && nodes.ContainsKey(refNodeId))
                                        {
                                            endNodeId = refNodeId;
                                            if (startingNodeId.Length == 0)
                                            {
                                                startingNodeId = refNodeId;
                                            }

                                            motorwayNodes.Add(nodes[refNodeId]);
                                        }

                                        break;

                                    case "tag":
                                        if (reader.GetAttribute("k") == "highway")
                                        {
                                            highwayType = reader.GetAttribute("v");
                                        }

                                        break;

                                    default:
                                        break;
                                }
                            }
                            else if (reader.NodeType == XmlNodeType.EndElement)
                            {
                                if (reader.Name == "way")
                                {
                                    if (isInWay && !string.IsNullOrEmpty(highwayType) && motorwayNodes.Count > 1)
                                    {
                                        bool isFirstNode = true;
                                        var lineStringBuilder = new StringBuilder("LINESTRING(");
                                        foreach (var node in motorwayNodes)
                                        {
                                            if (!isFirstNode)
                                            {
                                                lineStringBuilder.Append(',');
                                            }
                                            else
                                            {
                                                isFirstNode = false;
                                            }

                                            lineStringBuilder.Append(node);
                                        }

                                        lineStringBuilder.Append(')');

                                        #region Write row to database
                                        try
                                        {
                                            context.InsertHighway(
                                                Int32.Parse(motorwayId),
                                                SqlGeography.STLineFromText(new SqlChars(new SqlString(lineStringBuilder.ToString())), 4326),
                                                highwayType,
                                                Int32.Parse(startingNodeId),
                                                Int32.Parse(endNodeId));

                                            lock (this.statisticsLockObject)
                                            {
                                                this.highwaysPerSecond++;
                                            }
                                        }
                                        catch (Exception ex)
                                        {
                                            logWriter(string.Format("Could not write way {0}: {1}", motorwayId, lineStringBuilder.ToString()));
                                            exceptionWriter(ex);
                                        }
                                        #endregion
                                    }

                                    motorwayNodes.Clear();
                                    isInWay = false;
                                    highwayType = string.Empty;
                                    startingNodeId = endNodeId = string.Empty;
                                }
                            }
                        }
                    }

                }

                Thread.Sleep(2);
                this.StopStatisticsTicker();
            }
            catch (Exception ex)
            {
                exceptionWriter(ex);
            }
        }
    }
}
