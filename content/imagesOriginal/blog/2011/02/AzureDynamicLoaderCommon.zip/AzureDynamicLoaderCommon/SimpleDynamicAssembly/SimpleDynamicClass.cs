﻿using System;
using AzureDynamicLoader.Common;
using System.Threading;

namespace SimpleDynamicAssembly
{
    public class SimpleDynamicClass : IStartup
    {
        public void Run(Action<string> logWriter, Action<Exception> exceptionWriter)
        {
            Thread.Sleep(10000);
            logWriter("Hello World!");
        }
    }
}
