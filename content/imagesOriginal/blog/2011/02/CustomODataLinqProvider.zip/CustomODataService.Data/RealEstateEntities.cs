﻿using System.Configuration;
using Microsoft.WindowsAzure.ServiceRuntime;

namespace CustomODataService.Data
{
    public partial class RealEstateEntities
    {
        /// <summary>
        /// Factory method that should be used to create instances of the RealEstateEntities class
        /// </summary>
        public static RealEstateEntities Create()
        {
            var context = new RealEstateEntities(GetRealEstateConnectionString());
            context.CommandTimeout = 300;
            return context;
        }

        internal static string GetRealEstateConnectionString()
        {
            if (RoleEnvironment.IsAvailable)
            {
                return string.Format(
                    RoleEnvironment.GetConfigurationSettingValue("EntityFrameworkDatabaseConnection"),
                    RoleEnvironment.GetConfigurationSettingValue("DatabaseConnection"));
            }
            else
            {
                return string.Format(
                    ConfigurationManager.AppSettings["EntityFrameworkDatabaseConnection"],
                    ConfigurationManager.AppSettings["DatabaseConnection"]);
            }
        }
    }
}
