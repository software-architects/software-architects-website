﻿using System;
using System.Data.Services;
using System.Data.Services.Providers;
using System.Reflection;
using System.Data.Objects.DataClasses;
using System.Linq;

namespace CustomODataService.CustomDataServiceBase
{
    /// <summary>
    /// Base class for implementing a custom OData service
    /// </summary>
    /// <typeparam name="T">Type that defines the data service.</typeparam>
    public abstract class CustomDataService<T> : DataService<T>, IServiceProvider
    {
        private IDataServiceMetadataProvider metadata;
        private IDataServiceQueryProvider query;

        public CustomDataService()
        {
            metadata = GetMetadataProvider(typeof(T));
            query = GetQueryProvider(metadata);
        }

        /// <summary>
        /// Called by the WCF data service framework to get underlying providers
        /// </summary>
        public object GetService(Type serviceType)
        {
            if (serviceType == typeof(IDataServiceMetadataProvider))
            {
                return metadata;
            }
            else if (serviceType == typeof(IDataServiceQueryProvider))
            {
                return query;
            }
             
            return null;
        }

        /// <summary>
        /// Derived classes have to implement this method and return the necessary metadata
        /// </summary>
        public abstract IDataServiceMetadataProvider GetMetadataProvider(Type dataSourceType);

        /// <summary>
        /// Derived classes have to implement this method and return the underlying query provider
        /// </summary>
        public abstract IDataServiceQueryProvider GetQueryProvider(IDataServiceMetadataProvider metadata);

        /// <summary>
        /// Helper function that generates service metadata for entity framework entities based on reflection
        /// </summary>
        /// <typeparam name="TEntity">Entity framework entity type</typeparam>
        /// <param name="namespaceName">Name of the namespace to which the entity type should be assigned</param>
        public static IDataServiceMetadataProvider BuildMetadataForEntityFrameworkEntity<TEntity>(string namespaceName)
        {
            var productType = new ResourceType(
                typeof(TEntity),
                ResourceTypeKind.EntityType,
                null, // BaseType 
                namespaceName, // Namespace 
                typeof(TEntity).Name,
                false // Abstract? 
            );

            // use reflection to get all properties (except entity framework specific ones)
            typeof(TEntity)
                .GetProperties(BindingFlags.Public | BindingFlags.Instance)
                .Where(pi => pi.DeclaringType == typeof(TEntity))
                .Select(pi => new ResourceProperty(
                    pi.Name,
                    (Attribute.GetCustomAttributes(pi).OfType<EdmScalarPropertyAttribute>().Where(ea => ea.EntityKeyProperty).Count() == 1)
                        ? ResourcePropertyKind.Primitive | ResourcePropertyKind.Key
                        : ResourcePropertyKind.Primitive,
                    ResourceType.GetPrimitiveResourceType(pi.PropertyType)))
                .ToList()
                .ForEach(prop => productType.AddProperty(prop));

            var metadata = new CustomDataServiceMetadataProvider();
            metadata.AddResourceType(productType);
            metadata.AddResourceSet(new ResourceSet(typeof(TEntity).Name, productType));
            return metadata;
        }
    }
}