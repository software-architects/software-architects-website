﻿using System.Data.Services.Providers;
using System.Linq;

namespace CustomODataService.CustomDataServiceBase
{
    /// <summary>
    /// Acts as the base class for data service contexts used for a custom data service
    /// </summary>
    public abstract class CustomDataServiceContext
    {
        /// <summary>
        /// Creates a queryable for the specified resource set
        /// </summary>
        /// <param name="set">Resource set for which the queryable should be created</param>
        public abstract IQueryable GetQueryable(ResourceSet set);
    }
}