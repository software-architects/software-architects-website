﻿using System;
using System.Collections.Generic;
using System.Data.Services.Providers;
using System.Linq;

namespace CustomODataService.CustomDataServiceBase
{
    public class CustomDataServiceProvider<T> : IDataServiceQueryProvider where T : CustomDataServiceContext
    {
        private T currentDataSource;
        private IDataServiceMetadataProvider metadata;

        public CustomDataServiceProvider(IDataServiceMetadataProvider metadata)
        {
            this.metadata = metadata;
        }

        public object CurrentDataSource
        {
            get { return currentDataSource; }
            set { currentDataSource = value as T; }
        }

        public IQueryable GetQueryRootForResourceSet(ResourceSet resourceSet)
        {
            return currentDataSource.GetQueryable(resourceSet);
        }

        public ResourceType GetResourceType(object target)
        {
            var type = target.GetType();
            return metadata.Types.Single(t => t.InstanceType == type);
        }

        public bool IsNullPropagationRequired
        {
            get { return true; }
        }

        public object GetOpenPropertyValue(object target, string propertyName)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<KeyValuePair<string, object>> GetOpenPropertyValues(object target)
        {
            throw new NotImplementedException();
        }

        public object GetPropertyValue(object target, ResourceProperty resourceProperty)
        {
            throw new NotImplementedException();
        }

        public object InvokeServiceOperation(ServiceOperation serviceOperation, object[] parameters)
        {
            throw new NotImplementedException();
        }
    }
}