﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading;

namespace DemoDataGenerator
{
    public class DemoDataManager
    {
        public PartitionConnectionInformation CompleteDatabasePartition { get; private set; }
        public PartitionConnectionInformation[] PartitionInformations { get; private set; }

        public DemoDataManager(
            string connectionStringCompleteDatabase,
            PartitionConnectionInformation[] partitionInformations)
        {
            if (string.IsNullOrWhiteSpace(connectionStringCompleteDatabase))
            {
                throw new ArgumentNullException("connectionStringCompleteDatabase");
            }

            if (partitionInformations == null)
            {
                throw new ArgumentNullException("partitionInformations");
            }

            this.CompleteDatabasePartition = new PartitionConnectionInformation(
                connectionStringCompleteDatabase);
            this.PartitionInformations = partitionInformations;
        }

        public static DemoDataManager CreateDefaultManager(bool local)
        {
            if (local)
            {
                return new DemoDataManager(
                    ConfigurationManager.AppSettings["LocalCompleteDatabaseConnectionString"],
                    new[]
                    {
                        new PartitionConnectionInformation(string.Format(
                            ConfigurationManager.AppSettings["LocalPartitionConnectionStringTemplate"],
                            1), "Wels"),
                        new PartitionConnectionInformation(string.Format(
                            ConfigurationManager.AppSettings["LocalPartitionConnectionStringTemplate"],
                            2), "Wien")
                    });
            }
            else
            {
                return new DemoDataManager(
                    ConfigurationManager.AppSettings["CloudCompleteDatabaseConnectionString"],
                    Enumerable.Range(1, 10)
                        .Select(i =>
                            new PartitionConnectionInformation(string.Format(
                                ConfigurationManager.AppSettings["CloudPartitionConnectionStringTemplate"],
                                i), clusterFilter: i))
                        .ToArray());
            }
        }

        public delegate void LogDelegate(LogRow entry);

        public void ClearAllDatabases(LogDelegate logger = null)
        {
            this.ExecuteForAllPartitions((cmd, connectionInfo) =>
                {
                    DateTime startTime = DateTime.Now;
                    cmd.CommandText = DemoDataScriptProvider.CreateTargetTableScript;
                    cmd.ExecuteNonQuery();
                    if (logger != null)
                    {
                        logger(new LogRow()
                        {
                            ActionDescription = "Cleared",
                            City = string.Empty,
                            ManagedProcessID = Thread.CurrentThread.ManagedThreadId,
                            Partition = connectionInfo,
                            Duration = DateTime.Now - startTime
                        });
                    }
                });
        }

        public void LoadAllDatabases(LogDelegate logger = null)
        {
            this.ExecuteForAllPartitions((cmd, connectionInfo) =>
            {
                var cities = new List<string>(50);
                #region Get all cities
                var statement = new StringBuilder();
                statement.AppendFormat("{0}\n{1}",
                    DemoDataScriptProvider.CreateTempSourceTablesScript,
                    DemoDataScriptProvider.AllCitiesStatement);
                var hasWhere = false;
                if (!string.IsNullOrEmpty(connectionInfo.CityFilter))
                {
                    hasWhere = true;
                    statement.Append(" where City = @CityFilter");
                    cmd.Parameters.AddWithValue("@CityFilter", connectionInfo.CityFilter);
                }

                if (connectionInfo.ClusterFilter.HasValue)
                {
                    cmd.Parameters.AddWithValue("@Cluster", connectionInfo.ClusterFilter.Value);
                    if (hasWhere)
                    {
                        statement.Append(" and Cluster = @Cluster");
                    }
                    else
                    {
                        statement.Append(" where Cluster = @Cluster");
                    }
                }

                cmd.CommandText = statement.ToString();
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        cities.Add(reader.GetString(0));
                    }
                }

                cmd.Parameters.Clear();
                #endregion

                #region Fill cities
                cmd.CommandText = string.Format("{0}\n{1}\nwhere c.City = @CityFilter",
                    DemoDataScriptProvider.CreateTempSourceTablesScript,
                    DemoDataScriptProvider.InsertDemoDataStatement);
                cmd.Parameters.Add("@CityFilter", SqlDbType.NVarChar, 50);
                cmd.CommandTimeout = 15 * 60; // 15 minutes
                cmd.Prepare();
                cities.ForEach(city =>
                    {
                        DateTime startTime = DateTime.Now;
                        cmd.Parameters[0].Value = city;
                        cmd.ExecuteNonQuery();
                        if (logger != null)
                        {
                            logger(new LogRow()
                            {
                                ActionDescription = "Loaded",
                                City = city,
                                ManagedProcessID = Thread.CurrentThread.ManagedThreadId,
                                Partition = connectionInfo,
                                Duration = DateTime.Now - startTime
                            });
                        }
                    });
                #endregion
            });
        }

        public void ExecuteForAllPartitions(Action<SqlCommand, PartitionConnectionInformation> actionToExecute)
        {
            new[] { this.CompleteDatabasePartition }
                .Concat(this.PartitionInformations)
                .ToArray()
                .AsParallel()
                .WithDegreeOfParallelism(this.PartitionInformations.Length + 1)
                .ForAll(connectionInfo =>
                {
                    using (var conn = new SqlConnection(connectionInfo.PartitionConnectionString))
                    {
                        conn.Open();
                        using (var cmd = conn.CreateCommand())
                        {
                            actionToExecute(cmd, connectionInfo);
                        }
                    }
                });
        }
    }
}
