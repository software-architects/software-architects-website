﻿namespace DemoDataGenerator
{
    public static class DemoDataScriptProvider
    {
        #region CreateTargetTableScript
        public const string CreateTargetTableScript = @"
            set nocount on;

            if exists ( select 1 from information_schema.tables where table_name = 'RealEstate' )
                drop table RealEstate; 

            if exists ( select 1 from information_schema.tables where table_name = 'RealEstates' )
                drop table RealEstates; 

            create table RealEstate (
	            [RealEstateID] int primary key
               ,[DateOfFirstOffering] datetime
               ,[TypeOfRealEstate] nvarchar(50)
               ,[TypeOfOffer] nvarchar(50)
               ,[Description] nvarchar(512)
               ,[SizeOfParcel] decimal(8,2)
               ,[SizeOfLivingSpace] decimal(8,2)
               ,[SizeOfBuildingArea] decimal(8,2)
               ,[SizeOfLivingRoom] decimal(8,2)
               ,[SizeOfSleepingRoom] decimal(8,2)
               ,[SizeOfGarden] decimal(8,2)
               ,[SizeOfCellar] decimal(8,2)
               ,[HasBalcony] bit
               ,[HasTerrace] bit
               ,[HasElevator] bit
               ,[HasImage] bit
               ,[IsFirstTimeUse] bit
               ,[ViewDirection] nvarchar(20)
               ,[NumberOfParkingLotsOutdoor] tinyint
               ,[NumberOfParkingLotsRoofed] tinyint
               ,[NumberOfParkingLotsGarage] tinyint
               ,[NumberOfBathrooms] tinyint
               ,[NumberOfStarsEstateAgent] tinyint
               ,[NumberOfRooms] smallint
               ,[HeatingType] nvarchar(50)
               ,[EarliestAvailable] date
               ,[MonthlyCost] decimal(8,2)
               ,[PurchasingPrice] decimal(10,2)
               ,[Location] nvarchar(128)
               );";
        #endregion

        #region CreateTempSourceTablesScript
        public const string CreateTempSourceTablesScript = @"
            set nocount on;

            declare @Attributes as table ( Attribute nvarchar(50), ID int );
            insert into @Attributes values ( 'schön', 1 );
            insert into @Attributes values ( 'großzügig', 2 );
            insert into @Attributes values ( 'hübsch', 3 );
            insert into @Attributes values ( 'reizend', 4 );
            insert into @Attributes values ( 'liebevoll', 5 );
            insert into @Attributes values ( 'herrlich', 6 );
            insert into @Attributes values ( 'einwandfrei', 7 );

            declare @RealEstateType as table ( TypeDescription nvarchar(50), TypeOfRealEstate nvarchar(50), AttributeEnd nvarchar(5), ID int );
            insert into @RealEstateType values ( 'Wohnung', 'Apartment', 'e', 100 );
            insert into @RealEstateType values ( 'Grundstück', 'Land', 'es', 200 );
            insert into @RealEstateType values ( 'Haus', 'House', 'es', 300 );
            insert into @RealEstateType values ( 'Büro', 'Office', 'es', 400 );
            insert into @RealEstateType values ( 'Residenz', 'House', 'e', 500 );
            insert into @RealEstateType values ( 'Villa', 'House', 'e', 600 );
            insert into @RealEstateType values ( 'Domizil', 'Apartment', 'es', 700 );
            insert into @RealEstateType values ( 'Gewerbeobjekt', 'Office', 'es', 800 );
            insert into @RealEstateType values ( 'Einliegerwohnung', 'Apartment', 'e', 900 );

            declare @Maximizer as table ( Maximizer nvarchar(50), ID int );
            insert into @Maximizer values ( 'sehr', 1000 );
            insert into @Maximizer values ( 'unglaublich', 2000 );
            insert into @Maximizer values ( 'phantastisch', 3000 );
            insert into @Maximizer values ( 'besonders', 4000 );
            insert into @Maximizer values ( 'tip-top', 5000 );
            insert into @Maximizer values ( 'ziemlich', 6000 );
            insert into @Maximizer values ( 'relativ', 7000 ); 

            declare @DetailedDescription as table ( Description nvarchar(50), DescriptionEnd nvarchar(5), ID int );
            insert into @DetailedDescription values ( 'eingerichtet', '', 10000 );
            insert into @DetailedDescription values ( 'Aussicht', 'e', 20000 );
            insert into @DetailedDescription values ( 'Lage', 'e', 30000 );
            insert into @DetailedDescription values ( 'hergerichtet', '', 40000 );
            insert into @DetailedDescription values ( 'Ausblick', 'er', 50000 );
            insert into @DetailedDescription values ( 'gelegen', '', 60000 ); 

            declare @City as table ( City nvarchar(50), ID int, Cluster int );
            insert into @City values ( 'Wien', 100000, 1 );
            insert into @City values ( 'Steyr', 200000, 1 );
            insert into @City values ( 'Graz', 300000, 1 );
            insert into @City values ( 'Wels', 400000, 2 );
            insert into @City values ( 'Salzburg', 500000, 2 );
            insert into @City values ( 'Innsbruck', 600000, 2 );
            insert into @City values ( 'Klagenfurt', 700000, 3 );
            insert into @City values ( 'Villach', 800000, 3 );
            insert into @City values ( 'St. Anton', 900000, 3 ); 
            insert into @City values ( 'St. Pölten', 1000000, 4 );
            insert into @City values ( 'Melk', 1100000, 4 );
            insert into @City values ( 'Freistadt', 1200000, 4 );
            insert into @City values ( 'Bregenz', 1300000, 5 );
            insert into @City values ( 'Eisenstadt', 1400000, 5 );
            insert into @City values ( 'Traun', 1500000, 5 );
            insert into @City values ( 'Kitzbühel', 1600000, 6 );
            insert into @City values ( 'Schwechat', 1700000, 6 );
            insert into @City values ( 'Wagram', 1800000, 6 );
            insert into @City values ( 'Pasching', 1900000, 7 );
            insert into @City values ( 'Oberhausen', 2000000, 7 );
            insert into @City values ( 'Poising', 2100000, 7 );
            insert into @City values ( 'Kirchdorf', 2200000, 8 );
            insert into @City values ( 'Stinaz', 2300000, 8 );
            insert into @City values ( 'Klosterneuburg', 2400000, 8 );
            insert into @City values ( 'Leonding', 2500000, 9 );
            insert into @City values ( 'Enns', 2600000, 9 );
            insert into @City values ( 'Pressbaum', 2700000, 10 );
            insert into @City values ( 'Gunskirchen', 2800000, 10 );

            declare @OfferType as table ( OfferTypeCode nvarchar(50), OfferTypeDesc nvarchar(50), ID int );
            insert into @OfferType values ( 'Rent', 'zur Miete', 10000000 );
            insert into @OfferType values ( 'Buy', 'zum Kauf', 20000000 );
            insert into @OfferType values ( 'Buy', 'als Anlegerobjekt', 30000000 );
            insert into @OfferType values ( 'Rent', 'zum Wohnen und Arbeiten', 40000000 );
            
            declare @HeatingType as table ( HeatingType nvarchar(50), ID int );
            insert into @HeatingType values ( 'Erdwärme', 100000000 );
            insert into @HeatingType values ( 'Öl', 200000000 );
            insert into @HeatingType values ( 'Gas', 300000000 );
            insert into @HeatingType values ( 'Fernwärme', 400000000 );
            insert into @HeatingType values ( 'Pallets', 500000000 );
            insert into @HeatingType values ( 'Holz', 600000000 )";
        #endregion

        #region InsertDemoDataStatement
        public const string InsertDemoDataStatement = @"
            set nocount on;

            INSERT INTO RealEstate (
	            [RealEstateID]
	            ,[DateOfFirstOffering]
	            ,[TypeOfRealEstate]
	            ,[TypeOfOffer]
	            ,[Description]
	            ,[SizeOfParcel]
	            ,[SizeOfLivingSpace]
	            ,[SizeOfBuildingArea]
	            ,[SizeOfLivingRoom]
	            ,[SizeOfSleepingRoom]
	            ,[SizeOfGarden]
	            ,[SizeOfCellar]
	            ,[HasBalcony]
	            ,[HasTerrace]
	            ,[HasElevator]
	            ,[HasImage]
	            ,[IsFirstTimeUse]
	            ,[ViewDirection]
	            ,[NumberOfParkingLotsOutdoor]
	            ,[NumberOfParkingLotsRoofed]
	            ,[NumberOfParkingLotsGarage]
	            ,[NumberOfBathrooms]
	            ,[NumberOfStarsEstateAgent]
	            ,[NumberOfRooms]
	            ,[HeatingType]
	            ,[EarliestAvailable]
	            ,[MonthlyCost]
	            ,[PurchasingPrice]
	            ,[Location]
	            )
            select	a1.ID + ret.ID + a2.ID + d.ID + m.ID + c.ID + ot.ID + ht.ID,
		            dateadd(wk, cast(rand(a1.ID + ret.ID + a2.ID + d.ID + m.ID + c.ID + ot.ID + ht.ID) * 100000 as int) % 100,
			            convert(datetimeoffset(0), '01.02.2009', 104)),
		            ret.TypeOfRealEstate,
		            ot.OfferTypeCode,
		            upper(substring(a1.Attribute, 1, 1)) + substring(a1.Attribute, 2, len(a1.Attribute)-1) + ret.AttributeEnd 
			            + ' ' + ret.TypeDescription 
			            + ' ' + ot.OfferTypeDesc
			            + ', ' + m.Maximizer 
			            + ' ' + a2.Attribute + d.DescriptionEnd + ' ' + d.Description
			            + ', ganz in der Nähe von ' + c.City
			            + ', geheizt mit ' + ht.HeatingType,
		            case when ret.TypeOfRealEstate in ( 'Land', 'House' )
			            then cast(rand((a1.ID + ret.ID + a2.ID + d.ID + m.ID + c.ID + ot.ID + ht.ID) + pi() * 1000000) * 100000 as int) % 1000
			            else null
		            end as SizeOfParcel,
		            case when ret.TypeOfRealEstate <> 'Land'
			            then cast(rand((a1.ID + ret.ID + a2.ID + d.ID + m.ID + c.ID + ot.ID + ht.ID) + pi() * 2000000) * 100000 as int) % 200
			            else null
		            end as SizeOfLivingSpace,
		            case when ret.TypeOfRealEstate <> 'Land'
			            then cast(rand((a1.ID + ret.ID + a2.ID + d.ID + m.ID + c.ID + ot.ID + ht.ID) + pi() * 3000000) * 100000 as int) % 100
			            else null
		            end as SizeOfBuildingArea,
		            case when ret.TypeOfRealEstate <> 'Land'
			            then cast(rand((a1.ID + ret.ID + a2.ID + d.ID + m.ID + c.ID + ot.ID + ht.ID) + pi() * 4000000) * 100000 as int) % 75
			            else null
		            end as SizeOfLivingRoom,
		            case when ret.TypeOfRealEstate <> 'Land'
			            then cast(rand((a1.ID + ret.ID + a2.ID + d.ID + m.ID + c.ID + ot.ID + ht.ID) + pi() * 5000000) * 100000 as int) % 75
			            else null
		            end as SizeOfSleepingRoom,
		            case when ret.TypeOfRealEstate <> 'Land'
			            then cast(rand((a1.ID + ret.ID + a2.ID + d.ID + m.ID + c.ID + ot.ID + ht.ID) + pi() * 6000000) * 100000 as int) % 500
			            else null
		            end as SizeOfGarden,
		            case when ret.TypeOfRealEstate <> 'Land'
			            then cast(rand((a1.ID + ret.ID + a2.ID + d.ID + m.ID + c.ID + ot.ID + ht.ID) + pi() * 7000000) * 100000 as int) % 75
			            else null
		            end as SizeOfCellar,
		            case when ret.TypeOfRealEstate in ( 'Apartment', 'House' )
			            then cast(cast(rand((a1.ID + ret.ID + a2.ID + d.ID + m.ID + c.ID + ot.ID + ht.ID) + pi() * 8000000) * 100000 as int) % 2 as bit)
			            else null
		            end as HasBalcony,
		            case when ret.TypeOfRealEstate in ( 'Apartment', 'House' )
			            then cast(cast(rand((a1.ID + ret.ID + a2.ID + d.ID + m.ID + c.ID + ot.ID + ht.ID) + pi() * 9000000) * 100000 as int) % 2 as bit)
			            else null
		            end as HasTerrace,
		            case when ret.TypeOfRealEstate in ( 'Apartment', 'House' )
			            then cast(cast(rand((a1.ID + ret.ID + a2.ID + d.ID + m.ID + c.ID + ot.ID + ht.ID) + pi() * 10000000) * 100000 as int) % 2 as bit)
			            else null
		            end as HasElevator,
		            cast(cast(rand((a1.ID + ret.ID + a2.ID + d.ID + m.ID + c.ID + ot.ID + ht.ID) + pi() * 11000000) * 100000 as int) % 2 as bit) as HasImage,
		            case when ret.TypeOfRealEstate <> 'Land'
			            then cast(cast(rand((a1.ID + ret.ID + a2.ID + d.ID + m.ID + c.ID + ot.ID + ht.ID) + pi() * 12000000) * 100000 as int) % 2 as bit)
			            else null
		            end as IsFirstTimeUse,
		            case when ret.TypeOfRealEstate <> 'Land'
			            then case cast(rand((a1.ID + ret.ID + a2.ID + d.ID + m.ID + c.ID + ot.ID + ht.ID) + pi() * 13000000) * 100000 as int) % 4
				            when 0 then 'North'
				            when 1 then 'South'
				            when 2 then 'West'
				            when 3 then 'East'
				            else null
			            end
			            else null
		            end as ViewDirection,
		            case when ret.TypeOfRealEstate <> 'Land'
			            then cast(rand((a1.ID + ret.ID + a2.ID + d.ID + m.ID + c.ID + ot.ID + ht.ID) + pi() * 14000000) * 100000 as int) % 5
			            else null
		            end as NumberOfParkingLotsOutdoor,
		            case when ret.TypeOfRealEstate <> 'Land'
			            then cast(rand((a1.ID + ret.ID + a2.ID + d.ID + m.ID + c.ID + ot.ID + ht.ID) + pi() * 15000000) * 100000 as int) % 4
			            else null
		            end as NumberOfParkingLotsRoofed,
		            case when ret.TypeOfRealEstate <> 'Land'
			            then cast(rand((a1.ID + ret.ID + a2.ID + d.ID + m.ID + c.ID + ot.ID + ht.ID) + pi() * 16000000) * 100000 as int) % 3
			            else null
		            end as NumberOfParkingLotsGarage,
		            case when ret.TypeOfRealEstate <> 'Land'
			            then cast(rand((a1.ID + ret.ID + a2.ID + d.ID + m.ID + c.ID + ot.ID + ht.ID) + pi() * 17000000) * 100000 as int) % 4
			            else null
		            end as NumberOfBathrooms,
		            case when ret.TypeOfRealEstate <> 'Land'
			            then cast(rand((a1.ID + ret.ID + a2.ID + d.ID + m.ID + c.ID + ot.ID + ht.ID) + pi() * 18000000) * 100000 as int) % 6
			            else null
		            end as NumberOfStarsEstateAgent,
		            case when ret.TypeOfRealEstate <> 'Land'
			            then cast(rand((a1.ID + ret.ID + a2.ID + d.ID + m.ID + c.ID + ot.ID + ht.ID) + pi() * 19000000) * 100000 as int) % 8
			            else null
		            end as NumberOfRooms,
		            ht.HeatingType,
		            dateadd(wk, cast(rand((a1.ID + ret.ID + a2.ID + d.ID + m.ID + c.ID + ot.ID + ht.ID) + pi() * 20000000) * 100000 as int) % 70,
			            convert(datetimeoffset(0), '01.01.2010', 104)) as EarliestAvailable,
		            cast(rand((a1.ID + ret.ID + a2.ID + d.ID + m.ID + c.ID + ot.ID + ht.ID) + pi() * 21000000) * 1000000 as int) % 1000 as MonthlyCost,
		            cast(rand((a1.ID + ret.ID + a2.ID + d.ID + m.ID + c.ID + ot.ID + ht.ID) + pi() * 22000000) * 1000000 as int) as PurchasingPrice,
		            c.City
            from	@Attributes a1
		            cross join @RealEstateType ret
		            cross join ( select Attribute, ID * 10 as ID from @Attributes ) a2
		            cross join @DetailedDescription d
		            cross join @Maximizer m
		            cross join @City c
		            cross join @OfferType ot
		            cross join @HeatingType ht";
        #endregion

        #region AllCitiesStatement
        public const string AllCitiesStatement =
            "select * from @City";
        #endregion
    }
}
