﻿using System;

namespace DemoDataGenerator
{
    public class LogRow
    {
        public string ActionDescription { get; set; }
        public PartitionConnectionInformation Partition { get; set; }
        public string City { get; set; }
        public int ManagedProcessID { get; set; }
        public TimeSpan Duration { get; set; }
    }
}
