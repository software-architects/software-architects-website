﻿using System;
using System.Collections.ObjectModel;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;

namespace DemoDataGenerator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            // Set thread pool to min. 11 threads to enable the creation of up to 11
            // parallel threads with PLINQ
            int minThreads, completionPortThreads;
            ThreadPool.GetMinThreads(out minThreads, out completionPortThreads);
            ThreadPool.SetMinThreads(Math.Max(minThreads, 11), Math.Max(completionPortThreads, 11));

            this.WorkLocally = true;
            this.Log = new ObservableCollection<LogRow>();
            this.DataContext = this;
        }

        public bool WorkLocally { get; set; }
        public ObservableCollection<LogRow> Log { get; set; }

        private void ClearAllDatabases(object sender, RoutedEventArgs e)
        {
            this.Log.Clear();
            var manager = DemoDataManager.CreateDefaultManager(this.WorkLocally);
            Task.Factory.StartNew(() => manager.ClearAllDatabases(logRow =>
                {
                    this.Dispatcher.BeginInvoke(new Action(() =>
                        {
                            this.Log.Add(logRow);
                        }));
                }));
        }

        private void FillLargeDB(object sender, RoutedEventArgs e)
        {
            this.Log.Clear();
            var manager = DemoDataManager.CreateDefaultManager(this.WorkLocally);
            Task.Factory.StartNew(() => manager.LoadAllDatabases(logRow =>
                {
                    this.Dispatcher.BeginInvoke(new Action(() =>
                    {
                        this.Log.Add(logRow);
                    }));
                }));
        }
    }
}
