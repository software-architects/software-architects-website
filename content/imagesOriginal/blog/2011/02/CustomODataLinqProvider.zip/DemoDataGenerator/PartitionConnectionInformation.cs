﻿namespace DemoDataGenerator
{
    public class PartitionConnectionInformation
    {
        public string PartitionConnectionString { get; private set; }
        public string CityFilter { get; private set; }
        public int? ClusterFilter { get; private set; }

        public PartitionConnectionInformation(
            string partitionConnectionString,
            string cityFilter = null,
            int? clusterFilter = null)
        {
            this.CityFilter = cityFilter;
            this.ClusterFilter = clusterFilter;
            this.PartitionConnectionString = partitionConnectionString;
        }
    }
}
