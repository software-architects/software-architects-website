﻿using System;
using System.Runtime.Serialization;

namespace ShardingProvider
{
    /// <summary>
    /// Represents an exception thrown by the <see cref="ShardingProvider{TContext, TEntity}"/>
    /// </summary>
    public class ShardingProviderException : NotSupportedException
    {
        public ShardingProviderException()
            : base()
        {
        }

        public ShardingProviderException(string message)
            : base(message)
        {
        }

        protected ShardingProviderException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        public ShardingProviderException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}
