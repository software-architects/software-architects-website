﻿using System;
using System.Data.Objects.DataClasses;
using System.Linq;
using System.Linq.Expressions;

namespace ShardingProvider
{
    /// <summary>
    /// Replaces constants of type IQueryable&lt;T&gt; with a specified expression
    /// </summary>
    internal class SwitchQueryable<T> : System.Linq.Expressions.ExpressionVisitor where T : EntityObject
    {
        private Expression targetExpression;

        /// <summary>
        /// Initializes a new instance of the SwitchQueryable class
        /// </summary>
        /// <param name="targetExpression">Expression that should take the place of the IQueryable&lt;T&gt;</param>
        public SwitchQueryable(Expression targetExpression)
        {
            if (targetExpression == null)
            {
                throw new ArgumentNullException("targetExpression");
            }

            this.targetExpression = targetExpression;
        }

        protected override Expression VisitConstant(ConstantExpression node)
        {
            if (typeof(IQueryable<T>).IsAssignableFrom(node.Type))
            {
                return this.targetExpression;
            }

            return base.VisitConstant(node);
        }
    }
}
