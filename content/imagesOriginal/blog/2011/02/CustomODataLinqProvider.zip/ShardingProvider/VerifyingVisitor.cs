﻿using System;
using System.Data.Objects.DataClasses;
using System.Linq.Expressions;
using System.Reflection;

namespace ShardingProvider
{
    internal class VerifyingVistor<T> : System.Linq.Expressions.ExpressionVisitor where T : EntityObject
    {
        /// <summary>
        /// Reference to the take expression
        /// </summary>
        public ConstantExpression TakeExpression { get; private set; }

        /// <summary>
        /// Reference to the body of the query's order by lambda expression
        /// </summary>
        public MemberExpression OrderByLambdaBody { get; private set; }

        /// <summary>
        /// Reference to the query's order by lambda expression
        /// </summary>
        public LambdaExpression OrderByLambda { get; private set; }

        /// <summary>
        /// Indicates whether the ordering should be ascending
        /// </summary>
        public bool Ascending { get; private set; }

        /// <summary>
        /// Indicates whether the veryfied query is valid
        /// </summary>
        public bool IsValid
        {
            get
            {
                return this.TakeExpression != null && this.OrderByLambdaBody != null && this.OrderByLambda != null;
            }
        }

        /// <summary>
        /// Validates the query based on the defined business logic for real
        /// estate queries.
        /// </summary>
        /// <param name="m">Expression for the method call</param>
        /// <exception cref="RealEstateQueryException">Thrown in case of an invalid query (see remarks)</exception>
        /// <returns>If no exception occurred the method returns <paramref name="m"/>.</returns>
        /// <remarks>
        /// <para>Checks method calls whether they fulfill all defined business rules:</para>
        /// <list type="bullet">
        /// <item>Query must not contain multiple 'Take' expressions</item>
        /// <item>'Take' must contain a constant integer expression with a value <= 25</item>
        /// <item>Query must not contain multiple 'OrderBy' expressions</item>
        /// <item>'OrderBy' must be a single reference to a supported member for a real estate</item>
        /// <item>Ordering by multiple criteria is not supported</item>
        /// </list>
        /// </remarks>
        protected override Expression VisitMethodCall(MethodCallExpression m)
        {
            switch (m.Method.Name)
            {
                case "Take":
                    if (this.TakeExpression != null)
                    {
                        throw new ShardingProviderException("Query must not contain multiple 'Take' expressions");
                    }

                    if (m.Arguments.Count < 2 || (this.TakeExpression = m.Arguments[1] as ConstantExpression) == null
                        || Convert.ToInt32(this.TakeExpression.Value) > 25)
                    {
                        throw new ShardingProviderException("'Take' must contain a constant integer expression with a value <= 25");
                    }

                    break;

                case "OrderBy":
                case "OrderByDescending":
                    MemberExpression memberAccess;

                    if (this.OrderByLambdaBody != null)
                    {
                        throw new ShardingProviderException("Query must not contain multiple 'OrderBy' expressions");
                    }

                    if (m.Arguments.Count < 2)
                    {
                        throw new InvalidOperationException("Method call expression contains an invalid number of arguments");
                    }

                    if (m.Arguments[1].NodeType == ExpressionType.Quote)
                    {
                        this.OrderByLambda = ((UnaryExpression)m.Arguments[1]).Operand as LambdaExpression;
                    }
                    else
                    {
                        this.OrderByLambda = m.Arguments[1] as LambdaExpression;
                    }

                    if (this.OrderByLambda == null || (memberAccess = this.OrderByLambda.Body as MemberExpression) == null
                        || memberAccess.Expression.NodeType != ExpressionType.Parameter
                        || memberAccess.Member.MemberType != MemberTypes.Property
                        || memberAccess.Member.DeclaringType != typeof(T))
                    {
                        throw new ShardingProviderException(string.Format(
                            "'OrderBy' must be a single reference to a supported member of type {0}",
                            typeof(T).Name));
                    }

                    // Store reference to body of lambda for later use
                    this.OrderByLambdaBody = memberAccess;
                    this.Ascending = m.Method.Name == "OrderBy";
                    break;

                case "ThenBy":
                case "ThenByDescending":
                    //throw new ShardingProviderException("Ordering by multiple criteria is not supported");
                    break;

                default:
                    break;
            }

            return base.VisitMethodCall(m);
        }
    }
}
