﻿namespace IronPython.UI.ViewModel
{
	public enum WindowContent
	{
		Speakers,
		Sessions
	}
}
