﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Excel = Microsoft.Office.Interop.Excel;
using System.Reflection;
using Microsoft.Office.Interop.Excel;

namespace OfficeInterop
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] values = { 4, 6, 18, 2, 1, 76, 0, 3, 11 };

            CreateWorkbook(values, @"C:\temp\SampleWorkbook.xlsx");
        }

        static void CreateWorkbook(int[] values, string filePath)
        {
            Excel.Application excelApp = null;
            Excel.Workbook wkbk;
            Excel.Worksheet sheet;

            try
            {
                // Start Excel and create a workbook and worksheet.
                excelApp = new Excel.Application();
                wkbk = excelApp.Workbooks.Add();
                sheet = wkbk.Sheets.Add() as Excel.Worksheet;
                sheet.Name = "Sample Worksheet";

                // Write a column of values.
                for (int i = 1; i < values.Length; i++)
                {
                    sheet.Cells[i, 1] = values[i];
                }

                // Suppress any alerts and save the file. Create the directory 
                // if it does not exist. Overwrite the file if it exists.
                excelApp.DisplayAlerts = false;
                string folderPath = Path.GetDirectoryName(filePath);
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }
                wkbk.SaveAs(filePath);
            }
            catch
            {
            }
            finally
            {
                sheet = null;
                wkbk = null;

                // Close Excel.
                excelApp.Quit();
                excelApp = null;
            }
        }
    }
}
