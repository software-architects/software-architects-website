﻿using System;
using System.Linq.Expressions;
using System.Reflection;

namespace CustomLinqProvider
{
	/// <summary>
	/// Simple visitor that extracts "Take" and "Skip" clauses from expression tree
	/// </summary>
	internal class AnalyzeQueryVisitor : ExpressionVisitor
	{
		public AnalyzeQueryVisitor()
		{
			this.Take = 100;
			this.Skip = 0;
		}

		public int Take { get; private set; }
		public int Skip { get; private set; }

		protected override Expression VisitMethodCall(MethodCallExpression m)
		{
			switch (m.Method.Name)
			{
				case "Take":
					this.Take = (int)(m.Arguments[1] as ConstantExpression).Value;
					break;
				case "Skip":
					this.Skip = (int)(m.Arguments[1] as ConstantExpression).Value;
					break;
				case "OrderBy":
					// We do not check/consider order by yet.
					break;
				default:
					throw new CustomLinqProviderException("Method not supported!");
			}

			return base.VisitMethodCall(m);
		}
	}
}
