﻿using System;
using System.Runtime.Serialization;

namespace CustomLinqProvider
{
	[Serializable]
	public class CustomLinqProviderException : NotSupportedException
	{
		public CustomLinqProviderException()
			: base()
		{
		}

		public CustomLinqProviderException(string message)
			: base(message)
		{
		}

		protected CustomLinqProviderException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}

		public CustomLinqProviderException(string message, Exception innerException)
			: base(message, innerException)
		{
		}
	}
}
