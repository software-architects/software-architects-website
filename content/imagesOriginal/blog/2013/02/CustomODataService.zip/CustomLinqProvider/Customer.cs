﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CustomLinqProvider
{
	public class Customer
	{
		public int CustomerID { get; set; }
		public string CompanyName { get; set; }
		public string ContactPersonFirstName { get; set; }
		public string ContactPersonLastName { get; set; }

		public override string ToString()
		{
			return string.Format("{0}, {1} {2}, {3}", this.CustomerID, this.ContactPersonFirstName, this.ContactPersonLastName, this.CompanyName);
		}

		public static IReadOnlyList<Customer> GenerateDemoCustomers(int firstCustomerID = 0, int numberOfCustomers = 100)
		{
			var rand = new Random();
			return Enumerable.Range(firstCustomerID, numberOfCustomers)
				.Select(i => new Customer()
				{
					CustomerID = i,
					ContactPersonLastName = DemoNames.LastNames[rand.Next(DemoNames.LastNames.Count)],
					ContactPersonFirstName = DemoNames.FirstNames[rand.Next(DemoNames.FirstNames.Count)],
					CompanyName = string.Format(
						"{0} {1} {2}",
						DemoNames.CompanyNamesPart1[rand.Next(DemoNames.CompanyNamesPart1.Count)],
						DemoNames.CompanyNamesPart2[rand.Next(DemoNames.CompanyNamesPart2.Count)],
						DemoNames.CompanyNamesPart3[rand.Next(DemoNames.CompanyNamesPart3.Count)])
				})
				.ToArray();
		}
	}
}
