﻿using IQToolkit;
using System;
using System.Linq;
using System.Linq.Expressions;

namespace CustomLinqProvider
{
	public class DemoCustomerProvider : QueryProvider
	{
		public override object Execute(Expression expression)
		{
			// Use a visitor to extract demo data generation parameters
			// ("take" and "skip" clauses)
			var analyzer = new AnalyzeQueryVisitor();
			analyzer.Visit(expression);

			// Generate data
			return Customer.GenerateDemoCustomers(analyzer.Skip, analyzer.Take);
		}

		public override string GetQueryText(Expression expression)
		{
			throw new NotImplementedException();
		}
	}
}
