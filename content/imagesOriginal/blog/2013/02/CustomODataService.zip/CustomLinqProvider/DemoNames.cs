﻿using System.Collections.Generic;

namespace CustomLinqProvider
{
	/// <summary>
	/// Contains some common names used to generate customer demo data
	/// </summary>
	public static class DemoNames
	{
		public static readonly IReadOnlyList<string> LastNames = new [] {
			"Smith", "Johnson", "Williams", "Jones", "Brown", "Davis", "Miller", "Wilson", "Moore", "Taylor", "Anderson",
			"Thomas", "Jackson", "White", "Harris", "Martin", "Thompson", "Garcia", "Martinez", "Robinson",
			"Clark", "Rodriguez", "Lewis", "Lee", "Walker", "Hall", "Allen", "Young", "Hernandez",
			"King", "Wright", "Lopez", "Hill", "Scott", "Green", "Adams", "Baker", "Gonzalez",
			"Nelson", "Carter", "Mitchell", "Perez", "Roberts", "Turner", "Phillips", "Campbell", "Parker",
			"Evans", "Edwards", "Collins", "Stewart", "Sanchez", "Morris", "Rogers", "Reed", "Cook",
			"Morgan", "Bell", "Murphy", "Bailey", "Rivera", "Cooper", "Richardson", "Cox", "Howard",
			"Ward", "Torres", "Peterson", "Gray", "Ramirez", "James", "Watson", "Brooks", "Kelly",
			"Sanders", "Price", "Bennett", "Wood", "Barnes", "Ross", "Henderson", "Coleman", "Jenkins",
			"Perry", "Powell", "Long", "Patterson", "Hughes", "Flores", "Washington", "Butler", "Simmons",
			"Foster", "Gonzales", "Bryant", "Alexander", "Russell", "Griffin", "Diaz", "Hayes", "Myers",
			"Ford", "Hamilton", "Graham", "Sullivan", "Wallace", "Woods", "Cole", "West", "Jordan",
			"Owens", "Reynolds", "Fisher", "Ellis", "Harrison", "Gibson", "Mcdonald", "Cruz", "Marshall", 
			"Ortiz", "Gomez", "Murray", "Freeman", "Wells", "Webb", "Simpson", "Stevens", "Tucker", "Porter", "Hunter"
		};

		public static readonly IReadOnlyList<string> FirstNames = new[] {
			"Jack", "Lewis", "Riley", "James", "Logan", "Daniel", "Ethan", "Harry", "Alexander", "Oliver", "Max", "Tyler", "Aaron", "Charlie", "Adam",
			"Finlay", "Alfie", "Mason", "Ryan", "Liam", "Lucas", "Thomas", "Jamie", "Callum", "Cameron", "Kyle", "Dylan", "Matthew", "Harris", "Rory",
			"Noah", "Connor", "Joshua", "Nathan", "Jacob", "Aiden", "Archie", "William", "Leo", "Jayden", "Luke", "Andrew", "Rhys", "Cole", "David", "Kai",
			"Joseph", "Michael", "Samuel", "Leon", "Benjamin", "John", "Harrison", "Brodie", "Owen", "Robbie", "Ben", "Josh", "Oscar", "Robert", "Fraser",
			"Caleb", "Euan", "Jake", "Jay", "Finn", "Blair", "Calum", "Muhammad", "Ross", "Arran", "Ollie", "Evan", "Murray", "Angus", "Christopher", "Scott",
			"Cooper", "Sam", "Zac", "Alex", "Kayden", "Ewan", "Aidan", "George", "Ruaridh", "Kaiden", "Declan", "Isaac", "Blake", "Cody", "Olly", "Calvin",
			"Mark", "Luca", "Shay", "Jude", "Sean", "Sebastian", "Kian",
			"Sophie", "Emily", "Olivia", "Ava", "Lucy", "Isla", "Lily", "Jessica", "Amelia", "Mia", "Millie", "Eva", "Ellie", "Chloe", "Freya", "Sophia", "Grace",
			"Emma", "Hannah", "Holly", "Ruby", "Amy", "Erin", "Leah", "Eilidh", "Ella", "Katie", "Charlotte", "Brooke", "Evie", "Layla", "Kayla", "Anna",
			"Poppy", "Rebecca", "Orla", "Summer", "Lexi", "Hollie", "Niamh", "Amber", "Lacey", "Maisie", "Molly", "Skye", "Isabella", "Abbie", "Zoe", "Daisy",
			"Megan", "Aimee", "Abigail", "Lilly", "Sarah", "Lauren", "Julia", "Zara", "Georgia", "Paige", "Caitlin", "Madison", "Sofia", "Iona", "Lola",
			"Mya", "Rosie", "Keira", "Mollie", "Cara", "Eve", "Darcy", "Robyn", "Elizabeth", "Elise", "Beth", "Alice", "Emilia", "Maya", "Rachel", "Sienna",
			"Amelie", "Taylor", "Rose", "Nicole", "Faith", "Kara", "Alexis", "Imogen", "Lucie", "Bella", "Carly", "Willow", "Lois", "Alyssa", "Gracie", "Lexie",
			"Maria", "Scarlett", "Alexandra", "Lara", "Mirren"
		};

		public static readonly IReadOnlyList<string> CompanyNamesPart1 = new[] { 
			"Corina", "Amelia", "Menno", "Malthe", "Hartwing", "Marlen", "Arend", "Huber", "Volker", "Murakami", "Schwalb", 
			"Naval", "Montrose", "Fernando", "Hao", "Sunde", "Charlebois", "Batiz", "Mortimore" };
		public static readonly IReadOnlyList<string> CompanyNamesPart2 = new[] { 
			"Construction", "Engineering", "Consulting", "Trading", "Metal Construction", "Publishers", "Software", 
			"Architecture", "Plan Engineering", "Electro", "Air Conditioning", "Plumbing" };
		public static readonly IReadOnlyList<string> CompanyNamesPart3 = new[] {
			"Ltd", "Limited", "Corporation", "Limited Company", "Joint Venture", "Ltd.", "Cooperative" };
	}
}
