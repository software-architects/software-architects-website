﻿using IQToolkit;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using CustomLinqProvider;
using System.Linq;

namespace CustomODataProvider.Test
{
    [TestClass]
    public class LinqProviderTest
    {
        [TestMethod]
        public void TestSuccessfullQueries()
        {
			var provider = new DemoCustomerProvider();

			var result = new Query<Customer>(provider).ToArray();
			Assert.AreEqual(100, result.Length);
			Assert.AreEqual(0, result[0].CustomerID);

			result = new Query<Customer>(provider).Skip(100).ToArray();
			Assert.AreEqual(100, result.Length);
			Assert.AreEqual(100, result[0].CustomerID);

			result = new Query<Customer>(provider).Skip(100).Take(10).ToArray();
			Assert.AreEqual(10, result.Length);
			Assert.AreEqual(100, result[0].CustomerID);
        }

		[TestMethod]
		public void TestIllegalQuery()
		{
			var provider = new DemoCustomerProvider();
			bool exception = false;
			try
			{
				new Query<Customer>(provider).Where(c => c.CustomerID == 5).ToArray();
			}
			catch (CustomLinqProviderException)
			{
				exception = true;
			}

			Assert.IsTrue(exception);
		}
	}
}
