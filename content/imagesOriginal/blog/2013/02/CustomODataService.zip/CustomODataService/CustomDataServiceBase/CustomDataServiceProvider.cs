﻿using System;
using System.Collections.Generic;
using System.Data.Services.Providers;
using System.Linq;

namespace CustomODataService.CustomDataServiceBase
{
    public class CustomDataServiceProvider : IDataServiceQueryProvider
    {
        private IGenericDataServiceContext currentDataSource;
        private IDataServiceMetadataProvider metadata;

        public CustomDataServiceProvider(IDataServiceMetadataProvider metadata, IGenericDataServiceContext dataSource)
        {
            this.metadata = metadata;
			this.currentDataSource = dataSource;
        }

        public object CurrentDataSource
        {
            get { return currentDataSource; }
            set { currentDataSource = value as IGenericDataServiceContext; }
        }

        public IQueryable GetQueryRootForResourceSet(ResourceSet resourceSet)
        {
            return currentDataSource.GetQueryable(resourceSet);
        }

        public ResourceType GetResourceType(object target)
        {
            var type = target.GetType();
            return metadata.Types.Single(t => t.InstanceType == type);
        }

		#region Implementation of IDataServiceQueryProvider
		public bool IsNullPropagationRequired
        {
            get { return true; }
        }

        public object GetOpenPropertyValue(object target, string propertyName)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<KeyValuePair<string, object>> GetOpenPropertyValues(object target)
        {
            throw new NotImplementedException();
        }

        public object GetPropertyValue(object target, ResourceProperty resourceProperty)
        {
            throw new NotImplementedException();
        }

        public object InvokeServiceOperation(ServiceOperation serviceOperation, object[] parameters)
        {
            throw new NotImplementedException();
		}
		#endregion
	}
}