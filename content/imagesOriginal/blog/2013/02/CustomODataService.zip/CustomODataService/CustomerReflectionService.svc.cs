﻿using IQToolkit;
using CustomLinqProvider;
using System.Data.Services;
using System.Data.Services.Common;
using System.Linq;
using System.ServiceModel;

namespace CustomODataService
{
	/// <summary>
	/// Implements a context class that contain queryables which we want to expose using OData
	/// </summary>
    public class CustomerReflectionContext 
    {
		//public IQueryable<Customer> Customer
		//{
		//	get
		//	{
		//		// Generate 1000 customers and return queryable so that user can query the
		//		// generated data.
		//		return CustomLinqProvider.Customer
		//			.GenerateDemoCustomers(numberOfCustomers: 100)
		//			.AsQueryable();
		//	}
		//}

		public IQueryable<Customer> Customer
		{
			get
			{
				// Use custom linq provider to generate exactly the number of customers we need
				return new Query<Customer>(new DemoCustomerProvider());
			}
		}
    }

    [ServiceBehavior(IncludeExceptionDetailInFaults = true)]
    public class CustomerReflectionService : DataService<CustomerReflectionContext>
    {
        // This method is called only once to initialize service-wide policies.
        public static void InitializeService(DataServiceConfiguration config)
        {
            // TODO: set rules to indicate which entity sets and service operations are visible, updatable, etc.
            // Examples:
            config.SetEntitySetAccessRule("*", EntitySetRights.AllRead);
            // config.SetServiceOperationAccessRule("MyServiceOperation", ServiceOperationRights.All);
            config.DataServiceBehavior.MaxProtocolVersion = DataServiceProtocolVersion.V2;
            config.UseVerboseErrors = true;
        }
    }
}
