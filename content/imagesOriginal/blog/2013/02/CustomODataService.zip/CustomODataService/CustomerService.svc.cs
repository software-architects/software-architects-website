﻿using System;
using System.Data.Services;
using System.Data.Services.Common;
using System.Data.Services.Providers;
using CustomODataService.CustomDataServiceBase;
using System.Threading;
using CustomLinqProvider;
using System.Reflection;
using System.Linq;
using IQToolkit;

namespace CustomODataService
{
	public class CustomerServiceDataContext : IGenericDataServiceContext
	{
		public IQueryable GetQueryable(ResourceSet set)
		{
			if (set.Name == "Customer")
			{
				return new Query<Customer>(new DemoCustomerProvider());
			}

			return null;
		}
	}

	public class CustomerService : DataService<object>, IServiceProvider
    {
		private readonly IDataServiceMetadataProvider customerMetadata;
		private readonly CustomDataServiceProvider dataSource;

		public CustomerService()
		{
			this.customerMetadata = CustomDataServiceMetadataProvider.BuildDefaultMetadataForClass<Customer>("DefaultNamespace");
			this.dataSource = new CustomDataServiceProvider(this.customerMetadata, new CustomerServiceDataContext());
		}

        public static void InitializeService(DataServiceConfiguration config)
        {
            // Enable read for all entities
            config.SetEntitySetAccessRule("*", EntitySetRights.AllRead);

            // Various other settings
            config.DataServiceBehavior.MaxProtocolVersion = DataServiceProtocolVersion.V2;
            config.DataServiceBehavior.AcceptProjectionRequests = false;
        }

		public object GetService(Type serviceType)
		{
			if (serviceType == typeof(IDataServiceMetadataProvider))
			{
				return this.customerMetadata;
			}
			else if (serviceType == typeof(IDataServiceQueryProvider))
			{
				return this.dataSource;
			}

			return null;
		}
	}
}