#include <vector>

void Sieve()
{
	std::vector<int> numbers(5);
	for(int i = 0; i < 5; i++) { numbers.push_back(i); }
}