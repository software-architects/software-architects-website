#pragma once

class MyVector2
{
public:
	MyVector2(float _x, float _y)
		: x(_x), y(_y)
	{
	}
	float x;
	float y;
};
