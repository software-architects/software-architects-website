#include "stdafx.h"
#include "CppUnitTest.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace VC2012Test
{	
	using namespace std;

	enum OldColorA { Red, Green, Blue, Yellow, Magenta, Orange };
	enum OldColorB { BlueB, GreenB, RedB };



	enum class ColorA { Red, Green, Blue, Yellow, Magenta, Orange };
	enum class ColorB { Blue, Green, Red };

	TEST_CLASS(EnumClasses)
	{
	public:
		TEST_METHOD(TestEnumClass)
		{
			auto ocb = OldColorB::RedB;
			auto oca = OldColorA::Blue;

			Assert::IsTrue(oca == ocb); // feels awkward

			auto cA = ColorA::Red;
			auto cB = ColorB::Blue;

			// Assert::IsTrue(cA == cB); // does not even compile!
		}

		TEST_METHOD(TestEnumClassBackingStore)
		{
			enum class SmallEnum : unsigned char
			{
				Value1, 
				Value2, 
				Value3,
			};

			auto a = SmallEnum::Value1;
			static_assert(sizeof(SmallEnum) == 1, "Size of an enum of unsigned char.");
		}
	};
}