#include "stdafx.h"
#include "CppUnitTest.h"
#include <string>
#include <iostream>

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace VC2012CTPtest
{	
	using namespace std;

}