// VC2012CTP.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>

using namespace std;

void saveprint(std::string format)
{
	cout << endl;
}

void printn(std::string b, std::string c, float d)
{
}

template<typename Head, typename... Tail>
void saveprint(std::string format, Head head, Tail... args)
{
	cout << head << " ";
	printn(args...);
	//saveprint(format, args...);
}

int main()
{
	saveprint("asdf", 10, "hello", "world", 30.0f);
}

