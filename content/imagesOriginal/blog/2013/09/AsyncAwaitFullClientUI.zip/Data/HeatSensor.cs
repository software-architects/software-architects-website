﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AsyncAwaitFullClientUI.Data
{
	public class HeatSensor
	{
		public string SensorName { get; set; }
		public double Range { get; set; }
	}

	public class HeatSensors
	{
		public async Task<IEnumerable<HeatSensor>> FindSensorsAsync(
			CancellationToken cancellationToken,
			IProgress<int> progress)
		{
			for (int i = 0; i < 10; i++)
			{
				await Task.Run(() => Thread.Sleep(100));
				cancellationToken.ThrowIfCancellationRequested();
				if (progress != null)
				{
					progress.Report((i + 1) * 10);
				}
			}

			return Enumerable.Range(1, 10)
				.Select(i => new HeatSensor()
				{
					SensorName = string.Format("Sensor {0}", i),
					Range = (double)i
				})
				.ToArray();
		}
	}
}
