﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace AsyncAwaitFullClientUI
{
	public class DelegateCommand : ICommand
	{
		private Action executeAction;
		private Func<bool> canExecuteFunc;

		public DelegateCommand(Action executeAction, Func<bool> canExecuteFunc)
		{
			this.executeAction = executeAction;
			this.canExecuteFunc = canExecuteFunc;
		}

		public bool CanExecute(object parameter)
		{
			if (this.canExecuteFunc != null)
			{
				return this.canExecuteFunc();
			}
			else
			{
				return true;
			}
		}

		public event EventHandler CanExecuteChanged;

		public void RaiseCanExecuteChanged()
		{
			if (this.CanExecuteChanged != null)
			{
				this.CanExecuteChanged(this, new EventArgs());
			}
		}

		public void Execute(object parameter)
		{
			this.executeAction();
		}
	}
}
