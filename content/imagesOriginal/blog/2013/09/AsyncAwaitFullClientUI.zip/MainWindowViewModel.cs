﻿using AsyncAwaitFullClientUI.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Input;

namespace AsyncAwaitFullClientUI
{
	public class MainWindowViewModel : INotifyPropertyChanged
	{
		private HeatSensors sensors = new HeatSensors();

		public MainWindowViewModel()
		{
			this.FindAllSensorsCommand = new DelegateCommand(
				async () =>
				{
					this.IsLoading = true;
					this.Sensors = null;
					this.cts = new CancellationTokenSource();
					try
					{
						this.Sensors = await this.sensors.FindSensorsAsync(
							this.cts.Token,
							new Progress<int>((p) => this.Progress = p));
					}
					catch (OperationCanceledException)
					{
					}

					this.IsLoading = false;
				},
				() => !this.IsLoading);
			this.CancelCommand = new DelegateCommand(
				() => this.cts.Cancel(),
				() => this.IsLoading);

		}

		private CancellationTokenSource cts;

		public ICommand FindAllSensorsCommand { get; private set; }
		public ICommand CancelCommand { get; private set; }

		private bool isLoading;
		public bool IsLoading 
		{
			get { return this.isLoading; }
			private set
			{
				this.isLoading = value;
				((DelegateCommand)this.FindAllSensorsCommand).RaiseCanExecuteChanged();
				((DelegateCommand)this.CancelCommand).RaiseCanExecuteChanged();
			}
		}

		private int progress;
		public int Progress
		{
			get { return this.progress; }
			private set
			{
				this.progress = value;
				this.RaisePropertyChanged();
			}
		}

		private IEnumerable<HeatSensor> SensorsValue;
		public IEnumerable<HeatSensor> Sensors
		{
			get
			{
				return this.SensorsValue;
			}

			set
			{
				if (this.SensorsValue != value)
				{
					this.SensorsValue = value;
					this.RaisePropertyChanged();
				}
			}
		}

		public event PropertyChangedEventHandler PropertyChanged;

		private void RaisePropertyChanged([CallerMemberName]string caller = null)
		{
			if (this.PropertyChanged != null)
			{
				this.PropertyChanged(this, new PropertyChangedEventArgs(caller));
			}
		}
	}
}
