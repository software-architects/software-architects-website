﻿using System.AddIn.Contract;
using System.AddIn.Pipeline;

namespace AddInSideAdapters
{
    [AddInAdapter]
    public class CalculatorViewToContractAddInAdapter : ContractBase, Calculator.Contracts.ICalculatorContract
    {
        private AddInView.Calculator _view;

        public CalculatorViewToContractAddInAdapter(AddInView.Calculator view)
        {
            _view = view;
        }

        #region ICalculatorContract Members

        public IListContract<Calculator.Contracts.IOperationContract> GetOperations()
        {
            return CollectionAdapters.ToIListContract(
				_view.Operations, 
				OperationViewToContractAddInAdapter.ViewToContractAdapter, 
				OperationViewToContractAddInAdapter.ContractToViewAdapter);
            }

		public double Operate(Calculator.Contracts.IOperationContract op, double[] operands)
        {
           return _view.Operate(OperationViewToContractAddInAdapter.ContractToViewAdapter(op), operands);
        }

        public string GetName()
        {
            return _view.Name;
        }

        #endregion
    }
}
