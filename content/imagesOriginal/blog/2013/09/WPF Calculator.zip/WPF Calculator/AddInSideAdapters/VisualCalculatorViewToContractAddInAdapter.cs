﻿using System.AddIn.Contract;
using System.AddIn.Pipeline;

namespace AddInSideAdapters
{
    [AddInAdapter]
    public class VisualCalculatorViewToContractAddInAdapter : ContractBase, Calculator.Contracts.IVisualCalculatorContract
    {
        private AddInView.VisualCalculator _view;

        public VisualCalculatorViewToContractAddInAdapter(AddInView.VisualCalculator view)
        {
            _view = view;
        }

        #region ICalculatorContract Members

        public IListContract<Calculator.Contracts.IOperationContract> GetOperations()
        {
            return CollectionAdapters.ToIListContract(
				_view.Operations, 
				OperationViewToContractAddInAdapter.ViewToContractAdapter, 
				OperationViewToContractAddInAdapter.ContractToViewAdapter);
        }

        public INativeHandleContract Operate(Calculator.Contracts.IOperationContract op, double[] operands)
        {
            return FrameworkElementAdapters.ViewToContractAdapter(
				_view.Operate(OperationViewToContractAddInAdapter.ContractToViewAdapter(op), operands));
        }

        public string GetName()
        {
            return _view.Name;
        }

        #endregion
    }
}
