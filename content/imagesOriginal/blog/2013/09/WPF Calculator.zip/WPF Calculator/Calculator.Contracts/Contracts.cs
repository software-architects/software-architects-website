﻿using System.AddIn.Contract;
using System.AddIn.Pipeline;
using System.Security;

namespace Calculator.Contracts
{
    [AddInContract]
    public interface ICalculatorContract : IContract
    {
        IListContract<IOperationContract> GetOperations();
        [SecurityCritical]
        double Operate(IOperationContract op, double[] operands);
        string GetName();
    }

    [AddInContract]
    public interface IVisualCalculatorContract : IContract
    {
        IListContract<IOperationContract> GetOperations();
        INativeHandleContract Operate(IOperationContract op, double[] operands);
        string GetName();
    }

    public interface IOperationContract : IContract
    {
        string GetName();
        int GetNumOperands();
    }
}
